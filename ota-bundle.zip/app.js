/**
 * KUBERAN VASTU COMPASS APP v5.9.0
 * High Precision Vedic Architecture & Mobile Compass
 * 
 * ═══════════════════════════════════════════════════════════════════
 * ARCHITECTURE: Single-file IIFE with logical section organization
 * ═══════════════════════════════════════════════════════════════════
 * 
 * SECTION MAP (search for these markers to navigate):
 * 
 *   §1  STATE          — All mutable application state variables
 *   §2  DOM            — All document.getElementById references
 *   §3  MATH           — Heading computation, angle normalization, declination
 *   §4  STABILIZER     — CompassStabilizer class (RAF-based smooth interpolation)
 *   §5  VASTU_ENGINE   — Zone lookups (8/16/32), SVG dial rendering
 *   §6  UI_UPDATES     — Heading display, inclinometer, inspector panel
 *   §7  SENSORS        — DeviceOrientation handlers, magnetometer, GPS
 *   §8  CALIBRATION    — Manual offset, accuracy display
 *   §9  TOOLS          — Plot Tilt, Camera AR, Room Finder, Audit Report
 *   §10 LANGUAGE       — Multi-language switching (EN/HI/KN/TA/TE)
 *   §11 AYADI          — Shadvarga Calculator (perimeter-based formulas)
 *   §12 REMEDIES       — Vastu Dosha analysis engine & element-zone mapping
 *   §13 PWA            — Service Worker registration, install prompt
 *   §14 EVENTS         — All event listener bindings
 *   §15 BOOTSTRAP      — init() entry point
 * 
 * FUTURE MIGRATION PATH:
 *   When moving to a framework (React/Vue/Flutter), extract each §section
 *   into its own module. State → store/provider, DOM → component refs,
 *   Math → utility library, Sensors → custom hook/service.
 * ═══════════════════════════════════════════════════════════════════
 */

(function() {
  'use strict';

  // ═══ §1 STATE ═══════════════════════════════════════════════════
  // All mutable application state. Future: extract to state.js or a Zustand/Redux store.
  let currentHeading = 0;
  let rawMagneticHeading = 0;
  let smoothedHeading = null;
  // (smoothing factor is now adaptive - see updateHeading)
  let calibrationOffset = 0;
  try {
    const savedOffset = localStorage.getItem('kuberan-vastu-compass-offset');
    if (savedOffset !== null) {
      calibrationOffset = parseFloat(savedOffset) || 0;
    }
  } catch(e) { /* localStorage/vibrate may be blocked in private browsing */ }
  let sensorAccuracy = null;
  let isAbsoluteOrientation = false;
  let targetHeading = null;
  let isTrueNorth = true; // TRUE NORTH BY DEFAULT per requirements
  let magneticDeclination = 0;
  let pitch = 0;
  let roll = 0;
  let hasSensorData = false;
  let hapticsEnabled = true;
  let deferredPrompt = null;
  let lastVibrateTime = 0;
  let lastVibratedCardinal = -1;
  let lastVibratedRoomZone = null;
  let lastVibratedPada = null;

  // App Modes & Vastu State
  let compassMode = 'vastu'; // 'vastu' or 'simple'
  let zoneSystem = '8';      // '8', '16', or '32'
  let dialTheme = 'elemental'; // 'elemental', 'chakra', or 'gold'
  let currentLang = 'en';    // 'en', 'hi', 'kn', 'ta', 'te'
  let activeRoom = null;     // Selected room object from VASTU_DATA.ROOMS
  let plotTiltReading = null;// Locked wall alignment data
  let cameraStream = null;   // MediaStream for Camera AR
  let propertyType = 'residential'; // 'residential' or 'commercial'
  let retailProfile = 'apparel_silk_sarees'; // 'apparel_silk_sarees', 'jewelry_luxury', 'general_commercial'
  let roomCategoryTab = 'residential'; // 'residential' or 'commercial'
  let selectedPlotShape = 'Shermukhi';
  // v5.5.0 Field Powerhouse States
  let isHeadingFrozen = false;
  let frozenHeadingVal = null;
  let frozenCssVal = null;      // unwrapped CSS rotation held while frozen (the dial has a CSS transition: never feed it a wrapped jump)
  let lastCssHeading = 0;       // last rotation written to the dial (unwrapped, continuous)
  let tiltWarningActive = false;
  const SC = window.SensorCore; // sensor-core.js: CircularEMA, verified 32-Pada lookup, tilt hysteresis
  let isPrecisionSampling = false;
  let precisionSamples = [];
  let precisionSampleTimer = null;
  let precisionSampleCountdown = null;
  let precisionConfidenceDeg = null;
  let isArTorchOn = false;
  let isArExpanded = false;
  let siteWalkthroughLogs = [];
  try {
    const savedLogs = localStorage.getItem('kuberan_site_walkthrough_logs');
    if (savedLogs) siteWalkthroughLogs = JSON.parse(savedLogs);
  } catch(e) {}
 // 'Shermukhi', 'Gaumukhi', 'Square_Rectangular'

  // Visual Themes List (Marine Brass is base palette)
  const DIAL_THEMES = ['elemental', 'chakra', 'gold'];
  let currentDialThemeIndex = 0;
  let previewZoneSector = null; // Interactive Tap-to-Inspect sector preview
  let gpsWatchId = null;

  // Performance Cache: Prevent full DOM destruction when heading rotates within the same zone
  let cachedInspectorZone = null;
  let cachedInspectorLang = null;
  let cachedInspectorPropType = null;
  let cachedInspectorPada = null;
  let cachedInspectorRetail = null;

  // ═══ §2 DOM ════════════════════════════════════════════════════
  // All getElementById references. Future: extract to dom.js or component refs.
  const compassCard = document.getElementById('compassCard');
  const dialSvg = document.getElementById('dialSvg');
  const compassViewport = document.getElementById('compassViewport');
  const cameraFeed = document.getElementById('cameraFeed');
  const cameraScrim = document.getElementById('cameraScrim');
  const headingDegrees = document.getElementById('headingDegrees');
  const headingCardinal = document.getElementById('headingCardinal');
  const headingSanskrit = document.getElementById('headingSanskrit');
  const milsValue = document.getElementById('milsValue');
  const backAzimuthValue = document.getElementById('backAzimuthValue');
  const targetValue = document.getElementById('targetValue');
  const targetMarkerRing = document.getElementById('targetMarkerRing');
  const targetDeviationBar = document.getElementById('targetDeviationBar');
  const devArrow = document.getElementById('devArrow');
  const devText = document.getElementById('devText');
  const btnClearTarget = document.getElementById('btnClearTarget');
  const btnBearingLock = document.getElementById('btnBearingLock');
  const btnToggleNorth = document.getElementById('btnToggleNorth');
  const northPill = document.getElementById('northPill');
  const northModeLabel = document.getElementById('northModeLabel');
  const btnDialTheme = document.getElementById('btnDialTheme');
  const btnLanguage = document.getElementById('btnLanguage');
  const langPill = document.getElementById('langPill');
  const btnInfo = document.getElementById('btnInfo');
  const infoModal = document.getElementById('infoModal');
  const btnCloseModal = document.getElementById('btnCloseModal');
  const iosPermissionBanner = document.getElementById('iosPermissionBanner');
  const btnGrantSensor = document.getElementById('btnGrantSensor');
  const btnDismissSensor = document.getElementById('btnDismissSensor');
  const levelHousing = document.getElementById('levelHousing');
  const levelBubble = document.getElementById('levelBubble');
  const pitchGauge = document.getElementById('pitchGauge');
  const rollGauge = document.getElementById('rollGauge');
  const pitchValue = document.getElementById('pitchValue');
  const rollValue = document.getElementById('rollValue');
  const levelStatusCard = document.getElementById('levelStatusCard');
  const levelStatusText = document.getElementById('levelStatusText');
  const gpsLat = document.getElementById('gpsLat');
  const gpsLatDec = document.getElementById('gpsLatDec');
  const gpsLng = document.getElementById('gpsLng');
  const gpsLngDec = document.getElementById('gpsLngDec');
  const gpsAlt = document.getElementById('gpsAlt');
  const gpsAccuracy = document.getElementById('gpsAccuracy');
  const gpsDeclination = document.getElementById('gpsDeclination');
  const sensorStatus = document.getElementById('sensorStatus');
  const btnCopyCoords = document.getElementById('btnCopyCoords');
  const btnInstallApp = document.getElementById('btnInstallApp');

  // Calibration Studio Elements
  const telemetryCalibrationItem = document.getElementById('telemetryCalibrationItem');
  const sensorAccuracyBadge = document.getElementById('sensorAccuracyBadge');
  const btnCalibrate = document.getElementById('btnCalibrate');
  const calibrationModal = document.getElementById('calibrationModal');
  const btnCloseCalModal = document.getElementById('btnCloseCalModal');
  const calSensorBadge = document.getElementById('calSensorBadge');
  const calAccuracyText = document.getElementById('calAccuracyText');
  const calActiveOffsetVal = document.getElementById('calActiveOffsetVal');
  const calOffsetBadge = document.getElementById('calOffsetBadge');
  const btnOffsetMinus5 = document.getElementById('btnOffsetMinus5');
  const btnOffsetMinus1 = document.getElementById('btnOffsetMinus1');
  const btnOffsetReset = document.getElementById('btnOffsetReset');
  const btnOffsetPlus1 = document.getElementById('btnOffsetPlus1');
  const btnOffsetPlus5 = document.getElementById('btnOffsetPlus5');
  const btnZeroToNorth = document.getElementById('btnZeroToNorth');
  const toast = document.getElementById('toast');

  // Vastu Mode Switcher & Controls Elements
  const btnModeVastu = document.getElementById('btnModeVastu');
  const btnModeSimple = document.getElementById('btnModeSimple');
  const vastuSubcontrols = document.getElementById('vastuSubcontrols');
  const btnZone8 = document.getElementById('btnZone8');
  const btnZone16 = document.getElementById('btnZone16');
  const btnZone32 = document.getElementById('btnZone32');
  const btnToolRoomFinder = document.getElementById('btnToolRoomFinder');
  const btnToolPlotTilt = document.getElementById('btnToolPlotTilt');
  const btnToolAudit = document.getElementById('btnToolAudit');
  const vastuInspectorSection = document.getElementById('vastuInspectorSection');

  // Commercial & Retail Elements
  const btnPropResidential = document.getElementById('btnPropResidential');
  const btnPropCommercial = document.getElementById('btnPropCommercial');
  const retailProfileStrip = document.getElementById('retailProfileStrip');
  const chipProfileApparel = document.getElementById('chipProfileApparel');
  const chipProfileJewelry = document.getElementById('chipProfileJewelry');
  const chipProfileGeneral = document.getElementById('chipProfileGeneral');
  const commercialInspectorBox = document.getElementById('commercialInspectorBox');
  const inspCommSuitability = document.getElementById('inspCommSuitability');
  const inspBusinessImpact = document.getElementById('inspBusinessImpact');
  const roomFinderCategoryTabs = document.getElementById('roomFinderCategoryTabs');
  const tabResRooms = document.getElementById('tabResRooms');
  const tabCommRooms = document.getElementById('tabCommRooms');
  const plotShapeSelectorGrid = document.getElementById('plotShapeSelectorGrid');
  const plotShapeBadge = document.getElementById('plotShapeBadge');
  const plotShapeAdviceText = document.getElementById('plotShapeAdviceText');
  const reportPropertyType = document.getElementById('reportPropertyType');
  const reportCategoryRow = document.getElementById('reportCategoryRow');
  const reportBusinessCategory = document.getElementById('reportBusinessCategory');
  const reportPlotShapeRow = document.getElementById('reportPlotShapeRow');
  const reportPlotShape = document.getElementById('reportPlotShape');
  const commercialChecklistBox = document.getElementById('commercialChecklistBox');
  const inspZoneBadge = document.getElementById('inspZoneBadge');
  const inspZoneName = document.getElementById('inspZoneName');
  const inspSanskrit = document.getElementById('inspSanskrit');
  const inspElementDot = document.getElementById('inspElementDot');
  const inspElementName = document.getElementById('inspElementName');
  const inspDeityVal = document.getElementById('inspDeityVal');
  const inspSummaryText = document.getElementById('inspSummaryText');
  const favorableTags = document.getElementById('favorableTags');
  const avoidTags = document.getElementById('avoidTags');
  const inspTipText = document.getElementById('inspTipText');
  const padaEntranceCard = document.getElementById('padaEntranceCard');
  const padaIdBadge = document.getElementById('padaIdBadge');
  const padaDevataName = document.getElementById('padaDevataName');
  const padaGradePill = document.getElementById('padaGradePill');
  const padaEffectText = document.getElementById('padaEffectText');

  // Guidance Banner Elements
  const roomGuidanceBanner = document.getElementById('roomGuidanceBanner');
  const guideRoomIcon = document.getElementById('guideRoomIcon');
  const guideRoomName = document.getElementById('guideRoomName');
  const guideTargetBadge = document.getElementById('guideTargetBadge');
  const guideStatusText = document.getElementById('guideStatusText');
  const btnCloseRoomGuide = document.getElementById('btnCloseRoomGuide');

  // Modals Elements
  const langModal = document.getElementById('langModal');
  const btnCloseLangModal = document.getElementById('btnCloseLangModal');
  const langOptionsList = document.getElementById('langOptionsList');
  const roomFinderModal = document.getElementById('roomFinderModal');
  const btnCloseRoomModal = document.getElementById('btnCloseRoomModal');
  const roomsGrid = document.getElementById('roomsGrid');
  const plotTiltModal = document.getElementById('plotTiltModal');
  const btnCloseTiltModal = document.getElementById('btnCloseTiltModal');
  const plotHeadingVal = document.getElementById('plotHeadingVal');
  const plotDeviationVal = document.getElementById('plotDeviationVal');
  const plotStatusBanner = document.getElementById('plotStatusBanner');
  const plotStatusTitle = document.getElementById('plotStatusTitle');
  const plotStatusDesc = document.getElementById('plotStatusDesc');
  const btnLockPlotTilt = document.getElementById('btnLockPlotTilt');
  const auditModal = document.getElementById('auditModal');
  const btnCloseAuditModal = document.getElementById('btnCloseAuditModal');
  const reportTimestamp = document.getElementById('reportTimestamp');
  const reportHeading = document.getElementById('reportHeading');
  const reportZone = document.getElementById('reportZone');
  const reportElement = document.getElementById('reportElement');
  const reportDeity = document.getElementById('reportDeity');
  const reportGps = document.getElementById('reportGps');
  const reportDoor = document.getElementById('reportDoor');
  const reportPlot = document.getElementById('reportPlot');
  const reportAdvice = document.getElementById('reportAdvice');
  const btnCopyAuditReport = document.getElementById('btnCopyAuditReport');
  const btnShareAuditReport = document.getElementById('btnShareAuditReport');

  // --- Robust Compass Heading from W3C Euler angles (alpha, beta, gamma) ---
  // BUG FIXED (v4.6.2): the previous formula returned the direction of the phone's
  // BACK (-Z axis). Held flat (the normal way to use a compass) the back points at the
  // floor, so its horizontal projection is ~0 and the heading swung by up to 90-180°
  // with a 1-2° hand tilt (and jumped at the 0.5° flat/tilted switch).
  //
  // Correct behaviour:
  //   * phone flat / slightly tilted  -> heading of the SCREEN-TOP edge  (tilt-immune)
  //   * phone upright (camera / AR)   -> heading of the REAR CAMERA axis
  //   * smooth blend between the two  -> no jumps while raising or lowering the phone
  // Screen rotation (portrait/landscape) is handled here, so callers must NOT add it again.
  function computeHeadingFromEuler(alpha, beta, gamma, screenAngle) {
    const D = Math.PI / 180;
    const a = alpha * D, b = beta * D, g = gamma * D;
    const cA = Math.cos(a), sA = Math.sin(a);
    const cB = Math.cos(b), sB = Math.sin(b);
    const cG = Math.cos(g), sG = Math.sin(g);

    // Device axes in the Earth frame (east, north). R = Rz(alpha) · Rx(beta) · Ry(gamma)
    const axisX    = { e: cA * cG - sA * sB * sG, n: cG * sA + cA * sB * sG };   // device right
    const axisY    = { e: -cB * sA,               n: cA * cB };                  // device top edge
    const axisRear = { e: -(cA * sG + cG * sA * sB), n: -(sA * sG - cA * cG * sB) }; // -Z (rear camera)

    // Which device axis is the top of the *screen* right now?
    const quarter = ((Math.round((screenAngle || 0) / 90) % 4) + 4) % 4;
    const top = [axisY, axisX, { e: -axisY.e, n: -axisY.n }, { e: -axisX.e, n: -axisX.n }][quarter];

    // 1 = lying flat face-up, 0 = upright
    const flatness = cB * cG;
    const t = Math.min(1, Math.max(0, (flatness - 0.35) / 0.40));
    const wTop = t * t * (3 - 2 * t); // smoothstep: 0 (upright) .. 1 (flat)

    const unit = (v) => {
      const m = Math.hypot(v.e, v.n);
      return m < 1e-6 ? null : { e: v.e / m, n: v.n / m };
    };
    const uTop = unit(top);
    const uRear = unit(axisRear);

    let e = 0, n = 0;
    if (uTop && wTop > 0) { e += uTop.e * wTop; n += uTop.n * wTop; }
    if (uRear && wTop < 1) {
      // never blend two opposite vectors (phone tipped top-down): align rear with top first
      const sign = (uTop && wTop > 0 && (uTop.e * uRear.e + uTop.n * uRear.n) < 0) ? -1 : 1;
      e += sign * uRear.e * (1 - wTop);
      n += sign * uRear.n * (1 - wTop);
    }
    if (e === 0 && n === 0) return null;

    let heading = Math.atan2(e, n) / D;
    return heading < 0 ? heading + 360 : heading;
  }


/**
 * Vastu Compass Smooth & Freeze Engine
 * Solves endless jittering on stationary devices.
 */
  // ═══ §4 STABILIZER ════════════════════════════════════════════
  // RAF-based smooth heading interpolation with deadzone & lock.
  // Future: extract to CompassStabilizer.js class module.
class CompassStabilizer {
    constructor(options = {}) {
        this.alpha = options.alpha || 0.15;
        this.deadzone = options.deadzone || 0.8;
        this.lockThreshold = options.lockThreshold || 1.2;
        this.lockDuration = options.lockDuration || 2000;
        // Hold band: while locked, the display only stays put if the target is within this many degrees of it.
        // Without it a slow steady turn (samples agree with each other) never released the lock and the
        // display froze while the phone rotated: error grew without bound (measured 5° after 10 s at 0.5°/s).
        this.lockRelease = options.lockRelease || 0.25;
        
        this.currentHeading = null;
        this.targetHeading = null;
        this.lastRenderedHeading = 0;
        
        this.motionHistory = [];
        this.isLocked = false;
        this.animFrameId = null;

        this.onHeadingChange = options.onHeadingChange || null;
    }

        updateRawHeading(rawHeading) {
        if (typeof rawHeading !== 'number' || isNaN(rawHeading)) return;

        let normalized = (rawHeading % 360 + 360) % 360;

        if (this.currentHeading === null) {
            this.currentHeading = normalized;
            this.targetHeading = normalized;
            if (this.onHeadingChange) this.onHeadingChange(this.currentHeading);
            return;
        }

        let sensorDelta = this.getShortestAngleDelta(this.targetHeading, normalized);
        if (Math.abs(sensorDelta) < this.deadzone) {
            this.checkStationaryStatus(normalized);
            return;
        }

        this.targetHeading = normalized;
        this.checkStationaryStatus(normalized);

        if (!this.animFrameId) {
            this.animFrameId = requestAnimationFrame(() => this.processLoop());
        }
    }

    getShortestAngleDelta(from, to) {
        from = (from % 360 + 360) % 360;
        to = (to % 360 + 360) % 360;
        let diff = (to - from + 180) % 360 - 180;
        return diff < -180 ? diff + 360 : diff;
    }

    stop() {
        if (this.animFrameId) { cancelAnimationFrame(this.animFrameId); this.animFrameId = null; }
    }

    // Forget all history so the next sample seeds the filter directly (first fix / resume from background)
    reset() {
        this.stop();
        this.currentHeading = null;
        this.targetHeading = null;
        this.lastRenderedHeading = 0;
        this.motionHistory = [];
        this.isLocked = false;
    }

    checkStationaryStatus(heading) {
        const now = Date.now();
        this.motionHistory.push({ heading, time: now });
        this.motionHistory = this.motionHistory.filter(item => now - item.time <= this.lockDuration);

        if (this.motionHistory.length > 5) {
            const headings = this.motionHistory.map(m => m.heading);
            let minDelta = 0;
            let maxDelta = 0;
            const ref = headings[0];
            for (let i = 1; i < headings.length; i++) {
                let d = this.getShortestAngleDelta(ref, headings[i]);
                if (d < minDelta) minDelta = d;
                if (d > maxDelta) maxDelta = d;
            }
            const totalSpread = maxDelta - minDelta;
            const stale = this.currentHeading !== null
                ? Math.abs(this.getShortestAngleDelta(this.currentHeading, heading))
                : 0;
            this.isLocked = totalSpread < this.lockThreshold && stale <= this.lockRelease;
        }
    }

        processLoop() {
        if (this.isLocked) {
            const stale = Math.abs(this.getShortestAngleDelta(this.currentHeading, this.targetHeading));
            if (stale <= this.lockRelease) {
                this.animFrameId = null;
                return;
            }
            this.isLocked = false; // display is stale beyond the hold band: follow the phone again
        }

        let delta = this.getShortestAngleDelta(this.currentHeading, this.targetHeading);

        // Snap to target if very close to save CPU
        if (Math.abs(delta) < 0.1) {
            this.currentHeading = this.currentHeading + delta;
            if (Math.abs(this.currentHeading - this.lastRenderedHeading) >= 0.1) {
                this.lastRenderedHeading = this.currentHeading;
                if (this.onHeadingChange) this.onHeadingChange(this.currentHeading);
            }
            this.animFrameId = null;
            return;
        }

        // Accumulate angle to prevent CSS backward spinning (Tilt-Aware Weighting: dampen when tilted)
        const arOverlayEl = document.getElementById('arFullscreenOverlay');
        const isArMode = arOverlayEl && !arOverlayEl.classList.contains('hidden');
        const flatTilt = Math.max(Math.abs(pitch || 0), Math.abs(roll || 0));
        let effectiveAlpha = this.alpha;
        if (!isArMode) {
            if (flatTilt <= 3) effectiveAlpha = 0.16;       // Crisp response when held flat & level
            else if (flatTilt <= 10) effectiveAlpha = 0.12; // Normal hand-held damping
            else if (flatTilt <= 20) effectiveAlpha = 0.06; // Heavy damping against Z-axis rebar leakage
            else effectiveAlpha = 0.035;                    // Maximum protection when steeply tilted
        }
        this.currentHeading = this.currentHeading + delta * effectiveAlpha;

        if (Math.abs(this.currentHeading - this.lastRenderedHeading) >= 0.1) {
            this.lastRenderedHeading = this.currentHeading;
            if (this.onHeadingChange) {
                this.onHeadingChange(this.currentHeading);
            }
        }

        this.animFrameId = requestAnimationFrame(() => this.processLoop());
    }
}

const stabilizer = new CompassStabilizer({
    alpha: 0.12,
    deadzone: 0.2,
    lockThreshold: 1.2,
    onHeadingChange: (smoothedH) => {
        smoothedHeading = smoothedH;
        if (isHeadingFrozen && frozenHeadingVal !== null) {
          if (frozenCssVal !== null) { updateHeadingUI(frozenCssVal); return; }
          updateHeadingUI(frozenHeadingVal);
          return;
        }
        let calibratedHeading = smoothedHeading + calibrationOffset;
        let trueHeading = calibratedHeading;
        if (isTrueNorth) {
          trueHeading = calibratedHeading + magneticDeclination;
        }
        updateHeadingUI(trueHeading);
    }
});

  // ═══ §3 MATH ═══════════════════════════════════════════════════
  // Pure math functions. Future: extract to math.js utility module.
  // ── v5.8.0: circular (sin/cos) EMA pre-filter ─────────────────────────
  // Raw headings are averaged as unit vectors: s += a(sin θ − s), c += a(cos θ − c), θ = atan2(s, c).
  // The output is wrapped to [0, 360); CompassStabilizer then accumulates the SHORTEST delta into an
  // unwrapped angle, which is what drives the dial's CSS rotate() (it has a transition, so it must never wrap).
  const headingFilter = new SC.CircularEMA({ alpha: 0.3 });

  function isArFullscreenOpen() {
    const el = document.getElementById('arFullscreenOverlay');
    return !!(el && !el.classList.contains('hidden'));
  }

  // Heavier damping when tilted (cross-axis magnetometer leakage); responsive when upright in AR.
  function headingFilterGain() {
    if (isArFullscreenOpen()) return 0.4;
    const t = Math.max(Math.abs(pitch || 0), Math.abs(roll || 0));
    if (t <= 3) return 0.35;
    if (t <= 10) return 0.28;
    if (t <= SC.TILT_WARN_DEG) return 0.2;
    return 0.12;
  }

  function resetHeadingFilters() {
    headingFilter.reset();
    stabilizer.reset();
    smoothedHeading = null;
  }

  // --- Angle Smoothing Helper (handles 0°/360° phase wrap-around) ---
  function smoothAngle(prev, target, factor) {
    if (prev === null) return target;
    // Calculate shortest angular distance to target, keeping prev as an accumulated value
    let prevDisplay = ((prev % 360) + 360) % 360;
    let diff = (target - prevDisplay + 540) % 360 - 180;
    return prev + diff * factor;
  }

  // --- Helper: Degree Normalizer ---
  function normalizeAngle(angle) {
    const a = SC.normalizeDeg(angle);
    return a;
  }

  // --- Helper: WGS84 Declination Estimator ---
  function estimateMagneticDeclination(latitude, longitude) {
    if (isNaN(latitude) || isNaN(longitude)) return 0;
    
    // 1. High-Precision World Magnetic Model (WMM)
    if (typeof geomagnetism !== 'undefined') {
      try {
        const info = geomagnetism.model().point([latitude, longitude]);
        if (info && typeof info.decl !== 'undefined') {
          return parseFloat(info.decl.toFixed(2));
        }
      } catch (err) {
        console.error('WMM calculation failed, using fallback', err);
      }
    }

    // 2. Fallback: Crude linear approximation for Indian subcontinent
    if (latitude >= 6 && latitude <= 38 && longitude >= 68 && longitude <= 98) {
      const latFraction = (latitude - 8) / 30;
      const lngFraction = (longitude - 77) / 20;
      return parseFloat((-0.5 + latFraction * 0.8 - lngFraction * 1.2).toFixed(1));
    }
    return 0.0;
  }

  // --- Helper: Format Degrees to DMS ---
  function formatDMS(dec, isLat) {
    if (isNaN(dec)) return '--° --\' --"';
    const dir = isLat ? (dec >= 0 ? 'N' : 'S') : (dec >= 0 ? 'E' : 'W');
    const absVal = Math.abs(dec);
    const deg = Math.floor(absVal);
    const minDec = (absVal - deg) * 60;
    const min = Math.floor(minDec);
    const sec = Math.round((minDec - min) * 60);
    return `${deg}° ${min}' ${sec}" ${dir}`;
  }

  // --- Helper: Format Milliseconds / Date ---
  
  // --- Solar Azimuth & Elevation (NOAA Solar Model) ---
  function calculateSunPosition(latitude, longitude, date = new Date()) {
    const lat = isNaN(latitude) ? 12.9716 : latitude;
    const lng = isNaN(longitude) ? 77.5946 : longitude;
    const rad = Math.PI / 180;
    const deg = 180 / Math.PI;

    const time = date.getTime();
    const jd = (time / 86400000) + 2440587.5;
    const n = jd - 2451545.0;

    const L = (280.460 + 0.9856474 * n) % 360;
    const g = ((357.528 + 0.9856003 * n) % 360) * rad;
    const lambda = (L + 1.915 * Math.sin(g) + 0.020 * Math.sin(2 * g)) * rad;
    const epsilon = (23.439 - 0.0000004 * n) * rad;

    const sinAlpha = Math.cos(epsilon) * Math.sin(lambda);
    const cosAlpha = Math.cos(lambda);
    const alpha = Math.atan2(sinAlpha, cosAlpha);
    const delta = Math.asin(Math.sin(epsilon) * Math.sin(lambda));

    const gmst = (18.697374558 + 24.06570982441908 * n) % 24;
    const lmst = ((gmst * 15 + lng) % 360) * rad;

    const H = lmst - alpha;
    const phi = lat * rad;

    const sinAlt = Math.sin(phi) * Math.sin(delta) + Math.cos(phi) * Math.cos(delta) * Math.cos(H);
    const alt = Math.asin(Math.max(-1, Math.min(1, sinAlt)));

    const sinAz = -Math.cos(delta) * Math.sin(H) / Math.cos(alt);
    const cosAz = (Math.sin(delta) - Math.sin(phi) * Math.sin(alt)) / (Math.cos(phi) * Math.cos(alt));
    let az = Math.atan2(sinAz, cosAz) * deg;
    if (az < 0) az += 360;

    return {
      azimuth: Math.round(az * 10) / 10,
      altitude: Math.round(alt * deg * 10) / 10,
      isDay: alt > 0
    };
  }

  // --- Vedic Rahu Kalam & Muhurta Calculator ---
  function getVedicMuhurta(date = new Date()) {
    const dayOfWeek = date.getDay(); // 0 = Sun, 1 = Mon ...
    const hour = date.getHours() + date.getMinutes() / 60;
    const rahuOctants = [8, 2, 7, 5, 6, 4, 3];
    const octant = rahuOctants[dayOfWeek];
    const rahuStart = 6.0 + (octant - 1) * 1.5;
    const rahuEnd = rahuStart + 1.5;

    const isRahuKalam = hour >= rahuStart && hour < rahuEnd;
    const isAbhijit = hour >= 11.6 && hour <= 12.4; // Midday Solar Peak

    function fmt(h) {
      const hrs = Math.floor(h);
      const mins = Math.round((h - hrs) * 60);
      const period = hrs >= 12 ? 'PM' : 'AM';
      const dispHrs = hrs % 12 || 12;
      return dispHrs + ':' + (mins < 10 ? '0' : '') + mins + ' ' + period;
    }

    return {
      isRahuKalam,
      isAbhijit,
      rahuPeriodText: fmt(rahuStart) + ' – ' + fmt(rahuEnd),
      statusLabel: isRahuKalam
        ? '⚠️ Rahu Kalam (' + fmt(rahuStart) + '-' + fmt(rahuEnd) + ')'
        : (isAbhijit ? '🌟 Abhijit Muhurta (Solar Peak)' : '✨ Auspicious Solar Alignment')
    };
  }

  function formatCurrentTimestamp() {
    const now = new Date();
    return now.toLocaleString('en-IN', {
      dateStyle: 'medium',
      timeStyle: 'medium'
    });
  }

  // ═══ §5 VASTU_ENGINE ══════════════════════════════════════════
  // Zone lookups and SVG dial rendering.
  // Future: extract zone lookups to vastu.js, dial rendering to DialRenderer.js.
  // --- Vastu Calculations Engine ---
  function getActiveZone8(heading) {
    const h = normalizeAngle(heading);
    for (const z of VASTU_DATA.ZONES_8) {
      if (z.startDeg > z.endDeg) {
        // Wrap-around North (337.5° to 22.5°)
        if (h >= z.startDeg || h < z.endDeg) return z;
      } else {
        if (h >= z.startDeg && h < z.endDeg) return z;
      }
    }
    return VASTU_DATA.ZONES_8[0];
  }

  function getActiveZone16(heading) {
    const h = normalizeAngle(heading);
    for (const z of VASTU_DATA.ZONES_16) {
      if (z.startDeg > z.endDeg) {
        if (h >= z.startDeg || h < z.endDeg) return z;
      } else {
        if (h >= z.startDeg && h < z.endDeg) return z;
      }
    }
    return VASTU_DATA.ZONES_16[0];
  }

  // 32-Pada lookup: O(1) index, table verified once at startup (11.25° each, contiguous from 45°).
  // If the table were ever corrupted we log loudly and fall back to the legacy linear scan.
  const PADA32_VERIFIED = (function () {
    const r = SC.verifyPadaTable(VASTU_DATA.PADAS_32);
    if (!r.ok) console.error('PADAS_32 verification failed:', r.errors);
    return r.ok;
  })();

  function getActivePada32(heading) {
    const h = normalizeAngle(heading);
    if (PADA32_VERIFIED) return VASTU_DATA.PADAS_32[SC.getPadaIndex(h)];
    for (const p of VASTU_DATA.PADAS_32) {
      if (p.startDeg > p.endDeg) {
        if (h >= p.startDeg || h < p.endDeg) return p;
      } else {
        if (h >= p.startDeg && h < p.endDeg) return p;
      }
    }
    return VASTU_DATA.PADAS_32[0];
  }

  function getActiveAntarDevata(heading) {
    const h = normalizeAngle(heading);
    if (!VASTU_DATA.ANTAR_DEVATAS_12) return null;
    for (const d of VASTU_DATA.ANTAR_DEVATAS_12) {
      if (d.startDeg > d.endDeg) {
        if (h >= d.startDeg || h < d.endDeg) return d;
      } else {
        if (h >= d.startDeg && h < d.endDeg) return d;
      }
    }
    return VASTU_DATA.ANTAR_DEVATAS_12[0];
  }

  // --- Build Dial Vector SVG ---
  function buildDialSvg() {
    const cx = 250;
    const cy = 250;
    const rOuter = 240;
    let svgContent = '';
    const toggleGrid = document.getElementById('toggle-vastu-grid');
    const showGrid = toggleGrid && toggleGrid.checked;

    if (false /* compassMode === 'simple' — removed: app locked to Vastu mode */) {
      // SIMPLE COMPASS DIAL — Dead code, kept for reference
      svgContent += `<circle cx="${cx}" cy="${cy}" r="${rOuter}" fill="none" stroke="currentColor" stroke-opacity="0.25" stroke-width="2"/>`;
      svgContent += `<circle cx="${cx}" cy="${cy}" r="${rOuter - 18}" fill="none" stroke="currentColor" stroke-opacity="0.12" stroke-width="1"/>`;
      svgContent += `<circle cx="${cx}" cy="${cy}" r="116" fill="none" stroke="currentColor" stroke-opacity="0.15" stroke-width="1" stroke-dasharray="4,4"/>`;

      // Degree Ticks (Every 2°, 10°, 30°)
      for (let deg = 0; deg < 360; deg += 2) {
        const rad = (deg - 90) * (Math.PI / 180);
        const is30 = deg % 30 === 0;
        const is10 = deg % 10 === 0;

        let tickLen = 7;
        let strokeWidth = 1;
        let strokeOpacity = 0.35;

        if (is30) {
          tickLen = 16;
          strokeWidth = 2.5;
          strokeOpacity = 0.9;
        } else if (is10) {
          tickLen = 12;
          strokeWidth = 1.5;
          strokeOpacity = 0.6;
        }

        const x1 = cx + (rOuter - 2) * Math.cos(rad);
        const y1 = cy + (rOuter - 2) * Math.sin(rad);
        const x2 = cx + (rOuter - 2 - tickLen) * Math.cos(rad);
        const y2 = cy + (rOuter - 2 - tickLen) * Math.sin(rad);

        const strokeColor = (deg === 0) ? 'var(--accent-north)' : 'currentColor';
        svgContent += `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="${strokeColor}" stroke-width="${strokeWidth}" stroke-opacity="${strokeOpacity}"/>`;

        // Degree Numbers (every 30°, skipping cardinal positions)
        if (is30 && deg % 90 !== 0) {
          const textR = rOuter - 29;
          const tx = cx + textR * Math.cos(rad);
          const ty = cy + textR * Math.sin(rad);
          svgContent += `<text x="${tx.toFixed(1)}" y="${ty.toFixed(1)}" text-anchor="middle" dominant-baseline="central" font-size="11" font-weight="600" fill="currentColor" fill-opacity="0.7" transform="rotate(${deg}, ${tx.toFixed(1)}, ${ty.toFixed(1)})">${deg}</text>`;
        }
      }

      // Compass Rose 8-Point Star
      svgContent += `
        <g class="compass-rose-star" opacity="0.85">
          <polygon points="${cx},${cy - 120} ${cx + 12},${cy - 20} ${cx},${cy}" fill="var(--accent-north)" />
          <polygon points="${cx},${cy - 120} ${cx - 12},${cy - 20} ${cx},${cy}" fill="rgba(239, 68, 68, 0.4)" />
          <polygon points="${cx},${cy + 120} ${cx - 12},${cy + 20} ${cx},${cy}" fill="var(--accent-cyan)" opacity="0.9" />
          <polygon points="${cx},${cy + 120} ${cx + 12},${cy + 20} ${cx},${cy}" fill="var(--accent-cyan)" opacity="0.4" />
          <polygon points="${cx + 120},${cy} ${cx + 20},${cy + 12} ${cx},${cy}" fill="var(--accent-cyan)" opacity="0.9" />
          <polygon points="${cx + 120},${cy} ${cx + 20},${cy - 12} ${cx},${cy}" fill="var(--accent-cyan)" opacity="0.4" />
          <polygon points="${cx - 120},${cy} ${cx - 20},${cy - 12} ${cx},${cy}" fill="var(--accent-cyan)" opacity="0.9" />
          <polygon points="${cx - 120},${cy} ${cx - 20},${cy + 12} ${cx},${cy}" fill="var(--accent-cyan)" opacity="0.4" />
          <polygon points="${cx + 80},${cy - 80} ${cx + 14},${cy - 14} ${cx},${cy}" fill="var(--accent-cyan)" opacity="0.65" />
          <polygon points="${cx + 80},${cy + 80} ${cx + 14},${cy + 14} ${cx},${cy}" fill="var(--accent-cyan)" opacity="0.65" />
          <polygon points="${cx - 80},${cy + 80} ${cx - 14},${cy + 14} ${cx},${cy}" fill="var(--accent-cyan)" opacity="0.65" />
          <polygon points="${cx - 80},${cy - 80} ${cx - 14},${cy - 14} ${cx},${cy}" fill="var(--accent-cyan)" opacity="0.65" />
        </g>
      `;

      // Cardinal & Intercardinal Typography
      const cardinals = [
        { label: 'N', deg: 0, r: rOuter - 32, size: 24, weight: '800', color: 'var(--accent-north)', hasDeg: false },
        { label: 'E', deg: 90, r: rOuter - 32, size: 22, weight: '700', color: 'currentColor', hasDeg: true, degNum: '90' },
        { label: 'S', deg: 180, r: rOuter - 32, size: 22, weight: '700', color: 'currentColor', hasDeg: true, degNum: '180' },
        { label: 'W', deg: 270, r: rOuter - 32, size: 22, weight: '700', color: 'currentColor', hasDeg: true, degNum: '270' },
        { label: 'NE', deg: 45, r: rOuter - 29, size: 13, weight: '600', color: 'currentColor', hasDeg: false },
        { label: 'SE', deg: 135, r: rOuter - 29, size: 13, weight: '600', color: 'currentColor', hasDeg: false },
        { label: 'SW', deg: 225, r: rOuter - 29, size: 13, weight: '600', color: 'currentColor', hasDeg: false },
        { label: 'NW', deg: 315, r: rOuter - 29, size: 13, weight: '600', color: 'currentColor', hasDeg: false }
      ];

      cardinals.forEach(c => {
        const rad = (c.deg - 90) * (Math.PI / 180);
        const tx = cx + c.r * Math.cos(rad);
        const ty = cy + c.r * Math.sin(rad);
        svgContent += `<text x="${tx.toFixed(1)}" y="${ty.toFixed(1)}" text-anchor="middle" dominant-baseline="central" font-size="${c.size}" font-weight="${c.weight}" fill="${c.color}" transform="rotate(${c.deg}, ${tx.toFixed(1)}, ${ty.toFixed(1)})">${c.label}</text>`;
        if (c.hasDeg) {
          const numR = c.r - 18;
          const nx = cx + numR * Math.cos(rad);
          const ny = cy + numR * Math.sin(rad);
          svgContent += `<text x="${nx.toFixed(1)}" y="${ny.toFixed(1)}" text-anchor="middle" dominant-baseline="central" font-size="11" font-weight="600" fill="currentColor" fill-opacity="0.7" transform="rotate(${c.deg}, ${nx.toFixed(1)}, ${ny.toFixed(1)})">${c.degNum}</text>`;
        }
      });

    } else {
      // -------------------------------------------------------------
      // VASTU COMPASS DIAL (8 Zones / 16 Zones / 32 Padas)
      // -------------------------------------------------------------
      const rInnerVastu = 130;
      const rOuterVastu = 236;

      // Concentric Rings
      svgContent += `<circle cx="${cx}" cy="${cy}" r="${rOuter}" fill="none" stroke="currentColor" stroke-opacity="0.25" stroke-width="2"/>`;
      svgContent += `<circle cx="${cx}" cy="${cy}" r="${rOuterVastu}" fill="none" stroke="currentColor" stroke-opacity="0.3" stroke-width="1.5"/>`;
      svgContent += `<circle cx="${cx}" cy="${cy}" r="${rInnerVastu}" fill="none" stroke="currentColor" stroke-opacity="0.25" stroke-width="1.5"/>`;
      svgContent += `<circle cx="${cx}" cy="${cy}" r="116" fill="none" stroke="currentColor" stroke-opacity="0.15" stroke-width="1" stroke-dasharray="4,4"/>`;

      if (zoneSystem === '8') {
        // --- 8 ZONES (Ashta Dikpala) ---
        VASTU_DATA.ZONES_8.forEach((zone) => {
          const elem = VASTU_DATA.ELEMENTS[zone.element];
          const startRad = (zone.startDeg - 90) * (Math.PI / 180);
          const endRad = (zone.endDeg - 90) * (Math.PI / 180);
          const centerRad = (zone.centerDeg - 90) * (Math.PI / 180);

          // Sector divider ray
          const sx = cx + rOuterVastu * Math.cos(startRad);
          const sy = cy + rOuterVastu * Math.sin(startRad);
          const ex = cx + rInnerVastu * Math.cos(startRad);
          const ey = cy + rInnerVastu * Math.sin(startRad);
          svgContent += `<line x1="${ex.toFixed(1)}" y1="${ey.toFixed(1)}" x2="${sx.toFixed(1)}" y2="${sy.toFixed(1)}" stroke="currentColor" stroke-opacity="0.35" stroke-width="1.2"/>`;

          // Sector arc band (outer rim)
          const arcX1 = cx + (rOuterVastu - 4) * Math.cos(startRad);
          const arcY1 = cy + (rOuterVastu - 4) * Math.sin(startRad);
          const arcX2 = cx + (rOuterVastu - 4) * Math.cos(endRad);
          const arcY2 = cy + (rOuterVastu - 4) * Math.sin(endRad);
          svgContent += `<path d="M ${arcX1.toFixed(1)} ${arcY1.toFixed(1)} A ${rOuterVastu - 4} ${rOuterVastu - 4} 0 0 1 ${arcX2.toFixed(1)} ${arcY2.toFixed(1)}" fill="none" stroke="${elem.color}" stroke-width="6" stroke-opacity="0.85" class="vastu-sector-ring vastu-sector-clickable" data-zone-code="${zone.code}"/>`;

          // Sector fill for Chakra Theme
          if (dialTheme === 'chakra') {
            const ix1 = cx + rInnerVastu * Math.cos(startRad);
            const iy1 = cy + rInnerVastu * Math.sin(startRad);
            const ix2 = cx + rInnerVastu * Math.cos(endRad);
            const iy2 = cy + rInnerVastu * Math.sin(endRad);
            svgContent += `<path d="M ${ix1.toFixed(1)} ${iy1.toFixed(1)} L ${arcX1.toFixed(1)} ${arcY1.toFixed(1)} A ${rOuterVastu - 4} ${rOuterVastu - 4} 0 0 1 ${arcX2.toFixed(1)} ${arcY2.toFixed(1)} L ${ix2.toFixed(1)} ${iy2.toFixed(1)} A ${rInnerVastu} ${rInnerVastu} 0 0 0 ${ix1.toFixed(1)} ${iy1.toFixed(1)} Z" fill="${elem.color}" fill-opacity="0.22" class="vastu-sector-fill"/>`;
          }

          // Direction Label & Sanskrit Name
          const textR = rOuterVastu - 24;
          const tx = cx + textR * Math.cos(centerRad);
          const ty = cy + textR * Math.sin(centerRad);
          const textColor = (zone.code === 'N') ? 'var(--accent-north)' : 'currentColor';

          svgContent += `<text x="${tx.toFixed(1)}" y="${ty.toFixed(1)}" text-anchor="middle" dominant-baseline="central" font-size="15" font-weight="800" fill="${textColor}" class="vastu-zone-text" transform="rotate(${zone.centerDeg}, ${tx.toFixed(1)}, ${ty.toFixed(1)})">${zone.code}</text>`;

          const sanskritR = textR - 18;
          const sxTxt = cx + sanskritR * Math.cos(centerRad);
          const syTxt = cy + sanskritR * Math.sin(centerRad);
          const sanskritShort = zone.sanskrit.split(' ')[0]; // E.g., 'Īśānya'
          svgContent += `<text x="${sxTxt.toFixed(1)}" y="${syTxt.toFixed(1)}" text-anchor="middle" dominant-baseline="central" font-size="9" font-weight="600" fill="${elem.color}" transform="rotate(${zone.centerDeg}, ${sxTxt.toFixed(1)}, ${syTxt.toFixed(1)})">${sanskritShort}</text>`;
        });

      } else if (zoneSystem === '16') {
        // --- 16 MAHAVASTU ZONES (22.5° each) ---
        VASTU_DATA.ZONES_16.forEach((zone) => {
          const elem = VASTU_DATA.ELEMENTS[zone.element];
          const startRad = (zone.startDeg - 90) * (Math.PI / 180);
          const endRad = (zone.endDeg - 90) * (Math.PI / 180);
          const centerRad = (zone.centerDeg - 90) * (Math.PI / 180);

          // Divider
          const sx = cx + rOuterVastu * Math.cos(startRad);
          const sy = cy + rOuterVastu * Math.sin(startRad);
          const ex = cx + rInnerVastu * Math.cos(startRad);
          const ey = cy + rInnerVastu * Math.sin(startRad);
          svgContent += `<line x1="${ex.toFixed(1)}" y1="${ey.toFixed(1)}" x2="${sx.toFixed(1)}" y2="${sy.toFixed(1)}" stroke="currentColor" stroke-opacity="0.3" stroke-width="1"/>`;

          // Outer colored arc
          const arcX1 = cx + (rOuterVastu - 3) * Math.cos(startRad);
          const arcY1 = cy + (rOuterVastu - 3) * Math.sin(startRad);
          const arcX2 = cx + (rOuterVastu - 3) * Math.cos(endRad);
          const arcY2 = cy + (rOuterVastu - 3) * Math.sin(endRad);
          svgContent += `<path d="M ${arcX1.toFixed(1)} ${arcY1.toFixed(1)} A ${rOuterVastu - 3} ${rOuterVastu - 3} 0 0 1 ${arcX2.toFixed(1)} ${arcY2.toFixed(1)}" fill="none" stroke="${elem.color}" stroke-width="5" stroke-opacity="0.85" class="vastu-sector-ring vastu-sector-clickable" data-zone-code="${zone.id}"/>`;

          if (dialTheme === 'chakra') {
            const ix1 = cx + rInnerVastu * Math.cos(startRad);
            const iy1 = cy + rInnerVastu * Math.sin(startRad);
            const ix2 = cx + rInnerVastu * Math.cos(endRad);
            const iy2 = cy + rInnerVastu * Math.sin(endRad);
            svgContent += `<path d="M ${ix1.toFixed(1)} ${iy1.toFixed(1)} L ${arcX1.toFixed(1)} ${arcY1.toFixed(1)} A ${rOuterVastu - 3} ${rOuterVastu - 3} 0 0 1 ${arcX2.toFixed(1)} ${arcY2.toFixed(1)} L ${ix2.toFixed(1)} ${iy2.toFixed(1)} A ${rInnerVastu} ${rInnerVastu} 0 0 0 ${ix1.toFixed(1)} ${iy1.toFixed(1)} Z" fill="${elem.color}" fill-opacity="0.22" class="vastu-sector-fill"/>`;
          }

          // Zone text
          const textR = rOuterVastu - 22;
          const tx = cx + textR * Math.cos(centerRad);
          const ty = cy + textR * Math.sin(centerRad);
          const textColor = (zone.id === 'N') ? 'var(--accent-north)' : 'currentColor';
          svgContent += `<text x="${tx.toFixed(1)}" y="${ty.toFixed(1)}" text-anchor="middle" dominant-baseline="central" font-size="10.5" font-weight="700" fill="${textColor}" class="vastu-zone-text" transform="rotate(${zone.centerDeg}, ${tx.toFixed(1)}, ${ty.toFixed(1)})">${zone.id}</text>`;
        });

      } else if (zoneSystem === '32') {
        // --- 32 PADA DEVATA CHAKRA (11.25° each) ---
        VASTU_DATA.PADAS_32.forEach((pada) => {
          const startRad = (pada.startDeg - 90) * (Math.PI / 180);
          const endRad = (pada.endDeg - 90) * (Math.PI / 180);
          const centerDeg = (pada.startDeg + pada.endDeg) / 2;
          const centerRad = (centerDeg - 90) * (Math.PI / 180);

          // Grade color: Green for Grade A, Yellow for Grade B, Red for Grade C
          let gradeColor = '#ef4444';
          if (pada.grade === 'A') gradeColor = '#22c55e';
          else if (pada.grade === 'B') gradeColor = '#eab308';

          // Divider
          const sx = cx + rOuterVastu * Math.cos(startRad);
          const sy = cy + rOuterVastu * Math.sin(startRad);
          const ex = cx + rInnerVastu * Math.cos(startRad);
          const ey = cy + rInnerVastu * Math.sin(startRad);
          svgContent += `<line x1="${ex.toFixed(1)}" y1="${ey.toFixed(1)}" x2="${sx.toFixed(1)}" y2="${sy.toFixed(1)}" stroke="currentColor" stroke-opacity="0.2" stroke-width="0.8"/>`;

          // Outer arc with grade color
          const arcX1 = cx + (rOuterVastu - 2) * Math.cos(startRad);
          const arcY1 = cy + (rOuterVastu - 2) * Math.sin(startRad);
          const arcX2 = cx + (rOuterVastu - 2) * Math.cos(endRad);
          const arcY2 = cy + (rOuterVastu - 2) * Math.sin(endRad);
          svgContent += `<path d="M ${arcX1.toFixed(1)} ${arcY1.toFixed(1)} A ${rOuterVastu - 2} ${rOuterVastu - 2} 0 0 1 ${arcX2.toFixed(1)} ${arcY2.toFixed(1)}" fill="none" stroke="${gradeColor}" stroke-width="5" stroke-opacity="0.9" class="vastu-sector-ring vastu-sector-clickable" data-pada-id="${pada.id}"/>`;

          if (dialTheme === 'chakra') {
            const ix1 = cx + rInnerVastu * Math.cos(startRad);
            const iy1 = cy + rInnerVastu * Math.sin(startRad);
            const ix2 = cx + rInnerVastu * Math.cos(endRad);
            const iy2 = cy + rInnerVastu * Math.sin(endRad);
            svgContent += `<path d="M ${ix1.toFixed(1)} ${iy1.toFixed(1)} L ${arcX1.toFixed(1)} ${arcY1.toFixed(1)} A ${rOuterVastu - 2} ${rOuterVastu - 2} 0 0 1 ${arcX2.toFixed(1)} ${arcY2.toFixed(1)} L ${ix2.toFixed(1)} ${iy2.toFixed(1)} A ${rInnerVastu} ${rInnerVastu} 0 0 0 ${ix1.toFixed(1)} ${iy1.toFixed(1)} Z" fill="${gradeColor}" fill-opacity="0.18" class="vastu-sector-fill"/>`;
          }

          // Pada ID text (e.g. E3, N4)
          const textR = rOuterVastu - 16;
          const tx = cx + textR * Math.cos(centerRad);
          const ty = cy + textR * Math.sin(centerRad);
          svgContent += `<text x="${tx.toFixed(1)}" y="${ty.toFixed(1)}" text-anchor="middle" dominant-baseline="central" font-size="8.5" font-weight="700" fill="${gradeColor}" class="vastu-zone-text" transform="rotate(${centerDeg}, ${tx.toFixed(1)}, ${ty.toFixed(1)})">${pada.id}</text>`;

          // Devata short name
          const devataR = textR - 16;
          const dx = cx + devataR * Math.cos(centerRad);
          const dy = cy + devataR * Math.sin(centerRad);
          const devataShort = pada.devata.split(' ')[0];
          svgContent += `<text x="${dx.toFixed(1)}" y="${dy.toFixed(1)}" text-anchor="middle" dominant-baseline="central" font-size="7" font-weight="600" fill="currentColor" opacity="0.75" transform="rotate(${centerDeg}, ${dx.toFixed(1)}, ${dy.toFixed(1)})">${devataShort}</text>`;
        });

        // --- 12 ANTAR-DEVATA INNER RING (Completing the 45-Devata Vishwakarma Mandala) ---
        if (VASTU_DATA.ANTAR_DEVATAS_12) {
          const rAntarOuter = 132;
          svgContent += `<circle cx="${cx}" cy="${cy}" r="${rAntarOuter}" fill="none" stroke="var(--kuberan-gold)" stroke-opacity="0.45" stroke-width="1.2" stroke-dasharray="3,2"/>`;
          VASTU_DATA.ANTAR_DEVATAS_12.forEach((antar) => {
            const sRad = (antar.startDeg - 90) * (Math.PI / 180);
            let span = antar.endDeg - antar.startDeg;
            if (span < 0) span += 360;
            const cDeg = (antar.startDeg + span / 2) % 360;
            const cRad = (cDeg - 90) * (Math.PI / 180);

            const sx = cx + rAntarOuter * Math.cos(sRad);
            const sy = cy + rAntarOuter * Math.sin(sRad);
            const ex = cx + rInnerVastu * Math.cos(sRad);
            const ey = cy + rInnerVastu * Math.sin(sRad);
            svgContent += `<line x1="${ex.toFixed(1)}" y1="${ey.toFixed(1)}" x2="${sx.toFixed(1)}" y2="${sy.toFixed(1)}" stroke="var(--kuberan-gold)" stroke-opacity="0.35" stroke-width="1"/>`;

            const rLabel = (rAntarOuter + rInnerVastu) / 2;
            const lx = cx + rLabel * Math.cos(cRad);
            const ly = cy + rLabel * Math.sin(cRad);
            svgContent += `<text x="${lx.toFixed(1)}" y="${ly.toFixed(1)}" text-anchor="middle" dominant-baseline="central" font-size="6.8" font-weight="700" fill="var(--kuberan-gold)" opacity="0.9" transform="rotate(${cDeg}, ${lx.toFixed(1)}, ${ly.toFixed(1)})">${antar.shortName}</text>`;
          });
        }
      }

      // Room-to-Direction Finder Target Highlight Arc Overlay
      if (activeRoom) {
        activeRoom.idealZones.forEach(zoneCode => {
          const z = VASTU_DATA.ZONES_8.find(item => item.code === zoneCode);
          if (z) {
            const startRad = (z.startDeg - 90) * (Math.PI / 180);
            const endRad = (z.endDeg - 90) * (Math.PI / 180);
            const ax1 = cx + (rOuterVastu + 1) * Math.cos(startRad);
            const ay1 = cy + (rOuterVastu + 1) * Math.sin(startRad);
            const ax2 = cx + (rOuterVastu + 1) * Math.cos(endRad);
            const ay2 = cy + (rOuterVastu + 1) * Math.sin(endRad);
            svgContent += `<path d="M ${ax1.toFixed(1)} ${ay1.toFixed(1)} A ${rOuterVastu + 1} ${rOuterVastu + 1} 0 0 1 ${ax2.toFixed(1)} ${ay2.toFixed(1)}" fill="none" stroke="#22c55e" stroke-width="7" stroke-linecap="round" filter="drop-shadow(0 0 8px rgba(34,197,94,0.8))"/>`;
          }
        });
      } else if (propertyType === 'commercial') {
        // Retail Key Zones Highlight (Commercial Mode)
        const prof = VASTU_DATA.RETAIL_PROFILES && VASTU_DATA.RETAIL_PROFILES.find(p => p.profile_id === retailProfile);
        if (prof && prof.keyZones) {
          prof.keyZones.forEach(zoneCode => {
            const z = VASTU_DATA.ZONES_8.find(item => item.code === zoneCode);
            if (z) {
              const startRad = (z.startDeg - 90) * (Math.PI / 180);
              const endRad = (z.endDeg - 90) * (Math.PI / 180);
              const ax1 = cx + (rOuterVastu + 1) * Math.cos(startRad);
              const ay1 = cy + (rOuterVastu + 1) * Math.sin(startRad);
              const ax2 = cx + (rOuterVastu + 1) * Math.cos(endRad);
              const ay2 = cy + (rOuterVastu + 1) * Math.sin(endRad);
              svgContent += `<path d="M ${ax1.toFixed(1)} ${ay1.toFixed(1)} A ${rOuterVastu + 1} ${rOuterVastu + 1} 0 0 1 ${ax2.toFixed(1)} ${ay2.toFixed(1)}" fill="none" stroke="#d4a359" stroke-width="4.5" stroke-linecap="round" opacity="0.85" filter="drop-shadow(0 0 6px rgba(212,163,89,0.7))"/>`;
            }
          });
        }
      }

      // Degree Ticks (Every 5° and 15° around outer edge)
      for (let deg = 0; deg < 360; deg += 5) {
        const rad = (deg - 90) * (Math.PI / 180);
        const is15 = deg % 15 === 0;
        const tickLen = is15 ? 8 : 4;
        const strokeWidth = is15 ? 1.5 : 0.8;
        const strokeOpacity = is15 ? 0.7 : 0.35;
        const x1 = cx + (rOuter - 1) * Math.cos(rad);
        const y1 = cy + (rOuter - 1) * Math.sin(rad);
        const x2 = cx + (rOuter - 1 - tickLen) * Math.cos(rad);
        const y2 = cy + (rOuter - 1 - tickLen) * Math.sin(rad);
        const strokeColor = (deg === 0) ? 'var(--accent-north)' : 'currentColor';
        svgContent += `<line x1="${x1.toFixed(1)}" y1="${y1.toFixed(1)}" x2="${x2.toFixed(1)}" y2="${y2.toFixed(1)}" stroke="${strokeColor}" stroke-width="${strokeWidth}" stroke-opacity="${strokeOpacity}"/>`;
      }
    }

    
    // Vastu Purusha Mandala Grid (81 Padas)
    if (showGrid && compassMode === 'vastu') {
      const gridSize = 360; 
      const cell = gridSize / 9;
      const startX = cx - (gridSize / 2);
      const startY = cy - (gridSize / 2);

      // Draw grid lines
      for (let i = 0; i <= 9; i++) {
        const pos = startX + i * cell;
        // vertical
        svgContent += `<line x1="${pos}" y1="${startY}" x2="${pos}" y2="${startY + gridSize}" stroke="var(--kuberan-gold)" stroke-opacity="0.35" stroke-width="1.5" stroke-dasharray="4,4"/>`;
        // horizontal
        svgContent += `<line x1="${startX}" y1="${pos}" x2="${startX + gridSize}" y2="${pos}" stroke="var(--kuberan-gold)" stroke-opacity="0.35" stroke-width="1.5" stroke-dasharray="4,4"/>`;
      }

      // Highlight Brahmasthan (Center 3x3 = 9 squares)
      const bStart = startX + 3 * cell;
      svgContent += `<rect x="${bStart}" y="${bStart}" width="${3*cell}" height="${3*cell}" fill="var(--kuberan-gold)" fill-opacity="0.1" stroke="var(--kuberan-gold)" stroke-width="2"/>`;
      svgContent += `<text x="${cx}" y="${cy}" fill="var(--kuberan-gold)" font-size="11" font-weight="bold" font-family="Inter,sans-serif" text-anchor="middle" dominant-baseline="middle" opacity="0.95">BRAHMASTHAN</text>`;
      // 4 Paridhi Inner Deities around Brahmasthana (Vishwakarma Prakash 81-Pada Mandala)
      svgContent += `<text x="${cx}" y="${bStart - cell * 0.5}" fill="#fde68a" font-size="7.5" font-weight="700" text-anchor="middle" dominant-baseline="middle" opacity="0.85">Pṛthvīdhara</text>`;
      svgContent += `<text x="${bStart + 3 * cell + cell * 0.5}" y="${cy}" fill="#fde68a" font-size="7.5" font-weight="700" text-anchor="middle" dominant-baseline="middle" opacity="0.85" transform="rotate(90, ${bStart + 3 * cell + cell * 0.5}, ${cy})">Aryamā</text>`;
      svgContent += `<text x="${cx}" y="${bStart + 3 * cell + cell * 0.5}" fill="#fde68a" font-size="7.5" font-weight="700" text-anchor="middle" dominant-baseline="middle" opacity="0.85">Vivasvān</text>`;
      svgContent += `<text x="${bStart - cell * 0.5}" y="${cy}" fill="#fde68a" font-size="7.5" font-weight="700" text-anchor="middle" dominant-baseline="middle" opacity="0.85" transform="rotate(-90, ${bStart - cell * 0.5}, ${cy})">Mitra</text>`;
      
      // Maha Marmas (Critical Energy Diagonals: NE-SW Spine & NW-SE)
      // NW to SE diagonal
      svgContent += `<line x1="${startX}" y1="${startY}" x2="${startX + gridSize}" y2="${startY + gridSize}" stroke="#ef4444" stroke-opacity="0.4" stroke-width="2" stroke-dasharray="6,4"/>`;
      // NE to SW diagonal (The Primary Spine)
      svgContent += `<line x1="${startX + gridSize}" y1="${startY}" x2="${startX}" y2="${startY + gridSize}" stroke="#ef4444" stroke-opacity="0.5" stroke-width="2.5" stroke-dasharray="6,4"/>`;
      
      // Outer rim box
      svgContent += `<rect x="${startX}" y="${startY}" width="${gridSize}" height="${gridSize}" fill="none" stroke="var(--kuberan-gold)" stroke-width="2" stroke-opacity="0.6"/>`;
    }

    // ─── Golden Solar Azimuth Marker on Dial Outer Ring ───
    try {
      const currentLat = (window.lastKnownLat !== undefined) ? window.lastKnownLat : 12.9716;
      const currentLng = (window.lastKnownLng !== undefined) ? window.lastKnownLng : 77.5946;
      const sunPos = calculateSunPosition(currentLat, currentLng);
      const sunRad = (sunPos.azimuth - 90) * (Math.PI / 180);
      const sunR = 216; // Placed on outer ring
      const sunX = cx + sunR * Math.cos(sunRad);
      const sunY = cy + sunR * Math.sin(sunRad);
      const sunOpacity = sunPos.isDay ? 1.0 : 0.35;
      const sunIconText = sunPos.isDay ? '☀️' : '🌙';

      svgContent += `
        <g class="sun-dial-marker" opacity="${sunOpacity}" transform="rotate(${sunPos.azimuth}, ${sunX.toFixed(1)}, ${sunY.toFixed(1)})" title="Sun Azimuth: ${sunPos.azimuth}° (Alt: ${sunPos.altitude}°)">
          <circle cx="${sunX.toFixed(1)}" cy="${sunY.toFixed(1)}" r="10" fill="#f59e0b" fill-opacity="0.25" stroke="#f59e0b" stroke-width="1.5"/>
          <text x="${sunX.toFixed(1)}" y="${sunY.toFixed(1)}" font-size="11" text-anchor="middle" dominant-baseline="central">${sunIconText}</text>
        </g>
      `;
    } catch(e) {}

    dialSvg.innerHTML = svgContent;
  }

  // ═══ §6 UI_UPDATES ════════════════════════════════════════════
  // Heading display, inclinometer, inspector panel updates.
  // Future: extract to UI update layer or React/Vue computed props.
  const EXTRA_TAG_LABELS = {
    meditation: { icon: '🧘', en: 'Meditation / Yoga', hi: 'ध्यान एवं योग', kn: 'ಧ್ಯಾನ ಕೇಂದ್ರ', ta: 'தியானம் / யோகா', te: 'ధ్యాన మందిరం' },
    open_space: { icon: '🌿', en: 'Open Space / Lawn', hi: 'खुला स्थान / उद्यान', kn: 'ಮುಕ್ತ ಸ್ಥಳ / ಉದ್ಯಾನ', ta: 'திறந்தவெளி / தோட்டம்', te: 'ఖాళీ స్థలం / తోట' },
    balcony: { icon: '🌤️', en: 'Balcony / Verandah', hi: 'बालकनी / बरामदा', kn: 'ಬಾಲ್ಕನಿ / ಜಗುಲಿ', ta: 'பால்கனி / தாழ்வாரம்', te: 'బాల్కనీ / వరండా' },
    electrical_meter: { icon: '⚡', en: 'Electrical Panel', hi: 'विद्युत मीटर / पैनल', kn: 'ವಿದ್ಯುತ್ ಮೀಟರ್', ta: 'மின்சார மீட்டர்', te: 'విద్యుత్ మీటర్' },
    inverter: { icon: '🔋', en: 'Inverter / UPS', hi: 'इन्वर्टर / यूपीएस', kn: 'ಇನ್ವರ್ಟರ್ / ಯುಪಿಎಸ್', ta: 'இன்வெர்ட்டர் / யுபிஎஸ்', te: 'ఇన్వర్టర్ / యుపిఎస్' },
    boiler: { icon: '🔥', en: 'Boiler / Heater', hi: 'बॉयलर / गीजर', kn: 'ಬಾಯ್ಲರ್ / ಹೀಟರ್', ta: 'பாய்லர் / ஹீட்டர்', te: 'బాయిలర్ / హీటర్' },
    generator: { icon: '⚙️', en: 'Generator', hi: 'जनरेटर', kn: 'ಜನರೇಟರ್', ta: 'ஜெனரேட்டர்', te: 'జనరేటర్' },
    bedroom: { icon: '🛏️', en: 'Bedroom', hi: 'शयनकक्ष', kn: 'ಮಲಗುವ ಕೋಣೆ', ta: 'படுக்கையறை', te: 'పడకగది' },
    main_entrance: { icon: '🚪', en: 'Main Entrance', hi: 'मुख्य द्वार', kn: 'ಮುಖ್ಯ ದ್ವಾರ', ta: 'முக்கிய வாசல்', te: 'సింహద్వారం' },
    children_bed: { icon: '🧒', en: 'Children Bedroom', hi: 'बच्चों का कमरा', kn: 'ಮಕ್ಕಳ ಕೋಣೆ', ta: 'குழந்தைகள் அறை', te: 'పిల్లల గది' },
    guest_bed: { icon: '🛎️', en: 'Guest Room', hi: 'अतिथि कक्ष', kn: 'ಅತಿಥಿ ಕೋಣೆ', ta: 'விருந்தினர் அறை', te: 'అతిథి గది' },
    garage: { icon: '🚗', en: 'Garage / Parking', hi: 'गैरेज / वाहन पार्किंग', kn: 'ವಾಹನ ನಿಲುಗಡೆ', ta: 'வாகன நிறுத்துமிடம்', te: 'వాహన పార్కింగ్' },
    finished_goods: { icon: '🚚', en: 'Finished Goods', hi: 'तैयार माल', kn: 'ಸಿದ್ಧಪಡಿಸಿದ ಸರಕು', ta: 'விற்பனைப் பொருட்கள்', te: 'సిద్ధమైన సరుకు' },
    grains_storage: { icon: '🌾', en: 'Grains / Granary', hi: 'अन्न भंडार', kn: 'ಧಾನ್ಯ ಸಂಗ್ರಹ', ta: 'தானிய கிடங்கு', te: 'ధాన్యాగారం' }
  };

  function updateVastuInspector(heading) {
    if (compassMode !== 'vastu') return;

    const activeZone8 = getActiveZone8(heading);
    const activeZone16 = getActiveZone16(heading);
    const activeAntar = getActiveAntarDevata(heading);
    const elem = VASTU_DATA.ELEMENTS[activeZone8.element];
    const dict = VASTU_DATA.UI[currentLang] || VASTU_DATA.UI.en;
    const toggleGridEl = document.getElementById('toggle-vastu-grid');
    const isGridActive = !!(toggleGridEl && toggleGridEl.checked);

    // Update Shastric Lineage & Antar-Devata Header Pills
    const shastraLineageBadge = document.getElementById('shastraLineageBadge');
    const shastraAntarPill = document.getElementById('shastraAntarPill');
    if (shastraLineageBadge) {
      if (zoneSystem === '32' || isGridActive) {
        shastraLineageBadge.textContent = '📜 Vishwakarma Prakash • 45-Devata Mandala (Classical)';
      } else if (zoneSystem === '16') {
        shastraLineageBadge.textContent = '🧭 MahaVastu • 16-Zone Angular System (Modern)';
      } else {
        shastraLineageBadge.textContent = '📜 Vishwakarma Prakash • Ashta-Dikpala (Classical 8-Zone)';
      }
    }
    if (shastraAntarPill && activeAntar) {
      shastraAntarPill.textContent = `🕉️ Antar-Devatā: ${activeAntar.name}`;
    }

    const effectiveZoneCode = zoneSystem === '16' ? activeZone16.id : activeZone8.code;
    const isZoneChanged = effectiveZoneCode !== cachedInspectorZone ||
                          currentLang !== cachedInspectorLang ||
                          propertyType !== cachedInspectorPropType ||
                          retailProfile !== cachedInspectorRetail;

    if (isZoneChanged) {
      cachedInspectorZone = effectiveZoneCode;
      cachedInspectorLang = currentLang;
      cachedInspectorPropType = propertyType;
      cachedInspectorRetail = retailProfile;

      // Header Zone Badge & Name (Supports both 8-Zone Classical & 16-Zone Sub-Sectors)
      if (zoneSystem === '16' && activeZone16) {
        if (inspZoneBadge) inspZoneBadge.textContent = activeZone16.id;
        if (inspZoneName) inspZoneName.textContent = activeZone16.label;
        const attrKey = currentLang === 'en' ? 'attribute' : ('attribute' + currentLang.charAt(0).toUpperCase() + currentLang.slice(1));
        const attrVal = activeZone16[attrKey] || activeZone16.attribute;
        if (inspSanskrit) inspSanskrit.textContent = `${activeZone16.sanskrit} • ${attrVal}`;
      } else {
        if (inspZoneBadge) inspZoneBadge.textContent = activeZone8.code;
        if (inspZoneName) inspZoneName.textContent = activeZone8.names[currentLang] || activeZone8.names.en;
        if (inspSanskrit) inspSanskrit.textContent = activeZone8.sanskrit;
      }

      // Element Badge
      if (inspElementDot) {
        inspElementDot.style.background = elem.color;
        inspElementDot.style.boxShadow = `0 0 8px ${elem.color}`;
      }
      if (inspElementName) inspElementName.textContent = elem.names[currentLang] || elem.names.en;

      // Ruling Deity & Classical Summary
      if (inspDeityVal) inspDeityVal.textContent = activeZone8.deityNames[currentLang] || activeZone8.deityNames.en;
      if (inspSummaryText) inspSummaryText.textContent = activeZone8.summary[currentLang] || activeZone8.summary.en;

      // Favorable & Avoid Placements Cloud & Commercial Inspector
      if (propertyType === 'commercial') {
        if (commercialInspectorBox) commercialInspectorBox.classList.remove('hidden');
        const commZone = VASTU_DATA.COMMERCIAL_ZONES && VASTU_DATA.COMMERCIAL_ZONES[activeZone8.code];
        if (commZone) {
          if (inspCommSuitability) inspCommSuitability.textContent = commZone.commercial_suitability.join(' • ');
          const impactText = typeof commZone.business_impact === 'object'
            ? (commZone.business_impact[currentLang] || commZone.business_impact.en)
            : commZone.business_impact;
          if (inspBusinessImpact) inspBusinessImpact.textContent = impactText;

          let favHtml = '';
          commZone.commercial_suitability.forEach(item => {
            favHtml += `<span class="room-tag">🏢 ${item}</span>`;
          });
          if (favorableTags) favorableTags.innerHTML = favHtml || '<span class="room-tag">Commercial</span>';

          let avoidHtml = '';
          commZone.avoid.forEach(item => {
            avoidHtml += `<span class="room-tag tag-avoid">❌ ${item}</span>`;
          });
          if (avoidTags) avoidTags.innerHTML = avoidHtml || '<span class="room-tag tag-avoid">Incompatible Setup</span>';

          if (inspTipText) {
            if (commZone.retail_tips && commZone.retail_tips[retailProfile]) {
              inspTipText.textContent = commZone.retail_tips[retailProfile][currentLang] || commZone.retail_tips[retailProfile].en;
            } else {
              inspTipText.textContent = activeZone8.tips[currentLang] || activeZone8.tips.en;
            }
          }
        }
      } else {
        if (commercialInspectorBox) commercialInspectorBox.classList.add('hidden');
        let favHtml = '';
        activeZone8.recommendedRooms.forEach(roomId => {
          const roomObj = VASTU_DATA.ROOMS.find(r => r.id === roomId);
          const extraObj = EXTRA_TAG_LABELS[roomId];
          const name = roomObj ? (roomObj.names[currentLang] || roomObj.names.en) : (extraObj ? (extraObj[currentLang] || extraObj.en) : roomId.replace(/_/g, ' '));
          const icon = roomObj ? roomObj.icon : (extraObj ? extraObj.icon : '✨');
          favHtml += `<span class="room-tag">${icon} ${name}</span>`;
        });
        if (favorableTags) favorableTags.innerHTML = favHtml || '<span class="room-tag">General</span>';

        let avoidHtml = '';
        activeZone8.prohibitedRooms.forEach(roomId => {
          const roomObj = VASTU_DATA.ROOMS.find(r => r.id === roomId);
          const extraObj = EXTRA_TAG_LABELS[roomId];
          const name = roomObj ? (roomObj.names[currentLang] || roomObj.names.en) : (extraObj ? (extraObj[currentLang] || extraObj.en) : roomId.replace(/_/g, ' '));
          avoidHtml += `<span class="room-tag tag-avoid">❌ ${name}</span>`;
        });
        if (avoidTags) avoidTags.innerHTML = avoidHtml || '<span class="room-tag tag-avoid">Heavy Clutter</span>';

        if (inspTipText) inspTipText.textContent = activeZone8.tips[currentLang] || activeZone8.tips.en;
      }
    }

    // 45-Devata Mandala & 32-Pada Entrance Card (Active in 32-Pada mode or 81-Grid mode)
    if (zoneSystem === '32' || isGridActive) {
      if (padaEntranceCard) padaEntranceCard.classList.remove('hidden');
      const activePada = getActivePada32(heading);
      if (activePada.id !== cachedInspectorPada || currentLang !== cachedInspectorLang) {
        cachedInspectorPada = activePada.id;
        if (padaIdBadge) padaIdBadge.textContent = activePada.id;
        if (padaDevataName) padaDevataName.textContent = activePada.devata;

        if (padaGradePill) {
          padaGradePill.className = 'pada-grade-pill';
          if (activePada.grade === 'A') {
            padaGradePill.classList.add('grade-a');
            padaGradePill.textContent = dict.entranceGradeA || '🌟 Highly Auspicious';
          } else if (activePada.grade === 'B') {
            padaGradePill.classList.add('grade-b');
            padaGradePill.textContent = dict.entranceGradeB || '⚠️ Neutral';
          } else {
            padaGradePill.classList.add('grade-c');
            padaGradePill.textContent = dict.entranceGradeC || '❌ Inauspicious';
          }
        }

        const effectProp = 'effect' + currentLang.charAt(0).toUpperCase() + currentLang.slice(1);
        if (padaEffectText) padaEffectText.textContent = activePada[effectProp] || activePada.effectEn;

        // Populate 12 Antar-Devata (Inner 45-Devata Mandala Ring)
        if (activeAntar) {
          const antarNameEl = document.getElementById('antarDevataName');
          const antarPadasEl = document.getElementById('antarDevataPadas');
          const antarEffectEl = document.getElementById('antarDevataEffect');
          if (antarNameEl) antarNameEl.textContent = activeAntar.name;
          if (antarPadasEl) antarPadasEl.textContent = `${activeAntar.padas} Padas • ${activeAntar.ring}`;
          if (antarEffectEl) antarEffectEl.textContent = activeAntar.effect[currentLang] || activeAntar.effect.en;
        }
      }

      if (hapticsEnabled && activePada.grade === 'A' && lastVibratedPada !== activePada.id) {
        lastVibratedPada = activePada.id;
        triggerHapticTick(25);
      }
    } else {
      if (padaEntranceCard) padaEntranceCard.classList.add('hidden');
    }

    // Check Room Finder Alignment
    if (activeRoom) {
      const isAligned = activeRoom.idealZones.includes(activeZone8.code);
      if (isAligned) {
        roomGuidanceBanner.classList.add('aligned');
        guideStatusText.textContent = `🎯 ${dict.targetBearing || 'Target'}: ${inspZoneName.textContent} (${dict.entranceGradeA || 'Auspicious'})`;
        if (hapticsEnabled && lastVibratedCardinal !== activeZone8.centerDeg) {
          lastVibratedCardinal = activeZone8.centerDeg;
          triggerHapticTick(35);
        }
      } else {
        roomGuidanceBanner.classList.remove('aligned');
        guideStatusText.textContent = `Rotate device toward: ${activeRoom.idealZones.join(', ')}`;
      }
    }
  }

  // --- Haptic Feedback ---
  function triggerHapticTick(duration = 20) {
    if (hapticsEnabled && 'vibrate' in navigator) {
      const now = Date.now();
      if (now - lastVibrateTime > 250) {
        lastVibrateTime = now;
        try {
          (localStorage.getItem('kuberan_haptics') !== 'false') && navigator.vibrate(duration);
        } catch(e) { /* localStorage/vibrate may be blocked in private browsing */ }
      }
    }
  }

  // --- Update Primary Orientation & Telemetry UI ---
  function updateHeadingUI(cssHeading) {
    lastCssHeading = cssHeading;
    const displayHeading = ((cssHeading % 360) + 360) % 360;
    currentHeading = displayHeading; // Store clamped 0-359 value for external use
    const rounded = Math.round(displayHeading) === 360 ? 0 : Math.round(displayHeading);

    // Degrees display
    headingDegrees.textContent = rounded;

    // Cardinal Heading calculation
    const cardinals = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    const cardIndex = Math.round(displayHeading / 45) % 8;
    const activeZone8 = VASTU_DATA.ZONES_8[cardIndex];
    headingCardinal.textContent = cardinals[cardIndex];

    // Subtitle Sanskrit
    headingSanskrit.textContent = activeZone8.sanskrit;

    // Mils (6400 NATO Mils scale)
    const mils = Math.round((displayHeading / 360) * 6400);
    milsValue.textContent = mils;

    // Back Azimuth
    const backAzimuth = Math.round((displayHeading + 180) % 360);
    backAzimuthValue.textContent = `${backAzimuth}°`;

    // Rotate Compass Card
    compassCard.style.transform = `rotate(${-cssHeading}deg)`;

    // Target Deviation Bar
    if (targetHeading !== null) {
      let diff = displayHeading - targetHeading;
      while (diff < -180) diff += 360;
      while (diff > 180) diff -= 360;

      const absDiff = Math.abs(diff);
      targetDeviationBar.classList.remove('hidden');

      if (absDiff <= 2) {
        devArrow.textContent = '🎯';
        devText.textContent = 'ON TARGET';
        targetDeviationBar.classList.add('on-target');
      } else if (diff < 0) {
        devArrow.textContent = '▶';
        devText.textContent = `${Math.round(absDiff)}° RIGHT`;
        targetDeviationBar.classList.remove('on-target');
      } else {
        devArrow.textContent = '◀';
        devText.textContent = `${Math.round(absDiff)}° LEFT`;
        targetDeviationBar.classList.remove('on-target');
      }
    } else {
      targetDeviationBar.classList.add('hidden');
    }

    // Cardinal Haptic Tick (exact 0°, 90°, 180°, 270° within 1.5°)
    
    const cardinalAngles = [0, 90, 180, 270];
    let matchedCardinal = -1;
    for (const ang of cardinalAngles) {
      if (Math.abs(displayHeading - ang) <= 1.2 || Math.abs(displayHeading - 360) <= 1.2) {
        matchedCardinal = ang === 360 ? 0 : ang;
        break;
      }
    }
    
    if (matchedCardinal !== -1 && lastVibratedCardinal !== matchedCardinal) {
      lastVibratedCardinal = matchedCardinal;
      triggerHapticTick(20);
    } else if (matchedCardinal === -1) {
      lastVibratedCardinal = -1;
    }


    // Update Vastu Inspector Card (Preserve Tap-to-Inspect Sector Preview if active)
    if (!previewZoneSector) {
      updateVastuInspector(displayHeading);
    }

    // If Plot Tilt Modal is open, update its real-time angle
    if (!plotTiltModal.classList.contains('hidden')) {
      updatePlotTiltUI(displayHeading);
    }

    // Live update AR Fullscreen HUD if active
    updateArFullscreenHUD(displayHeading);
  }

  // --- Bubble Level & Inclinometer with RAF Decoupling ---
  let inclinometerRafId = null;
  let scheduledPitch = 0;
  let scheduledRoll = 0;

  function scheduleInclinometerUpdate(p, r) {
    scheduledPitch = p;
    scheduledRoll = r;
    if (!inclinometerRafId) {
      inclinometerRafId = requestAnimationFrame(() => {
        inclinometerRafId = null;
        updateInclinometer(scheduledPitch, scheduledRoll);
      });
    }
  }

  function updateInclinometer(p, r) {
    pitch = p;
    roll = r;

    if (pitchValue) pitchValue.textContent = `${Math.round(pitch)}°`;
    if (rollValue) rollValue.textContent = `${Math.round(roll)}°`;

    // Gauge bars
    const maxTilt = 45;
    const pitchPct = Math.min(100, (Math.abs(pitch) / maxTilt) * 100);
    const rollPct = Math.min(100, (Math.abs(roll) / maxTilt) * 100);
    pitchGauge.style.width = `${pitchPct}%`;
    rollGauge.style.width = `${rollPct}%`;

    // Center bubble position inside housing (housing radius ~65px)
    const maxBubbleDisp = 40;
    const bx = Math.max(-maxBubbleDisp, Math.min(maxBubbleDisp, (roll / 30) * maxBubbleDisp));
    const by = Math.max(-maxBubbleDisp, Math.min(maxBubbleDisp, (pitch / 30) * maxBubbleDisp));
    levelBubble.style.transform = `translate(${bx}px, ${by}px)`;

    // Level status check (<= 1.5° = perfectly level)
    const isLevel = Math.abs(pitch) <= 1.5 && Math.abs(roll) <= 1.5;
    
    const levelHudBadge = document.getElementById('levelHudBadge');
    const levelHudText = document.getElementById('levelHudText');
    const tiltDeg = Math.max(Math.abs(pitch), Math.abs(roll));
    if (levelHudBadge && levelHudText) {
      if (isLevel) {
        levelHudBadge.classList.add('level-locked');
        levelHudBadge.classList.remove('tilt-warning');
        levelHudText.textContent = '0.0° LEVEL';
      } else if (tiltDeg > SC.TILT_WARN_DEG) {
        levelHudBadge.classList.remove('level-locked');
        levelHudBadge.classList.add('tilt-warning');
        levelHudText.textContent = `⚠️ ${tiltDeg.toFixed(1)}° TILT`;
      } else {
        levelHudBadge.classList.remove('level-locked', 'tilt-warning');
        levelHudText.textContent = `${tiltDeg.toFixed(1)}° TILT`;
      }
    }

    if (isLevel) {
      levelHousing.classList.add('level-locked');
      levelStatusCard.classList.add('level-locked');
      levelStatusText.textContent = 'PERFECTLY LEVEL';
    } else {
      levelHousing.classList.remove('level-locked');
      levelStatusCard.classList.remove('level-locked');
      levelStatusText.textContent = `${Math.max(Math.abs(pitch), Math.abs(roll)).toFixed(1)}° TILT`;
    }

    syncTiltWarning(pitch, roll);

    // Update AR Artificial Horizon Line if AR overlay is open
    const arHorizonLine = document.getElementById('arHorizonLine');
    if (arHorizonLine) {
      arHorizonLine.style.transform = `translateY(-50%) rotate(${-roll}deg)`;
    }
  }

  // Visual warning when pitch (beta) or roll (gamma) exceeds 15° (hysteresis: clears below 12°).
  // Suppressed in fullscreen AR where an upright phone is expected. Text is set once on activation so
  // the aria-live region announces it once instead of on every degree change.
  function syncTiltWarning(p, r) {
    const banner = document.getElementById('tiltWarningBanner');
    if (!banner) return;
    const ev = SC.evaluateTilt(p, r, tiltWarningActive);
    const show = ev.warning && !isArFullscreenOpen();
    if (show === tiltWarningActive) return;
    tiltWarningActive = show;
    if (show) {
      const textEl = document.getElementById('tiltWarningText');
      const ui = (VASTU_DATA.UI && (VASTU_DATA.UI[currentLang] || VASTU_DATA.UI.en)) || {};
      if (textEl) textEl.textContent = ui.tiltWarningMsg || (VASTU_DATA.UI && VASTU_DATA.UI.en.tiltWarningMsg) || 'Phone tilted more than 15°. Hold it flat: excessive tilt degrades magnetometer accuracy.';
    }
    banner.classList.toggle('hidden', !show);
  }

  // --- Update Compass Orientation via RAF Stabilizer Engine ---
  function computeTrueHeadingFromRaw(rawDeg) {
    let calibrated = rawDeg + calibrationOffset;
    if (isTrueNorth) calibrated += magneticDeclination;
    return ((calibrated % 360) + 360) % 360;
  }

  function updateHeading(rawHeading, forceImmediateUI = false) {
    if (typeof rawHeading === 'number' && !isNaN(rawHeading)) {
      rawMagneticHeading = ((rawHeading % 360) + 360) % 360;
      if (isPrecisionSampling) {
        const flatTilt = Math.max(Math.abs(pitch || 0), Math.abs(roll || 0));
        const weight = flatTilt <= 3 ? 2.0 : (flatTilt <= 10 ? 1.0 : 0.35);
        precisionSamples.push({ angle: computeTrueHeadingFromRaw(rawMagneticHeading), weight });
      }
      stabilizer.updateRawHeading(headingFilter.update(rawMagneticHeading, headingFilterGain()));
      if (forceImmediateUI && !isHeadingFrozen) {
        // Same unwrapped angle the stabilizer would emit. computeTrueHeadingFromRaw() WRAPS to [0,360), and the dial
        // has a CSS transition, so feeding it directly made the dial spin ~200-360° on unfreeze / True↔Magnetic.
        if (smoothedHeading !== null) {
          updateHeadingUI(smoothedHeading + calibrationOffset + (isTrueNorth ? magneticDeclination : 0));
        } else {
          updateHeadingUI(SC.unwrapToward(lastCssHeading, computeTrueHeadingFromRaw(rawMagneticHeading)));
        }
      }
    }
  }

  // ═══ §7 SENSORS ═══════════════════════════════════════════════
  // DeviceOrientation handlers, magnetometer, GPS.
  // Future: extract to sensors.js service module.
  // Chromium (Android): plain `deviceorientation` is RELATIVE (alpha = 0 at page load, NOT north),
  // only `deviceorientationabsolute` is north-referenced. Mixing them made the needle jump.
  // iOS: `deviceorientation` carries webkitCompassHeading (north-referenced).
  // Firefox: `deviceorientation` is absolute (event.absolute === true).
  const HAS_ABSOLUTE_EVENT = ('ondeviceorientationabsolute' in window);
  let sensorAttachTs = 0;
  let lastAbsoluteEventTs = 0;
  let relativeWarningShown = false;

  let sensorsAttached = false;
  let standardListenerAttached = false;
  let absoluteFallbackTimer = null;
  let hasAbsoluteSample = false;
  const ABSOLUTE_FALLBACK_MS = 1500;

  function attachStandardOrientationListener() {
    if (standardListenerAttached) return;
    standardListenerAttached = true;
    window.addEventListener('deviceorientation', handleDeviceOrientation, true);
  }

  // Android/Chrome: bind to north-referenced 'deviceorientationabsolute' FIRST. Plain 'deviceorientation'
  // is bound only if the browser has no absolute event (iOS Safari → webkitCompassHeading, Firefox →
  // absolute:true) or the absolute stream never delivers a usable sample within ABSOLUTE_FALLBACK_MS.
  function attachSensorListeners() {
    if (sensorsAttached) return; // Prevent duplicate event listeners
    sensorsAttached = true;
    sensorAttachTs = performance.now();
    lastAbsoluteEventTs = 0;
    hasAbsoluteSample = false;

    if (HAS_ABSOLUTE_EVENT) {
      window.addEventListener('deviceorientationabsolute', handleDeviceOrientationAbsolute, true);
      absoluteFallbackTimer = setTimeout(() => {
        absoluteFallbackTimer = null;
        if (sensorsAttached && !hasAbsoluteSample) attachStandardOrientationListener();
      }, ABSOLUTE_FALLBACK_MS);
    } else {
      attachStandardOrientationListener();
    }

    // Fallback manual touch/mouse control if sensors aren't firing on desktop
    initDesktopDragSimulation();
  }

  function detachSensorListeners() {
    if (!sensorsAttached) return;
    sensorsAttached = false;
    if (absoluteFallbackTimer) { clearTimeout(absoluteFallbackTimer); absoluteFallbackTimer = null; }
    window.removeEventListener('deviceorientationabsolute', handleDeviceOrientationAbsolute, true);
    window.removeEventListener('deviceorientation', handleDeviceOrientation, true);
    standardListenerAttached = false;
  }

  function handleDeviceOrientationAbsolute(event) {
    if (event.alpha === null || event.alpha === undefined) return; // no north reference -> useless for a compass
    isAbsoluteOrientation = true;
    lastAbsoluteEventTs = performance.now();
    hasAbsoluteSample = true;
    processOrientationData(event, true);
  }

  function handleDeviceOrientation(event) {
    const hasWebkit = event.webkitCompassHeading !== undefined && event.webkitCompassHeading !== null;
    const hasAlpha = event.alpha !== null && event.alpha !== undefined;
    if (!hasWebkit && !hasAlpha) return; // ignore empty dummy events from desktop browsers

    // iOS: direct, north-referenced heading
    if (hasWebkit) { processOrientationData(event, false); return; }

    // Firefox / any browser that flags this stream as absolute
    if (event.absolute === true) { processOrientationData(event, true); return; }

    // Chromium: this stream is RELATIVE. Prefer the absolute stream whenever it is alive.
    const now = performance.now();
    if (HAS_ABSOLUTE_EVENT) {
      const absoluteAlive = lastAbsoluteEventTs > 0 && (now - lastAbsoluteEventTs) < 1500;
      const stillWaiting = lastAbsoluteEventTs === 0 && (now - sensorAttachTs) < 1500;
      if (absoluteAlive || stillWaiting) return;
    }

    // Last resort: relative-only device. Heading is NOT north-referenced - tell the user once.
    isAbsoluteOrientation = false;
    if (!relativeWarningShown) {
      relativeWarningShown = true;
      showToast('This browser has no magnetic compass. Open in Chrome for true direction.');
    }
    processOrientationData(event, false);
  }

  function processOrientationData(event, isAbsolute) {
    const firstSample = !hasSensorData;
    hasSensorData = true;

    // Ensure permission banner is dismissed and saved as enabled once data arrives
    if (iosPermissionBanner && !iosPermissionBanner.classList.contains('hidden')) {
      iosPermissionBanner.classList.add('hidden');
    }
    // First real sensor sample: persist the flag ONCE (it used to be written at 60 Hz) and re-seed every
    // filter on the true heading so the dial does not sweep in from the 0° placeholder.
    if (firstSample) {
      try { localStorage.setItem('kuberan_compass_sensor_enabled', 'true'); } catch(e) { /* private browsing */ }
      resetHeadingFilters();
    }

    // Handle landscape/portrait orientation adjustments (modern standard + legacy fallback)
    const orientationAngle = (screen.orientation && typeof screen.orientation.angle === 'number')
      ? screen.orientation.angle
      : (typeof window.orientation === 'number' ? window.orientation : 0);

    let heading = null;

    // iOS provides direct calibrated magnetic heading and accuracy radius
    if (event.webkitCompassHeading !== undefined && event.webkitCompassHeading !== null) {
      heading = event.webkitCompassHeading;
      if (typeof event.webkitCompassAccuracy === 'number') {
        sensorAccuracy = event.webkitCompassAccuracy;
      }
      // webkitCompassHeading is reported for the device's natural top edge: compensate for screen rotation
      if (orientationAngle) {
        heading = ((heading + orientationAngle) % 360 + 360) % 360;
      }
    } else if (event.alpha !== null && event.alpha !== undefined) {
      // Android / W3C: tilt-immune heading (screen rotation is handled inside the function)
      const beta  = (event.beta  !== null && event.beta  !== undefined) ? event.beta  : 0;
      const gamma = (event.gamma !== null && event.gamma !== undefined) ? event.gamma : 0;
      heading = computeHeadingFromEuler(event.alpha, beta, gamma, orientationAngle);
      if (event.absolute === true || isAbsolute) {
        isAbsoluteOrientation = true;
      }
    }

    if (heading !== null) updateHeading(heading);

    // Pitch & Roll for bubble level
    let p = event.beta || 0;
    let r = event.gamma || 0;

    if (orientationAngle === 90) {
      const temp = p; p = -r; r = temp;
    } else if (orientationAngle === -90 || orientationAngle === 270) {
      const temp = p; p = r; r = -temp;
    } else if (orientationAngle === 180) {
      p = -p; r = -r;
    }

    // Process bubble level through identical rotation matrix (RAF-synced)
    scheduleInclinometerUpdate(p, r);
    updateCalibrationUI();
  }

  // --- Desktop / Fallback Drag Simulation ---
  let dragSimulationInitialized = false;
  let detachDesktopDragSimulation = function () {};
  function initDesktopDragSimulation() {
    if (dragSimulationInitialized) return;
    dragSimulationInitialized = true;
    let isDragging = false;
    let startAngle = 0;
    let startHeading = 0;

    function getAngle(e) {
      const rect = compassCard.getBoundingClientRect();
      const cx = rect.left + rect.width / 2;
      const cy = rect.top + rect.height / 2;
      const clientX = e.touches && e.touches.length ? e.touches[0].clientX : e.clientX;
      const clientY = e.touches && e.touches.length ? e.touches[0].clientY : e.clientY;
      return Math.atan2(clientY - cy, clientX - cx) * (180 / Math.PI);
    }

    function onStart(e) {
      if (hasSensorData) return;
      isDragging = true;
      startAngle = getAngle(e);
      startHeading = currentHeading;
    }

    function onMove(e) {
      if (!isDragging) return;
      const angle = getAngle(e);
      const delta = angle - startAngle;
      const newHeading = normalizeAngle(startHeading - delta);
      updateHeading(newHeading);
    }

    function onEnd() {
      isDragging = false;
    }

    const dialSection = document.querySelector('.dial-section') || compassCard;
    dialSection.addEventListener('mousedown', onStart);
    window.addEventListener('mousemove', onMove);
    window.addEventListener('mouseup', onEnd);

    dialSection.addEventListener('touchstart', onStart, { passive: true });
    window.addEventListener('touchmove', onMove, { passive: true });
    window.addEventListener('touchend', onEnd);

    detachDesktopDragSimulation = function () {
      dialSection.removeEventListener('mousedown', onStart);
      window.removeEventListener('mousemove', onMove);
      window.removeEventListener('mouseup', onEnd);
      dialSection.removeEventListener('touchstart', onStart);
      window.removeEventListener('touchmove', onMove);
      window.removeEventListener('touchend', onEnd);
      dragSimulationInitialized = false;
      detachDesktopDragSimulation = function () {};
    };
  }

  // ═══ §8 CALIBRATION ═══════════════════════════════════════════
  // Manual offset, accuracy display, zero-to-north.
  // Future: extract to calibration.js.
  function updateCalibrationUI() {
    const formattedOffset = `${calibrationOffset >= 0 ? '+' : ''}${calibrationOffset.toFixed(1)}°`;
    if (calActiveOffsetVal) calActiveOffsetVal.textContent = formattedOffset;
    if (calOffsetBadge) calOffsetBadge.textContent = formattedOffset;

    let accLabel = 'Acc: ±3° (High)';
    let badgeClass = 'badge-high';

    if (sensorAccuracy !== null) {
      if (sensorAccuracy < 0) {
        accLabel = 'Uncalibrated';
        badgeClass = 'badge-low';
      } else if (sensorAccuracy <= 15) {
        accLabel = `Acc: ±${Math.round(sensorAccuracy)}° (High)`;
        badgeClass = 'badge-high';
      } else if (sensorAccuracy <= 25) {
        accLabel = `Acc: ±${Math.round(sensorAccuracy)}° (Good)`;
        badgeClass = 'badge-med';
      } else {
        accLabel = `Acc: ±${Math.round(sensorAccuracy)}° (Interference)`;
        badgeClass = 'badge-low';
      }
    } else if (isAbsoluteOrientation) {
      accLabel = 'Acc: ±3° (Absolute)';
      badgeClass = 'badge-high';
    } else if (hasSensorData) {
      accLabel = 'Relative Gyro';
      badgeClass = 'badge-med';
    } else {
      accLabel = 'Sensors Inactive';
      badgeClass = 'badge-low';
    }

    if (calAccuracyText) {
      calAccuracyText.textContent = accLabel;
    }
    if (calSensorBadge) {
      calSensorBadge.textContent = (isAbsoluteOrientation || (sensorAccuracy !== null && sensorAccuracy >= 0))
        ? 'Magnetometer Active'
        : 'Sensors Active';
      calSensorBadge.className = `cal-badge ${badgeClass}`;
    }
    if (sensorAccuracyBadge) {
      sensorAccuracyBadge.textContent = accLabel;
    }
  }

  function setCalibrationOffset(offset) {
    calibrationOffset = Math.round(offset * 10) / 10;
    while (calibrationOffset > 180) calibrationOffset -= 360;
    while (calibrationOffset < -180) calibrationOffset += 360;
    try {
      localStorage.setItem('kuberan-vastu-compass-offset', calibrationOffset.toString());
    } catch(e) { /* localStorage/vibrate may be blocked in private browsing */ }
    updateCalibrationUI();
    updateHeading(rawMagneticHeading, true);
    showToast(`Offset: ${calibrationOffset >= 0 ? '+' : ''}${calibrationOffset.toFixed(1)}°`);
  }

  function adjustCalibrationOffset(delta) {
    setCalibrationOffset(calibrationOffset + delta);
  }

  // --- GPS Location & Telemetry with Fast Coarse Lock & Refresh Handler ---
  function initGPS() {
    startGPS();
  }

  function applyLocationData(pos) {
    if (pos && pos.coords) {
      window.lastKnownLat = pos.coords.latitude;
      window.lastKnownLng = pos.coords.longitude;
    }
    if (!pos || !pos.coords) return;
    const lat = pos.coords.latitude;
    const lng = pos.coords.longitude;
    const alt = pos.coords.altitude;
    const acc = pos.coords.accuracy;

    if (gpsLat) gpsLat.textContent = formatDMS(lat, true);
    if (gpsLatDec) gpsLatDec.textContent = `${lat.toFixed(6)}°`;
    if (gpsLng) gpsLng.textContent = formatDMS(lng, false);
    if (gpsLngDec) gpsLngDec.textContent = `${lng.toFixed(6)}°`;

    if (gpsAlt) gpsAlt.textContent = alt !== null ? `${Math.round(alt)} m` : '-- m';
    if (gpsAccuracy) gpsAccuracy.textContent = `Accuracy: ±${Math.round(acc)} m`;

    // Compute magnetic declination for True North
    magneticDeclination = estimateMagneticDeclination(lat, lng);
    if (gpsDeclination) gpsDeclination.textContent = `${magneticDeclination >= 0 ? '+' : ''}${magneticDeclination}°`;
    if (sensorStatus) sensorStatus.textContent = isTrueNorth ? 'True North calibrated' : 'GPS Active';
  }

  function startGPS() {
    if (!('geolocation' in navigator)) {
      if (gpsLatDec) gpsLatDec.textContent = 'GPS not supported';
      return;
    }
    if (gpsWatchId !== null) return;

    if (gpsLatDec) gpsLatDec.textContent = 'Acquiring GPS fix...';
    if (gpsLngDec) gpsLngDec.textContent = 'Tap to refresh';

    // 1. Immediate Fast Coarse Position (Cell/Wi-Fi responds in <300ms)
    navigator.geolocation.getCurrentPosition(
      (pos) => applyLocationData(pos),
      (err) => { /* Fall through to high accuracy watch */ },
      { enableHighAccuracy: false, maximumAge: 300000, timeout: 6000 }
    );

    // 2. High Accuracy Satellite Watcher with Indoor Fallback
    gpsWatchId = navigator.geolocation.watchPosition(
      (pos) => applyLocationData(pos),
      (err) => {
        console.warn('GPS location code:', err.code, err.message);
        if (err.code === 1) { // PERMISSION_DENIED
          if (gpsLatDec) gpsLatDec.textContent = 'Permission Denied';
          if (gpsLngDec) gpsLngDec.textContent = 'Enable in browser';
          if (sensorStatus) sensorStatus.textContent = 'Standard Magnetic';
        } else if (err.code === 3) { // TIMEOUT (common indoors)
          // Fall back to low-accuracy network fix so user is NEVER left stranded
          navigator.geolocation.getCurrentPosition(
            (pos) => applyLocationData(pos),
            () => {
              if (gpsLatDec && gpsLatDec.textContent.includes('Acquiring')) {
                gpsLatDec.textContent = 'Weak GPS Signal';
                if (gpsLngDec) gpsLngDec.textContent = 'Tap to retry';
              }
            },
            { enableHighAccuracy: false, maximumAge: 60000, timeout: 10000 }
          );
        }
      },
      { enableHighAccuracy: true, maximumAge: 10000, timeout: 15000 }
    );
  }

  function stopGPS() {
    if (gpsWatchId !== null && 'geolocation' in navigator) {
      navigator.geolocation.clearWatch(gpsWatchId);
      gpsWatchId = null;
    }
  }

  function refreshGPS() {
    showToast('Refreshing GPS location...');
    stopGPS();
    startGPS();
  }

  // ═══ §9 TOOLS ═════════════════════════════════════════════════
  // Plot Tilt, Camera AR, Room Finder, Audit Report.
  // Future: extract each tool to its own module.
  function updatePlotTiltUI(heading) {
    const roundedHeading = parseFloat(heading.toFixed(1));
    plotHeadingVal.textContent = `${roundedHeading}°`;

    // Nearest cardinal axis (0, 90, 180, 270)
    let deviation = ((roundedHeading % 90) + 45) % 90 - 45;
    const absDev = Math.abs(deviation).toFixed(1);

    plotDeviationVal.textContent = `${absDev}° Deviation from Cardinal Axis`;

    const dict = (VASTU_DATA && VASTU_DATA.UI && VASTU_DATA.UI[currentLang]) || (VASTU_DATA && VASTU_DATA.UI && VASTU_DATA.UI.en) || {};
    const alignedTitle = dict.vidishaAligned || 'SAMA-SUTRA (Aligned Plot)';
    const tiltedTitleBase = dict.vidishaTilted || 'VIDISHA (Tilted Plot)';

    if (absDev <= 3.0) {
      if (plotStatusBanner) plotStatusBanner.className = 'plot-status-banner aligned';
      if (plotStatusTitle) plotStatusTitle.textContent = alignedTitle;
      if (plotStatusDesc) plotStatusDesc.textContent = dict.vidishaAlignedDesc || 'The property is naturally aligned with the cardinal geomagnetic axis (within ±3°). Highly auspicious and energetically balanced.';
    } else {
      if (plotStatusBanner) plotStatusBanner.className = 'plot-status-banner tilted';
      if (plotStatusTitle) plotStatusTitle.textContent = `${tiltedTitleBase} (${absDev}°)`;
      if (plotStatusDesc) plotStatusDesc.textContent = dict.vidishaTiltedDesc || 'The property walls are tilted relative to cardinal North. Recommended: Align internal work desks, Mandir, and bed axes towards Cardinal North.';
    }

    // Commercial Plot Shape geometry status
    const shapeObj = VASTU_DATA.PLOT_SHAPES && VASTU_DATA.PLOT_SHAPES[selectedPlotShape];
    if (shapeObj && plotShapeBadge && plotShapeAdviceText) {
      plotShapeBadge.className = `shape-badge ${shapeObj.badgeClass}`;
      plotShapeBadge.textContent = shapeObj.statusLabel;
      plotShapeAdviceText.textContent = (shapeObj.descriptions && shapeObj.descriptions[currentLang]) || shapeObj.commercialEffect;
    }
  }

  // --- Camera AR Mode (v5.5.2 Fullscreen Viewfinder & Spatial HUD) ---
  async function toggleCameraAR() {
    const btnQuickAR = document.getElementById('btnQuickAR');
    const toggleCamera = document.getElementById('toggle-camera-ar');
    const arOverlay = document.getElementById('arFullscreenOverlay');
    const arVideoFull = document.getElementById('arVideoFull');
    const btnArTapeToggle = document.getElementById('btnArTapeToggle');

    if (cameraStream) {
      // Turn OFF
      if (isArTorchOn) toggleArTorch(false);
      try {
        cameraStream.getTracks().forEach(t => t.stop());
      } catch (e) {
        console.warn('Error stopping camera tracks:', e);
      }
      cameraStream = null;
      if (arVideoFull) {
        try { arVideoFull.pause(); } catch (e) {}
        arVideoFull.srcObject = null;
      }
      if (cameraFeed) {
        try { cameraFeed.pause(); } catch (e) {}
        cameraFeed.srcObject = null;
      }
      if (arOverlay) arOverlay.classList.add('hidden');
      if (btnQuickAR) btnQuickAR.classList.remove('active');
      if (toggleCamera) toggleCamera.checked = false;
      showToast('AR Viewfinder closed');
    } else {
      // Turn ON Fullscreen Viewfinder with multi-tier hardware fallback
      let stream = null;

      // Tier 1: Ideal 1080p environment camera
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          audio: false,
          video: {
            facingMode: { ideal: 'environment' },
            width: { ideal: 1920 },
            height: { ideal: 1080 }
          }
        });
      } catch (err1) {
        console.warn('AR Tier 1 camera failed, trying basic environment:', err1);
        // Tier 2: Basic environment camera without strict resolution constraints
        try {
          stream = await navigator.mediaDevices.getUserMedia({
            audio: false,
            video: {
              facingMode: { ideal: 'environment' }
            }
          });
        } catch (err2) {
          console.warn('AR Tier 2 camera failed, trying fallback video device:', err2);
          // Tier 3: Any video device
          try {
            stream = await navigator.mediaDevices.getUserMedia({
              audio: false,
              video: true
            });
          } catch (err3) {
            console.error('All camera initialization tiers failed:', err3);
          }
        }
      }

      if (!stream) {
        if (btnQuickAR) btnQuickAR.classList.remove('active');
        if (toggleCamera) toggleCamera.checked = false;
        if (arOverlay) arOverlay.classList.add('hidden');
        showToast('Camera permission denied or camera device unavailable');
        return;
      }

      cameraStream = stream;

      // Hardware drop/interrupt listener
      stream.getVideoTracks().forEach(track => {
        track.addEventListener('ended', () => {
          if (cameraStream) toggleCameraAR();
        });
      });

      if (arVideoFull) {
        arVideoFull.setAttribute('playsinline', '');
        arVideoFull.setAttribute('webkit-playsinline', '');
        arVideoFull.muted = true;
        arVideoFull.volume = 0;
        arVideoFull.srcObject = stream;
        try {
          await arVideoFull.play();
        } catch (playErr) {
          console.warn('arVideoFull play error:', playErr);
        }
      }

      if (arOverlay) arOverlay.classList.remove('hidden');
      if (btnQuickAR) btnQuickAR.classList.add('active');
      if (toggleCamera) toggleCamera.checked = true;
      if (btnArTapeToggle) btnArTapeToggle.classList.add('active');

      renderArTapeTicks();
      updateArFullscreenHUD(currentHeading);
      showToast('📸 AR Viewfinder active: Align crosshairs with room wall');
    }
  }

  // --- Real-Time Update for Fullscreen AR HUD ---
  function updateArFullscreenHUD(heading) {
    const arOverlay = document.getElementById('arFullscreenOverlay');
    if (!arOverlay || arOverlay.classList.contains('hidden')) return;

    const activeZone = getActiveZone8(heading);
    const elem = VASTU_DATA.ELEMENTS[activeZone.element];

    const degNum = document.getElementById('arFsDegreeNum');
    const cardEl = document.getElementById('arFsCardinal');
    const elemEl = document.getElementById('arFsElement');
    const brandSub = document.getElementById('arZonePillSub');
    const badgeEl = document.getElementById('arFsAuspiciousBadge');
    const deityEl = document.getElementById('arFsDeityText');
    const adviceEl = document.getElementById('arFsAdviceText');

    const dict = (VASTU_DATA && VASTU_DATA.UI && VASTU_DATA.UI[currentLang]) || VASTU_DATA.UI.en;
    const zoneLocalName = activeZone.names[currentLang] || activeZone.names.en;
    const elemLocalName = elem ? (elem.names[currentLang] || elem.names.en) : activeZone.element;

    if (degNum) degNum.textContent = Math.round(heading);
    if (cardEl) cardEl.textContent = activeZone.code;
    if (elemEl) elemEl.textContent = (elemLocalName + ' (' + (elem ? elem.sanskrit : '') + ')').toUpperCase();
    if (brandSub) brandSub.textContent = zoneLocalName + ' • ' + activeZone.sanskrit;
    if (deityEl) deityEl.textContent = activeZone.deityNames[currentLang] || activeZone.deityNames.en;

    // Check favorability
    if (activeRoom) {
      const rName = activeRoom.names[currentLang] || activeRoom.names.en;
      if (activeRoom.idealZones.includes(activeZone.code)) {
        if (badgeEl) {
          badgeEl.textContent = (dict.entranceGradeA || 'AUSPICIOUS ✅') + ' (' + rName + ')';
          badgeEl.style.borderColor = '#22c55e';
          badgeEl.style.color = '#4ade80';
        }
      } else if (activeRoom.avoidZones.includes(activeZone.code)) {
        if (badgeEl) {
          badgeEl.textContent = (dict.entranceGradeC || 'DOSHA DEFECT ❌') + ' (' + rName + ')';
          badgeEl.style.borderColor = '#ef4444';
          badgeEl.style.color = '#fca5a5';
        }
      } else {
        if (badgeEl) {
          badgeEl.textContent = dict.entranceGradeB || 'NEUTRAL ⚖️';
          badgeEl.style.borderColor = '#eab308';
          badgeEl.style.color = '#fde047';
        }
      }
    } else {
      const isFav = ['NE', 'N', 'E'].includes(activeZone.code);
      if (badgeEl) {
        badgeEl.textContent = isFav ? (dict.entranceGradeA || 'AUSPICIOUS ✅') : (activeZone.code === 'SW' ? 'NAIRṚTYA MASTER ⚖️' : (dict.favorableRooms || 'FAVORABLE ✨'));
        badgeEl.style.borderColor = isFav ? '#22c55e' : '#eab308';
        badgeEl.style.color = isFav ? '#4ade80' : '#fde047';
      }
    }

    if (adviceEl) {
      adviceEl.textContent = activeZone.summary[currentLang] || activeZone.summary.en;
    }

    // Dynamic rotation for reticle outer ring (compass gimbal)
    const reticleOuter = document.querySelector('.ar-reticle-circle-outer');
    if (reticleOuter) {
      reticleOuter.style.transform = `rotate(${-heading}deg)`;
    }

    // Scroll Horizontal Ribbon Tape
    updateArTapePosition(heading);
  }

  // --- Horizontal Compass Ribbon Tape Generator (Triple-Wrap for Continuous 360° Panning) ---
  function renderArTapeTicks() {
    const track = document.getElementById('arTapeTrack');
    if (!track || track.dataset.built) return;

    // 3 complete cycles: cycle 0 (-360° to 0°), cycle 1 (0° to 360°), cycle 2 (360° to 720°)
    // Total width: 10800px (10px per degree, 3600px per cycle)
    let svgHtml = '<svg viewBox="0 0 10800 48" width="10800" height="48" style="position:absolute; top:0; left:0;">';
    const cardinals = { 0: 'N', 45: 'NE', 90: 'E', 135: 'SE', 180: 'S', 225: 'SW', 270: 'W', 315: 'NW' };

    for (let cycle = 0; cycle < 3; cycle++) {
      const baseX = cycle * 3600;
      for (let deg = 0; deg < 360; deg += 5) {
        const x = baseX + (deg * 10);
        const isMajor = deg % 45 === 0;
        const isMedium = deg % 15 === 0;
        const h = isMajor ? 28 : (isMedium ? 18 : 10);
        const stroke = isMajor ? '#22c55e' : (isMedium ? '#d4a359' : 'rgba(255,255,255,0.4)');
        const w = isMajor ? 2.5 : 1;
        svgHtml += '<line x1="' + x + '" y1="0" x2="' + x + '" y2="' + h + '" stroke="' + stroke + '" stroke-width="' + w + '"/>';
        if (isMajor) {
          svgHtml += '<text x="' + x + '" y="42" fill="' + (deg === 0 ? '#ef4444' : '#22c55e') + '" font-size="14" font-weight="800" text-anchor="middle" font-family="Inter,sans-serif">' + cardinals[deg] + '</text>';
        } else if (isMedium) {
          svgHtml += '<text x="' + x + '" y="36" fill="#cbd5e1" font-size="10" font-weight="600" text-anchor="middle" font-family="Inter,sans-serif">' + deg + '</text>';
        }
      }
    }
    svgHtml += '</svg>';
    track.innerHTML = svgHtml;
    track.dataset.built = 'true';
  }

  function updateArTapePosition(heading) {
    const track = document.getElementById('arTapeTrack');
    const wrap = document.querySelector('.ar-compass-tape-wrap');
    if (!track || !wrap) return;
    const centerOffset = wrap.clientWidth / 2;
    // Normalized heading clamped between 0 and 360
    const normalized = ((heading % 360) + 360) % 360;
    // Primary cycle is Cycle 1 (starts at x = 3600px)
    const targetX = centerOffset - (3600 + (normalized * 10));
    track.style.transform = 'translateX(' + targetX + 'px)';
  }

  // --- AR Torch Flashlight Handler ---
  async function toggleArTorch(forceState) {
    if (!cameraStream) return;
    const track = cameraStream.getVideoTracks()[0];
    if (!track) return;
    const btnArTorch = document.getElementById('btnArTorch');
    const btnArTorchFs = document.getElementById('btnArTorchFs');
    const arTorchLabel = document.getElementById('arTorchLabel');
    const arTorchFsText = document.getElementById('arTorchFsText');

    const nextState = forceState !== undefined ? forceState : !isArTorchOn;
    try {
      const capabilities = track.getCapabilities ? track.getCapabilities() : {};
      if ('torch' in capabilities || true) {
        await track.applyConstraints({
          advanced: [{ torch: nextState }]
        });
        isArTorchOn = nextState;
        if (btnArTorch) btnArTorch.classList.toggle('active', isArTorchOn);
        if (btnArTorchFs) btnArTorchFs.classList.toggle('active', isArTorchOn);
        if (arTorchLabel) arTorchLabel.textContent = isArTorchOn ? 'Torch ON' : 'Torch';
        if (arTorchFsText) arTorchFsText.textContent = isArTorchOn ? 'Torch ON' : 'Torch';
        showToast(isArTorchOn ? '🔦 Torch Enabled' : 'Torch Disabled');
      }
    } catch(err) {
      showToast('Torch not supported on this device lens');
    }
  }

    // --- AR Vastu Snapshot Generator & Canvas Watermarker ---
  async function captureArVastuSnapshot() {
    if (!cameraStream) {
      showToast('Please enable AR Cam first to take a snapshot');
      return;
    }
    const snapModal = document.getElementById('arSnapshotModal');
    const snapImg = document.getElementById('snapPreviewImg');
    const snapSpinner = document.getElementById('snapSpinner');

    if (snapModal) snapModal.classList.remove('hidden');
    if (snapSpinner) snapSpinner.classList.remove('hidden');

    try {
      const activeVideo = (document.getElementById('arVideoFull') && !document.getElementById('arFullscreenOverlay').classList.contains('hidden'))
        ? document.getElementById('arVideoFull')
        : cameraFeed;
      const vWidth = activeVideo.videoWidth || 1920;
      const vHeight = activeVideo.videoHeight || 1080;
      const canvas = document.createElement('canvas');
      canvas.width = vWidth;
      canvas.height = vHeight;
      const ctx = canvas.getContext('2d');

      // 1. Draw live video feed frame
      ctx.drawImage(activeVideo, 0, 0, vWidth, vHeight);

      // 2. Dark glass overlay vignette
      const gradient = ctx.createRadialGradient(vWidth/2, vHeight/2, vHeight*0.2, vWidth/2, vHeight/2, vHeight*0.8);
      gradient.addColorStop(0, 'rgba(0,0,0,0.1)');
      gradient.addColorStop(1, 'rgba(8,17,30,0.65)');
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, vWidth, vHeight);

      // 3. Draw Laser Alignment Guideline across wall
      ctx.strokeStyle = '#22c55e';
      ctx.lineWidth = 3;
      ctx.shadowColor = '#22c55e';
      ctx.shadowBlur = 10;
      ctx.beginPath();
      ctx.moveTo(0, vHeight / 2);
      ctx.lineTo(vWidth, vHeight / 2);
      ctx.stroke();
      ctx.shadowBlur = 0;

      // 4. Render Compass Dial Overlay in Center
      const dialSize = Math.min(vWidth, vHeight) * 0.72;
      const dialX = (vWidth - dialSize) / 2;
      const dialY = (vHeight - dialSize) / 2;

      // Serialize live SVG dial
      if (dialSvg) {
        const svgData = new XMLSerializer().serializeToString(dialSvg);
        const svgBlob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
        const svgUrl = URL.createObjectURL(svgBlob);
        const dialImg = new Image();
        await new Promise((resolve) => {
          dialImg.onload = () => {
            ctx.save();
            ctx.translate(vWidth / 2, vHeight / 2);
            ctx.rotate((-currentHeading * Math.PI) / 180);
            ctx.drawImage(dialImg, -dialSize / 2, -dialSize / 2, dialSize, dialSize);
            ctx.restore();
            URL.revokeObjectURL(svgUrl);
            resolve();
          };
          dialImg.onerror = resolve;
          dialImg.src = svgUrl;
        });
      }

      // 5. Official Kuberan Silks Branding & Inspection Telemetry Watermark
      const activeZone = getActiveZone8(currentHeading);
      const pada = getActivePada32(currentHeading);
      const nowStr = formatCurrentTimestamp();
      const gpsStr = (gpsLatDec && gpsLngDec && !gpsLatDec.textContent.includes('Acquiring'))
        ? gpsLatDec.textContent + ', ' + gpsLngDec.textContent
        : 'Bengaluru, India';

      // Header Banner Box
      ctx.fillStyle = 'rgba(8, 17, 30, 0.88)';
      ctx.fillRect(0, 0, vWidth, 90);
      ctx.fillStyle = '#d4a359';
      ctx.fillRect(0, 88, vWidth, 2);

      ctx.font = 'bold 26px "Playfair Display", Georgia, serif';
      ctx.fillStyle = '#d4a359';
      ctx.fillText('KUBERAN SILKS • VASTU AR INSPECTION', 24, 38);

      ctx.font = '14px Inter, sans-serif';
      ctx.fillStyle = '#f7eedd';
      ctx.fillText('Official Architectural Evidence • https://kuberansilks.com/ • ' + nowStr, 24, 66);

      // Bottom Telemetry Overlay Bar
      ctx.fillStyle = 'rgba(8, 17, 30, 0.88)';
      ctx.fillRect(0, vHeight - 100, vWidth, 100);
      ctx.fillStyle = '#d4a359';
      ctx.fillRect(0, vHeight - 100, vWidth, 2);

      // Heading & Zone pill
      ctx.font = 'bold 28px Inter, sans-serif';
      ctx.fillStyle = '#22c55e';
      ctx.fillText(Math.round(currentHeading) + '° ' + activeZone.code + ' (' + activeZone.names.en + ')', 24, vHeight - 56);

      ctx.font = '15px Inter, sans-serif';
      ctx.fillStyle = '#cbd5e1';
      ctx.fillText('Deity: ' + activeZone.deity + ' | Element: ' + activeZone.element + ' | Pada: ' + pada.id + ' (' + pada.devata + ')', 24, vHeight - 24);

      // GPS on right side
      ctx.font = '13px monospace';
      ctx.fillStyle = '#94a3b8';
      ctx.textAlign = 'right';
      ctx.fillText('GPS: ' + gpsStr, vWidth - 24, vHeight - 56);
      ctx.fillText('Ref: ' + (isTrueNorth ? 'True North' : 'Magnetic North') + ' | Kuberan Silks Chickpet', vWidth - 24, vHeight - 24);
      ctx.textAlign = 'left';

      const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
      if (snapImg) snapImg.src = dataUrl;
      window.lastArSnapshotBlobUrl = dataUrl;

      if (snapSpinner) snapSpinner.classList.add('hidden');
      triggerHapticTick(50);
      showToast('📸 AR Vastu Snapshot captured successfully!');
    } catch(err) {
      console.error('AR Snapshot error:', err);
      if (snapSpinner) snapSpinner.classList.add('hidden');
      showToast('Could not generate snapshot frame');
    }
  }

  // --- Multi-Room Site Walkthrough Manager ---
  function logCurrentRoomToWalkthrough(customRoomName) {
    const activeZone = getActiveZone8(currentHeading);
    const roomName = customRoomName || (activeRoom ? (activeRoom.names[currentLang] || activeRoom.names.en) : (activeZone.names[currentLang] || activeZone.names.en) + ' Sector');
    
    // Evaluate Auspiciousness
    let grade = 'neutral';
    let gradeLabel = 'Neutral';
    if (activeRoom) {
      if (activeRoom.idealZones.includes(activeZone.code)) {
        grade = 'auspicious';
        gradeLabel = 'Auspicious ✅';
      } else if (activeRoom.avoidZones.includes(activeZone.code)) {
        grade = 'defect';
        gradeLabel = 'Dosha Defect ❌';
      }
    } else {
      // General zone favorability
      if (['NE', 'N', 'E'].includes(activeZone.code)) {
        grade = 'auspicious';
        gradeLabel = 'Auspicious ✅';
      } else if (['SW'].includes(activeZone.code)) {
        grade = 'neutral';
        gradeLabel = 'Heavy Master Zone ⚖️';
      }
    }

    const logEntry = {
      id: Date.now(),
      roomName,
      heading: Math.round(currentHeading),
      zoneCode: activeZone.code,
      zoneName: activeZone.names.en,
      deity: activeZone.deity,
      element: activeZone.element,
      grade,
      gradeLabel,
      time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })
    };

    siteWalkthroughLogs.push(logEntry);
    try {
      localStorage.setItem('kuberan_site_walkthrough_logs', JSON.stringify(siteWalkthroughLogs));
    } catch(e) {}

    renderSiteWalkthroughUI();
    triggerHapticTick(30);
    showToast('Logged ' + roomName + ' to Site Audit (' + activeZone.code + ')');
  }

  function renderSiteWalkthroughUI() {
    const listEl = document.getElementById('siteWalkthroughList');
    const scoreBadge = document.getElementById('siteVastuScoreBadge');
    if (!listEl) return;

    if (siteWalkthroughLogs.length === 0) {
      listEl.innerHTML = '<div class="walkthrough-empty-prompt">Tap <strong>"+ Log Room"</strong> on any live direction to build a full multi-point property audit.</div>';
      if (scoreBadge) {
        scoreBadge.textContent = '100% Auspicious';
        scoreBadge.className = 'score-val';
      }
      return;
    }

    let html = '';
    let auspiciousCount = 0;
    siteWalkthroughLogs.forEach((item, index) => {
      if (item.grade === 'auspicious') auspiciousCount += 1;
      else if (item.grade === 'neutral') auspiciousCount += 0.5;

      const badgeCls = item.grade === 'auspicious' ? 'status-auspicious' : (item.grade === 'defect' ? 'status-defect' : 'status-neutral');
      html += `
        <div class="walkthrough-item">
          <div class="walkthrough-item-left">
            <span class="walkthrough-idx">#${index + 1}</span>
            <div>
              <strong>${item.roomName}</strong>
              <div style="font-size:0.7rem; color:var(--text-muted);">${item.heading}° • ${item.zoneCode} (${item.zoneName}) • ${item.time}</div>
            </div>
          </div>
          <div style="display:flex; align-items:center; gap:6px;">
            <span class="walkthrough-status-pill ${badgeCls}">${item.gradeLabel}</span>
            <button class="btn-remove-log" data-index="${index}" title="Remove entry">✕</button>
          </div>
        </div>
      `;
    });

    listEl.innerHTML = html;

    // Attach remove listeners
    listEl.querySelectorAll('.btn-remove-log').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const idx = parseInt(e.target.dataset.index, 10);
        siteWalkthroughLogs.splice(idx, 1);
        try { localStorage.setItem('kuberan_site_walkthrough_logs', JSON.stringify(siteWalkthroughLogs)); } catch(err) {}
        renderSiteWalkthroughUI();
      });
    });

    // Calculate score
    const scorePct = Math.round((auspiciousCount / siteWalkthroughLogs.length) * 100);
    if (scoreBadge) {
      scoreBadge.textContent = scorePct + '% Auspicious (' + siteWalkthroughLogs.length + ' Rooms)';
      scoreBadge.style.borderColor = scorePct >= 75 ? '#22c55e' : (scorePct >= 50 ? '#eab308' : '#ef4444');
      scoreBadge.style.color = scorePct >= 75 ? '#4ade80' : (scorePct >= 50 ? '#fde047' : '#fca5a5');
    }
  }


  // ═══ §10 LANGUAGE ═════════════════════════════════════════════
  // Multi-language switching (EN/HI/KN/TA/TE).
  function setText(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

  function setLanguage(langCode) {
    if (!VASTU_DATA.UI[langCode]) return;
    currentLang = langCode;
    if (langPill) langPill.textContent = langCode.toUpperCase();

    const dict = VASTU_DATA.UI[langCode];

    // Update Header
    setText('lblModeVastu', dict.vastuMode || 'Vastu Compass');
    setText('lblModeSimple', dict.simpleMode || 'Simple Compass');
    if (btnZone8) btnZone8.textContent = dict.zones8 || '8 Zones';
    if (btnZone16) btnZone16.textContent = dict.zones16 || '16 Zones';
    if (btnZone32) btnZone32.textContent = dict.zones32 || '32 Padas';

    setText('lblToolRoom', dict.toolsRoomFinder || 'Room Finder');
    setText('lblToolTilt', dict.toolsPlotTilt || 'Plot Tilt');
    setText('lblToolCam', dict.toolsCamera || 'Camera AR');
    setText('lblToolAudit', dict.toolsAudit || 'Vastu Report');

    setText('lblDeity', dict.deity || 'Ruling Deity');
    setText('lblFavorable', dict.favorableRooms || 'Favorable');
    setText('lblAvoid', dict.avoidPlacements || 'Avoid');

    setText('lblPitch', dict.pitch || 'PITCH');
    setText('lblRoll', dict.roll || 'ROLL');
    setText('lblCopyCoords', dict.copyReport ? 'Copy Coords' : 'Copy Coords');
    setText('lblInstallApp', dict.installApp || 'Install App');

    // Calibration Studio Localized Strings
    const lblBtnCal = document.getElementById('lblBtnCalibrate');
    if (lblBtnCal) lblBtnCal.textContent = dict.calibrate || 'Calibrate';
    const calModalTitle = document.getElementById('calModalTitle');
    if (calModalTitle) calModalTitle.textContent = dict.calibrationTitle || 'Compass Calibration';
    const calModalSub = document.getElementById('calModalSub');
    if (calModalSub) calModalSub.textContent = dict.calibrationSub || 'Hardware Magnetometer & Alignment';
    const lblCalSensor = document.getElementById('lblCalSensorStatus');
    if (lblCalSensor) lblCalSensor.textContent = dict.sensorStatusLabel || 'SENSOR STATUS:';
    const lblCalConf = document.getElementById('lblCalConfidence');
    if (lblCalConf) lblCalConf.textContent = dict.calibrationConfidence || 'CALIBRATION CONFIDENCE:';
    const lblCalManual = document.getElementById('lblCalManualOffset');
    if (lblCalManual) lblCalManual.textContent = dict.manualOffsetLabel || 'MANUAL OFFSET:';
    const lblFig8T = document.getElementById('lblFig8Title');
    if (lblFig8T) lblFig8T.textContent = dict.fig8Title || 'Wave Phone in Figure-8 Motion';
    const lblFig8D = document.getElementById('lblFig8Desc');
    if (lblFig8D) lblFig8D.textContent = dict.fig8Desc || 'Gently wave your phone in a figure-8 pattern in the air 3 to 4 times to reset the internal magnetometer and clear local magnetic bias.';
    const lblManualT = document.getElementById('lblManualOffsetTitle');
    if (lblManualT) lblManualT.textContent = dict.manualOffsetTitle || 'Manual Calibration Offset';
    const lblCalH = document.getElementById('lblCalHint');
    if (lblCalH) lblCalH.textContent = dict.calHint || 'Compensate for magnetic phone cases or fine-tune against an external reference needle.';
    const lblBtnZero = document.getElementById('lblBtnZeroToNorth');
    if (lblBtnZero) lblBtnZero.textContent = dict.zeroToNorthBtn || 'Set Current Heading as True Reference';
    const btnResetEl = document.getElementById('btnOffsetReset');
    if (btnResetEl) btnResetEl.textContent = dict.resetOffset || 'Reset (0°)';

    // Commercial & Retail UI Translations
    const lblPropRes = document.getElementById('lblPropResidential');
    if (lblPropRes) lblPropRes.textContent = dict.propertyResidential || 'Residential Vastu';
    const lblPropComm = document.getElementById('lblPropCommercial');
    if (lblPropComm) lblPropComm.textContent = dict.propertyCommercial || 'Commercial & Retail';
    const lblBizCat = document.getElementById('lblBusinessCategory');
    if (lblBizCat) lblBizCat.textContent = dict.businessCategory ? `${dict.businessCategory}:` : 'Business Category:';
    const lblCommSuit = document.getElementById('lblCommSuitability');
    if (lblCommSuit) lblCommSuit.textContent = dict.commercialSuitability || 'Commercial Suitability';
    const lblBizImp = document.getElementById('lblBusinessImpact');
    if (lblBizImp) lblBizImp.textContent = dict.businessImpact || 'Business Impact';
    const lblPlotTitle = document.getElementById('lblPlotShapeTitle');
    if (lblPlotTitle) lblPlotTitle.textContent = dict.plotShapeTitle || 'Commercial Plot Geometry & Shape';
    const lblCommCheck = document.getElementById('lblCommercialChecklist');
    if (lblCommCheck) lblCommCheck.textContent = dict.commercialChecklist ? `${dict.commercialChecklist}:` : 'Commercial Compliance Audit:';
    const lblCheckOwner = document.getElementById('lblCheckOwner');
    if (lblCheckOwner) lblCheckOwner.textContent = dict.ownerDeskCheck || 'Owner/MD Desk:';
    const lblCheckSafe = document.getElementById('lblCheckSafe');
    if (lblCheckSafe) lblCheckSafe.textContent = dict.cashSafeCheck || 'Cash Safe:';
    const lblCheckStock = document.getElementById('lblCheckStock');
    if (lblCheckStock) lblCheckStock.textContent = dict.inventoryCheck || 'Inventory Flow:';
    const lblCheckFire = document.getElementById('lblCheckFire');
    if (lblCheckFire) lblCheckFire.textContent = dict.fireElectricalCheck || 'Electrical Safety:';

    // Re-render Dial and Inspector
    const selLangEl = document.getElementById('setting-lang');
    if (selLangEl) selLangEl.value = langCode;
    const lblBtnCopy = document.getElementById('lblBtnCopyReport');
    if (lblBtnCopy && dict.copyReport) lblBtnCopy.textContent = dict.copyReport;
    const lblBtnShare = document.getElementById('lblBtnShareReport');
    if (lblBtnShare && dict.shareReport) lblBtnShare.textContent = dict.shareReport;

    buildDialSvg();
    updateVastuInspector(currentHeading);
    renderRoomsGrid();
    renderLangModal();

    showToast(`Language switched: ${VASTU_DATA.LANGUAGES.find(l => l.code === langCode).native}`);
  }

  function renderLangModal() {
    let html = '';
    VASTU_DATA.LANGUAGES.forEach(l => {
      const activeClass = l.code === currentLang ? 'active' : '';
      html += `
        <button class="lang-btn ${activeClass}" data-lang="${l.code}">
          <span>${l.native}</span>
          <span style="font-size:0.75rem; opacity:0.7;">${l.label}</span>
        </button>
      `;
    });
    langOptionsList.innerHTML = html;

    langOptionsList.querySelectorAll('.lang-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        setLanguage(btn.dataset.lang);
        langModal.classList.add('hidden');
      });
    });
  }

  // --- Room Finder Modal & Grid ---
  function renderRoomsGrid() {
    let html = '';
    const roomList = (roomCategoryTab === 'commercial' && VASTU_DATA.COMMERCIAL_ROOMS) ? VASTU_DATA.COMMERCIAL_ROOMS : VASTU_DATA.ROOMS;
    roomList.forEach(room => {
      const isSelected = activeRoom && activeRoom.id === room.id ? 'active' : '';
      const name = room.names[currentLang] || room.names.en;
      html += `
        <button class="room-card-btn ${isSelected}" data-room-id="${room.id}">
          <span class="room-card-icon">${room.icon}</span>
          <span class="room-card-name">${name}</span>
          <span class="room-card-zones">Best: ${room.idealZones.join(', ')}</span>
        </button>
      `;
    });
    roomsGrid.innerHTML = html;

    roomsGrid.querySelectorAll('.room-card-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const roomId = btn.dataset.roomId;
        selectRoom(roomId);
        roomFinderModal.classList.add('hidden');
      });
    });
  }

  function selectRoom(roomId) {
    const room = VASTU_DATA.ROOMS.find(r => r.id === roomId) || (VASTU_DATA.COMMERCIAL_ROOMS && VASTU_DATA.COMMERCIAL_ROOMS.find(r => r.id === roomId));
    if (!room) return;

    activeRoom = room;
    if (btnToolRoomFinder) btnToolRoomFinder.classList.add('active');
    const btnDockRoom = document.getElementById('btnDockRoomFinder');
    if (btnDockRoom) btnDockRoom.classList.add('active');
    if (roomGuidanceBanner) roomGuidanceBanner.classList.remove('hidden');

    if (guideRoomIcon) guideRoomIcon.textContent = room.icon;
    if (guideRoomName) guideRoomName.textContent = room.names[currentLang] || room.names.en;
    if (guideTargetBadge) guideTargetBadge.textContent = `Ideal: ${room.idealZones.join(', ')}`;
    if (guideStatusText) guideStatusText.textContent = 'Rotate device toward auspicious zone';

    buildDialSvg();
    updateVastuInspector(currentHeading);
    showToast(`Highlighting auspicious directions for ${room.names[currentLang] || room.names.en}`);
  }

  function clearActiveRoom() {
    activeRoom = null;
    if (btnToolRoomFinder) btnToolRoomFinder.classList.remove('active');
    const btnDockRoom = document.getElementById('btnDockRoomFinder');
    if (btnDockRoom) btnDockRoom.classList.remove('active');
    if (roomGuidanceBanner) roomGuidanceBanner.classList.add('hidden');
    buildDialSvg();
    updateVastuInspector(currentHeading);
    showToast('Room Finder cleared');
  }

  // --- Vishwakarma Prakash Field Diagnostics Evaluator (Bhumi-Plava, Dvara-Vedha & Vithi-Shula) ---
  function updateShastraDiagnosticsUI() {
    const diagData = VASTU_DATA.SHASTRA_DIAGNOSTICS;
    if (!diagData) return;

    const selPlava = document.getElementById('selectBhumiPlava');
    const selVedha = document.getElementById('selectDvaraVedha');
    const selShula = document.getElementById('selectVithiShula');
    const verdictEl = document.getElementById('shastraDiagnosticVerdict');
    const reportDiagEl = document.getElementById('reportShastraDiagnostics');

    const plavaKey = (selPlava && selPlava.value) || 'NE_SLOPE';
    const vedhaKey = (selVedha && selVedha.value) || 'NONE';
    const shulaKey = (selShula && selShula.value) || 'NONE';

    const plavaObj = diagData.BHUMI_PLAVA[plavaKey] || diagData.BHUMI_PLAVA.NE_SLOPE;
    const vedhaObj = diagData.DVARA_VEDHA[vedhaKey] || diagData.DVARA_VEDHA.NONE;
    const shulaObj = diagData.VITHI_SHULA[shulaKey] || diagData.VITHI_SHULA.NONE;

    if (reportDiagEl) {
      reportDiagEl.textContent = `${plavaObj.badge} • ${vedhaObj.badge} • ${shulaObj.badge}`;
    }

    const hasDosha = plavaObj.status === 'dosha' || vedhaObj.status === 'dosha' || shulaObj.status === 'dosha' || shulaObj.status === 'warning';
    if (verdictEl) {
      verdictEl.classList.toggle('has-dosha', hasDosha);
      let notes = [];
      notes.push(`<div><strong>1. Slope (${plavaObj.badge}):</strong> ${plavaObj.verdict}</div>`);
      if (vedhaKey !== 'NONE') {
        notes.push(`<div style="margin-top:4px;"><strong>2. Door Vedha (${vedhaObj.badge}):</strong> ${vedhaObj.verdict}</div>`);
      } else {
        notes.push(`<div style="margin-top:4px;"><strong>2. Door Threshold (${vedhaObj.badge}):</strong> Clear unobstructed entrance.</div>`);
      }
      if (shulaKey !== 'NONE') {
        notes.push(`<div style="margin-top:4px;"><strong>3. Road Thrust (${shulaObj.badge}):</strong> ${shulaObj.verdict}</div>`);
      }
      verdictEl.innerHTML = notes.join('');
    }
  }

  // --- Vastu Inspection Audit Report Generator ---
  function openAuditModal() {
    renderSiteWalkthroughUI();
    const activeZone8 = getActiveZone8(currentHeading);
    const elem = VASTU_DATA.ELEMENTS[activeZone8.element];
    const rounded = Math.round(currentHeading);

    reportTimestamp.textContent = `Generated: ${formatCurrentTimestamp()}`;
    reportHeading.textContent = `${rounded}° ${headingCardinal.textContent} (${isTrueNorth ? 'True North' : 'Magnetic'})`;
    reportZone.textContent = `${activeZone8.names[currentLang] || activeZone8.names.en} • ${activeZone8.sanskrit}`;
    reportElement.textContent = elem.names[currentLang] || elem.names.en;
    reportDeity.textContent = activeZone8.deityNames[currentLang] || activeZone8.deityNames.en;

    const lat = gpsLat.textContent;
    const lng = gpsLng.textContent;
    reportGps.textContent = `${lat}, ${lng}`;

    const activePada = getActivePada32(currentHeading);
    const activeAntar = getActiveAntarDevata(currentHeading);
    if (reportDoor) {
      reportDoor.textContent = `${activePada.id} ${activePada.devata} (Grade ${activePada.grade} — ${activePada.grade === 'A' ? 'Auspicious' : (activePada.grade === 'B' ? 'Neutral' : 'Avoid')})`;
    }
    const reportAntarDevata = document.getElementById('reportAntarDevata');
    if (reportAntarDevata && activeAntar) {
      reportAntarDevata.textContent = `${activeAntar.name} (${activeAntar.ring})`;
    }
    updateShastraDiagnosticsUI();

    const currentRoomObj = activeRoom;
    const dirName = activeZone8.names[currentLang] || activeZone8.names.en;
    
    // Trigger Vastu Analysis API (Local Mock)
    const zKey = activeZone8.code;
    fetchVastuAnalysis(dirName, currentRoomObj, zKey);

    if (plotTiltReading) {
      reportPlot.textContent = `${plotTiltReading.type} (${plotTiltReading.dev}° tilt)`;
    } else {
      reportPlot.textContent = 'Standard Cardinal Inspection';
    }

    // Commercial Property vs Residential Audit parameters
    if (reportPropertyType) {
      reportPropertyType.textContent = propertyType === 'commercial' ? 'Commercial & Retail' : 'Residential';
    }
    if (propertyType === 'commercial') {
      if (reportCategoryRow) reportCategoryRow.classList.remove('hidden');
      if (reportPlotShapeRow) reportPlotShapeRow.classList.remove('hidden');
      if (commercialChecklistBox) commercialChecklistBox.classList.remove('hidden');

      const prof = VASTU_DATA.RETAIL_PROFILES && VASTU_DATA.RETAIL_PROFILES.find(p => p.profile_id === retailProfile);
      if (reportBusinessCategory) {
        reportBusinessCategory.textContent = prof ? (prof.name[currentLang] || prof.name.en) : 'Apparel, Silk Sarees & Boutiques';
      }
      const shapeObj = VASTU_DATA.PLOT_SHAPES && VASTU_DATA.PLOT_SHAPES[selectedPlotShape];
      if (reportPlotShape) {
        reportPlotShape.textContent = shapeObj ? `${shapeObj.name} • ${shapeObj.statusLabel}` : 'Shermukhi (Lion-Faced)';
      }
    } else {
      if (reportCategoryRow) reportCategoryRow.classList.add('hidden');
      if (reportPlotShapeRow) reportPlotShapeRow.classList.add('hidden');
      if (commercialChecklistBox) commercialChecklistBox.classList.add('hidden');
    }

    reportAdvice.textContent = inspTipText.textContent || activeZone8.tips[currentLang] || activeZone8.tips.en;

    auditModal.classList.remove('hidden');
  }

  function generateAuditTextReport() {
    const activeZone8 = getActiveZone8(currentHeading);
    const elem = VASTU_DATA.ELEMENTS[activeZone8.element];
    const activePada = getActivePada32(currentHeading);
    const prof = VASTU_DATA.RETAIL_PROFILES && VASTU_DATA.RETAIL_PROFILES.find(p => p.profile_id === retailProfile);
    const shapeObj = VASTU_DATA.PLOT_SHAPES && VASTU_DATA.PLOT_SHAPES[selectedPlotShape];

    let commercialText = '';
    if (propertyType === 'commercial') {
      commercialText = `
🏢 Property Type: Commercial & Retail
🛍️ Business Profile: ${prof ? (prof.name[currentLang] || prof.name.en) : 'Apparel, Silk Sarees & Boutiques'}
📐 Commercial Plot Shape: ${shapeObj ? shapeObj.name : 'Shermukhi (Lion-Faced)'} [${shapeObj ? shapeObj.statusLabel : 'Ideal for Retail'}]

📋 Commercial Compliance Checklist:
• Owner / MD Seating (SW Zone facing N/E): ✓ Verified
• Cash Locker / Safe Placement (SW opening North): ✓ Verified
• Fast Stock Circulation (NW Vayavya Zone): ✓ Verified
• Electrical Panel & DB Box (SE Agneya Fire Zone): ✓ Verified
`;
    }

    let walkthroughText = '';
    if (siteWalkthroughLogs && siteWalkthroughLogs.length > 0) {
      let auspCount = 0;
      const lines = siteWalkthroughLogs.map((item, idx) => {
        if (item.grade === 'auspicious') auspCount += 1;
        else if (item.grade === 'neutral') auspCount += 0.5;
        return `  #${idx + 1}. ${item.roomName}: ${item.heading}° ${item.zoneCode} (${item.zoneName}) — ${item.gradeLabel}`;
      });
      const scorePct = Math.round((auspCount / siteWalkthroughLogs.length) * 100);
      walkthroughText = `\n🏛️ Property Site Walkthrough Scorecard (${scorePct}% Auspicious):\n${lines.join('\n')}\n`;
    }

    let remediesText = '';
    if (activeRoom) {
      const analysis = generateLocalVastuAnalysis(activeZone8.names[currentLang] || activeZone8.names.en, activeRoom, activeZone8.code);
      if (analysis && !analysis.isCompliant && analysis.remedies) {
        const allRemedies = [
          ...(analysis.remedies.simple_fixes || []),
          ...(analysis.remedies.elemental_cures || []),
          ...(analysis.remedies.vastu_instruments || [])
        ];
        if (allRemedies.length > 0) {
          remediesText = `\n⚡ Vastu Dosha Remedies (${analysis.room} in ${activeZone8.code}):\n• ${allRemedies.slice(0, 5).join('\n• ')}\n`;
        }
      }
    }

    return `🏛️ KUBERAN VASTU COMPASS AUDIT REPORT
-----------------------------------------
Official Vedic Architecture Report
Presented by KUBERAN Silks (https://kuberansilks.com/)

📅 Date & Time: ${formatCurrentTimestamp()}
🧭 Heading: ${Math.round(currentHeading)}° (${isTrueNorth ? 'True North' : 'Magnetic North'})
🕉️ Vastu Zone: ${activeZone8.names[currentLang] || activeZone8.names.en} (${activeZone8.sanskrit})
🌊 Element: ${elem.names[currentLang] || elem.names.en}
👑 Ruling Deity: ${activeZone8.deityNames[currentLang] || activeZone8.deityNames.en}
🚪 32-Pada Outer Door Deity: ${activePada.id} - ${activePada.devata} [Grade ${activePada.grade}]
🕉️ 45-Chakra Inner Deity: ${getActiveAntarDevata(currentHeading) ? getActiveAntarDevata(currentHeading).name : 'Aryamā'}
📜 Shastra Diagnostics (Plava/Vedha): ${document.getElementById('reportShastraDiagnostics') ? document.getElementById('reportShastraDiagnostics').textContent : 'Śubha Plava • Śuddha-Dvāra'}
📍 GPS Coordinates: ${gpsLat.textContent}, ${gpsLng.textContent}
⛰️ Altitude: ${gpsAlt.textContent}${commercialText}${walkthroughText}${remediesText}

💡 Vedic Recommendation:
${inspTipText.textContent || activeZone8.tips[currentLang] || activeZone8.tips.en}

Explore official luxury silk & spiritual collections at:
https://kuberansilks.com/`;
  }

  // --- Toast Notification ---
  function showToast(msg) {
    toast.textContent = msg;
    toast.classList.remove('hidden');
    toast.classList.remove('fade');
    void toast.offsetWidth;
    setTimeout(() => toast.classList.add('fade'), 2200);
    setTimeout(() => toast.classList.add('hidden'), 2600);
  }


  // ═══ §11 AYADI ════════════════════════════════════════════════
  // Shadvarga Calculator (perimeter-based formulas per Manasara).
  // Future: extract to AyadiCalculator.js.
  const btnToolAyadi = document.getElementById('btnToolAyadi');
  const ayadiModal = document.getElementById('ayadiModal');
  const btnCloseAyadiModal = document.getElementById('btnCloseAyadiModal');
  const btnCalculateAyadi = document.getElementById('btnCalculateAyadi');
  const ayadiLength = document.getElementById('ayadiLength');
  const ayadiWidth = document.getElementById('ayadiWidth');
  const ayadiResults = document.getElementById('ayadiResults');
  const ayadiReportContent = document.getElementById('ayadiReportContent');

  if (btnToolAyadi) {
    btnToolAyadi.addEventListener('click', () => {
      ayadiModal.classList.remove('hidden');
    });
  }

  if (btnCloseAyadiModal) {
    btnCloseAyadiModal.addEventListener('click', () => {
      ayadiModal.classList.add('hidden');
    });
  }

  function runAyadiCalculation() {
    const l = parseFloat(ayadiLength.value);
    const w = parseFloat(ayadiWidth.value);

    if (isNaN(l) || isNaN(w) || l <= 0 || w <= 0) {
      showToast('Please enter valid length and width');
      return;
    }

    const traditionSelect = document.getElementById('ayadiTraditionSelect');
    const tradition = (traditionSelect && traditionSelect.value) || 'vishwakarma';

    // Convert feet to Hastas (1 Hasta = 18 inches = 1.5 feet per Vishwakarma Prakash & Manasara)
    const hastaL = l / 1.5;
    const hastaW = w / 1.5;
    const perimeter = Math.round(2 * (hastaL + hastaW));
    const area = Math.round(hastaL * hastaW);

    if (perimeter <= 0 || area <= 0) {
      showToast('Dimensions too small to calculate');
      return;
    }

    // Pinda (Base Measure): Kshetraphala (Area) in Vishwakarma Prakash vs Paridhi (Perimeter) in Manasara
    const pinda = (tradition === 'vishwakarma') ? area : perimeter;
    const pindaLabel = (tradition === 'vishwakarma')
      ? `Kṣetraphala (Area = ${area} sq. Hastas)`
      : `Paridhi (Perimeter = ${perimeter} Hastas)`;

    // Classical Ayadi Saptavarga / Shadvarga Formulas
    const aaya = ((pinda * 8) % 12) || 12;          // 1. Aaya (Income / Gain)
    const vyaya = ((pinda * 9) % 10) || 10;         // 2. Vyaya (Expenditure / Loss)
    let yoni = ((pinda * 3) % 8);                   // 3. Yoni (Cosmic Orientation)
    if (yoni === 0) yoni = 8;
    const grihaAyu = ((area * 8) % 120) || 120;     // 4. Griha-Ayu (Building Lifespan in Years per Vishwakarma Prakash)
    const nakshatra = ((pinda * 8) % 27) || 27;     // 5. Nakshatra (Lunar Mansion)
    const vaara = ((pinda * 9) % 7) || 7;           // 6. Vaara (Solar Day)
    const tithi = ((pinda * 8) % 30) || 30;         // 7. Tithi (Lunar Day)

    const yoniNames = {
      1: 'Dhvaja (Flag - East)',
      2: 'Dhūma (Smoke - SE)',
      3: 'Siṃha (Lion - South)',
      4: 'Śvā (Dog - SW)',
      5: 'Vṛṣabha (Bull - West)',
      6: 'Khara (Donkey - NW)',
      7: 'Gaja (Elephant - North)',
      8: 'Kāka (Crow - NE)'
    };
    const yoniAuspicious = {1: true, 3: true, 5: true, 7: true, 2: false, 4: false, 6: false, 8: false};
    const isDirghayu = grihaAyu >= 60;

    const nakshatraNames = ['Ashwini','Bharani','Krittika','Rohini','Mrigashira','Ardra','Punarvasu','Pushya','Ashlesha','Magha','P.Phalguni','U.Phalguni','Hasta','Chitra','Swati','Vishakha','Anuradha','Jyeshtha','Mula','P.Ashadha','U.Ashadha','Shravana','Dhanishta','Shatabhisha','P.Bhadrapada','U.Bhadrapada','Revati'];
    const vaaraNames = ['', 'Sunday (Ravi)', 'Monday (Soma)', 'Tuesday (Mangal)', 'Wednesday (Budha)', 'Thursday (Guru)', 'Friday (Shukra)', 'Saturday (Shani)'];

    let html = '';

    // Input & Tradition Summary
    html += `<p style="opacity:0.85; font-size:0.82rem; margin-bottom:10px; padding:6px 8px; background:rgba(212,163,89,0.1); border-radius:6px;">
      <strong>Tradition:</strong> ${tradition === 'vishwakarma' ? '📜 Vishwakarma Prakash (Kṣetraphala)' : '🏛️ Manasara Shilpa Shastra (Paridhi)'}<br>
      <strong>Dimensions:</strong> ${l}ft × ${w}ft → ${hastaL.toFixed(1)} × ${hastaW.toFixed(1)} Hastas (1 Hasta = 18")<br>
      <strong>Base Piṇḍa:</strong> ${pindaLabel}
    </p>`;

    // 1. Aaya vs Vyaya
    html += `<p><strong>1. Āya (Income):</strong> ${aaya}/12 &nbsp;|&nbsp; <strong>2. Vyaya (Expense):</strong> ${vyaya}/10</p>`;
    if (aaya > vyaya) {
      html += `<p style="color:#a7f3d0; margin-bottom:10px;">✅ <strong>Dhana-Vṛddhi (Net Positive Gain):</strong> Āya exceeds Vyaya (+ ${aaya - vyaya} surplus).</p>`;
    } else if (aaya === vyaya) {
      html += `<p style="color:#fde68a; margin-bottom:10px;">⚠️ <strong>Sama (Neutral):</strong> Income equals Expense.</p>`;
    } else {
      html += `<p style="color:#fca5a5; margin-bottom:10px;">❌ <strong>Vyaya-Adhikya (Loss):</strong> Expense exceeds Income. Adjust length/width by ±0.5 ft.</p>`;
    }

    // 2. Yoni
    html += `<p><strong>3. Yoni (Cosmic Direction):</strong> ${yoni} — ${yoniNames[yoni]}</p>`;
    if (yoniAuspicious[yoni]) {
      html += `<p style="color:#a7f3d0; margin-bottom:10px;">✅ <strong>Śubha Yoni:</strong> Odd-numbered Yoni brings stability and prosperity.</p>`;
    } else {
      html += `<p style="color:#fca5a5; margin-bottom:10px;">❌ <strong>Ugra/Asura Yoni:</strong> Even-numbered Yoni causes friction and obstacles.</p>`;
    }

    // 3. Griha-Ayu (Building Lifespan per Vishwakarma Prakash)
    html += `<p><strong>4. Gṛha-Āyu (Building Lifespan):</strong> ${grihaAyu} / 120 Years</p>`;
    if (isDirghayu) {
      html += `<p style="color:#a7f3d0; margin-bottom:10px;">✅ <strong>Dīrghāyu (Long-Lived ≥ 60 yrs):</strong> Enduring multi-generational prosperity.</p>`;
    } else {
      html += `<p style="color:#fde68a; margin-bottom:10px;">⚠️ <strong>Alpāyu (< 60 yrs):</strong> Moderate longevity; slight dimension adjustment recommended.</p>`;
    }

    // 4. Nakshatra, Vaara, Tithi
    html += `<p><strong>5. Nakṣatra:</strong> ${nakshatra} — ${nakshatraNames[(nakshatra - 1) % 27]} &nbsp;|&nbsp; <strong>6. Vāra:</strong> ${vaaraNames[vaara]} &nbsp;|&nbsp; <strong>7. Tithi:</strong> ${tithi}</p>`;

    // Overall Verdict & Badge Sync
    const score = (aaya > vyaya ? 1 : 0) + (yoniAuspicious[yoni] ? 1 : 0) + (isDirghayu ? 1 : 0);
    const overallBadge = document.getElementById('ayadiOverallBadge');
    if (score === 3) {
      if (overallBadge) {
        overallBadge.textContent = '🕉️ SUPREME SHASTRA ALIGNMENT (3/3)';
        overallBadge.style.color = '#a7f3d0';
      }
      html += `<div style="margin-top:12px; padding:10px; background:rgba(16,185,129,0.15); border:1px solid #10b981; border-radius:8px;"><strong style="color:#a7f3d0;">🕉️ OVERALL: HIGHLY AUSPICIOUS (3/3)</strong><br><span style="font-size:0.82rem;">Āya > Vyaya, Auspicious Odd Yoni, and Dīrghāyu (${grihaAyu} yrs) are all fulfilled per Vishwakarma Prakash.</span></div>`;
    } else if (score === 2) {
      if (overallBadge) {
        overallBadge.textContent = '✅ AUSPICIOUS (2/3)';
        overallBadge.style.color = '#fde68a';
      }
      html += `<div style="margin-top:12px; padding:10px; background:rgba(253,230,138,0.15); border:1px solid #fde68a; border-radius:8px;"><strong style="color:#fde68a;">✅ OVERALL: FAVORABLE (2/3 PARAMETERS MET)</strong><br><span style="font-size:0.82rem;">Two of three primary proportions are auspicious. Adjust by ±0.5 ft if you wish to achieve 3/3 perfection.</span></div>`;
    } else {
      if (overallBadge) {
        overallBadge.textContent = '❌ ADJUSTMENT NEEDED';
        overallBadge.style.color = '#fca5a5';
      }
      html += `<div style="margin-top:12px; padding:10px; background:rgba(252,165,165,0.15); border:1px solid #fca5a5; border-radius:8px;"><strong style="color:#fca5a5;">❌ OVERALL: INAUSPICIOUS PROPORTIONS</strong><br><span style="font-size:0.82rem;">Use the + / - steppers above to adjust Length or Width by 0.5 ft until Āya > Vyaya and Yoni is Odd (1, 3, 5, or 7).</span></div>`;
    }

    // If score < 3, automatically search nearby dimensions (±0.5ft to ±3.0ft) for a 3/3 Supreme Shastric match
    if (score < 3) {
      let bestMatch = null;
      let minDelta = 999;
      for (let dl = -3; dl <= 3; dl += 0.5) {
        for (let dw = -3; dw <= 3; dw += 0.5) {
          const candL = l + dl;
          const candW = w + dw;
          if (candL <= 3 || candW <= 3) continue;
          const hL = candL / 1.5;
          const hW = candW / 1.5;
          const cPerim = Math.round(2 * (hL + hW));
          const cArea = Math.round(hL * hW);
          const cPinda = (tradition === 'vishwakarma') ? cArea : cPerim;
          const cAaya = ((cPinda * 8) % 12) || 12;
          const cVyaya = ((cPinda * 9) % 10) || 10;
          const cYoni = ((cPinda * 3) % 8) || 8;
          const cAyu = ((cArea * 8) % 120) || 120;
          if (cAaya > cVyaya && yoniAuspicious[cYoni] && cAyu >= 60) {
            const dist = Math.abs(dl) + Math.abs(dw);
            if (dist > 0 && dist < minDelta) {
              minDelta = dist;
              bestMatch = { l: candL, w: candW, aaya: cAaya, vyaya: cVyaya, yoni: cYoni, ayu: cAyu };
            }
          }
        }
      }
      if (bestMatch) {
        html += `<div style="margin-top:8px; padding:8px 10px; background:rgba(212,163,89,0.14); border:1px dashed var(--kuberan-gold); border-radius:8px; font-size:0.78rem;">
          💡 <strong>Vishwakarma Shastra Suggestion:</strong> Adjusting to <strong>${bestMatch.l.toFixed(1)} ft × ${bestMatch.w.toFixed(1)} ft</strong> achieves <strong>3/3 Supreme Alignment</strong> (Āya ${bestMatch.aaya} > Vyaya ${bestMatch.vyaya}, ${yoniNames[bestMatch.yoni]}, Gṛha-Āyu ${bestMatch.ayu} yrs).
          <button type="button" id="btnApplyBestAyadi" data-l="${bestMatch.l}" data-w="${bestMatch.w}" style="margin-left:6px; padding:2px 8px; border-radius:6px; border:1px solid var(--kuberan-gold); background:rgba(212,163,89,0.25); color:#fff; font-weight:700; cursor:pointer; font-size:0.72rem;">Apply ${bestMatch.l}×${bestMatch.w}ft</button>
        </div>`;
      }
    }

    ayadiReportContent.innerHTML = html;
    ayadiResults.classList.remove('hidden');
    const btnApplyBest = document.getElementById('btnApplyBestAyadi');
    if (btnApplyBest) {
      btnApplyBest.addEventListener('click', () => {
        ayadiLength.value = btnApplyBest.dataset.l;
        ayadiWidth.value = btnApplyBest.dataset.w;
        runAyadiCalculation();
      });
    }
  }

  if (btnCalculateAyadi) {
    btnCalculateAyadi.addEventListener('click', runAyadiCalculation);
  }
  const ayadiTraditionSelectEl = document.getElementById('ayadiTraditionSelect');
  if (ayadiTraditionSelectEl) {
    ayadiTraditionSelectEl.addEventListener('change', runAyadiCalculation);
  }

  // ═══ §14 EVENTS ═══════════════════════════════════════════════
  // All event listener bindings.
  // Future: extract to events.js or framework component lifecycle.
  function setupEventListeners() {
    // ─── v5.3.0 Quick Strip Controls (Zones 8Z/16Z/32P + Grid + AR + North) ───
    const btnQuickZone8 = document.getElementById('btnQuickZone8');
    const btnQuickZone16 = document.getElementById('btnQuickZone16');
    const btnQuickZone32 = document.getElementById('btnQuickZone32');
    const btnQuickGrid = document.getElementById('btnQuickGrid');
    const btnQuickAR = document.getElementById('btnQuickAR');
    const btnQuickNorth = document.getElementById('btnQuickNorth');
    const quickNorthLabel = document.getElementById('quickNorthLabel');

    function syncZoneUI(z) {
      zoneSystem = z;
      [btnQuickZone8, btnQuickZone16, btnQuickZone32].forEach(btn => {
        if (btn) btn.classList.toggle('active', btn.dataset.zones === z);
      });
      [btnZone8, btnZone16, btnZone32].forEach(btn => {
        if (btn) btn.classList.toggle('active', btn.dataset.zones === z);
      });
      const radios = document.getElementsByName('zones');
      radios.forEach(r => { if (r.value === z) r.checked = true; });
      if (z === '32') {
        if (padaEntranceCard) padaEntranceCard.classList.remove('hidden');
      } else {
        if (padaEntranceCard) padaEntranceCard.classList.add('hidden');
      }
      buildDialSvg();
      updateVastuInspector(currentHeading);
      showToast(`Switched to ${z === '32' ? '32 Padas' : z + ' Zones'}`);
    }

    if (btnQuickZone8) btnQuickZone8.addEventListener('click', () => syncZoneUI('8'));
    if (btnQuickZone16) btnQuickZone16.addEventListener('click', () => syncZoneUI('16'));
    if (btnQuickZone32) btnQuickZone32.addEventListener('click', () => syncZoneUI('32'));

    // Quick 81-Pada Grid Toggle
    if (btnQuickGrid) {
      const toggleGridListener = document.getElementById('toggle-vastu-grid');
      btnQuickGrid.addEventListener('click', () => {
        const isNowOn = !btnQuickGrid.classList.contains('active');
        btnQuickGrid.classList.toggle('active', isNowOn);
        if (toggleGridListener) toggleGridListener.checked = isNowOn;
        try { localStorage.setItem('kuberan_vastu_grid', isNowOn); } catch(e) {}
        requestAnimationFrame(() => {
          buildDialSvg();
          updateVastuInspector(currentHeading);
        });
        showToast(isNowOn ? '81-Pada & 45-Devata Mandala Grid Active' : 'Grid Overlay Hidden');
      });
    }

    // Quick AR Camera Toggle
    if (btnQuickAR) {
      btnQuickAR.addEventListener('click', async () => {
        await toggleCameraAR();
      });
    }

    // Quick True/Magnetic North Toggle
    if (btnQuickNorth) {
      btnQuickNorth.addEventListener('click', () => {
        isTrueNorth = !isTrueNorth;
        if (quickNorthLabel) quickNorthLabel.textContent = isTrueNorth ? 'TRUE' : 'MAG';
        btnQuickNorth.classList.toggle('active', isTrueNorth);
        if (btnToggleNorth) btnToggleNorth.classList.toggle('active', isTrueNorth);
        if (northPill) northPill.textContent = isTrueNorth ? 'TRU' : 'MAG';
        const radiosRef = document.getElementsByName('compass-ref');
        radiosRef.forEach(r => { if (r.value === (isTrueNorth ? 'true' : 'magnetic')) r.checked = true; });
        if (sensorStatus) sensorStatus.textContent = isTrueNorth ? 'True North calibrated' : 'Magnetic active';
        showToast(isTrueNorth ? 'True North mode active' : 'Magnetic North mode active');
        updateHeading(rawMagneticHeading, true);
      });
    }

    // Header Dial Theme & Language Buttons
    const btnHeaderDialTheme = document.getElementById('btnHeaderDialTheme');
    if (btnHeaderDialTheme) {
      btnHeaderDialTheme.addEventListener('click', () => {
        currentDialThemeIndex = (currentDialThemeIndex + 1) % DIAL_THEMES.length;
        dialTheme = DIAL_THEMES[currentDialThemeIndex];
        document.body.classList.remove('theme-elemental', 'theme-chakra', 'theme-gold');
        document.body.classList.add(`theme-${dialTheme}`);
        const selDialEl = document.getElementById('setting-dial-style');
        if (selDialEl) selDialEl.value = dialTheme;
        buildDialSvg();
        const themeNames = { elemental: 'Pancha Bhoota Elemental', chakra: 'Vastu Chakra Wheel', gold: 'Royal Gold' };
        showToast(`Dial Style: ${themeNames[dialTheme]}`);
      });
    }

    const btnHeaderLang = document.getElementById('btnHeaderLang');
    if (btnHeaderLang) {
      btnHeaderLang.addEventListener('click', () => {
        renderLangModal();
        langModal.classList.remove('hidden');
      });
    }

    // Direct Tap on Heading / Bearing Container to Lock Target Bearing
    const bearingContainerTap = document.getElementById('bearingContainerTap');
    const targetLockPill = document.getElementById('targetLockPill');

    function toggleTargetLock() {
      if (targetHeading === null) {
        targetHeading = Math.round(currentHeading);
        targetValue.textContent = `${targetHeading}°`;
        if (btnBearingLock) btnBearingLock.classList.add('active');
        if (targetMarkerRing) {
          targetMarkerRing.style.transform = `rotate(${targetHeading}deg)`;
          targetMarkerRing.classList.remove('hidden');
        }
        triggerHapticTick(40);
        showToast(`🎯 Target Bearing Locked: ${targetHeading}°`);
      } else {
        targetHeading = null;
        targetValue.textContent = '--';
        if (btnBearingLock) btnBearingLock.classList.remove('active');
        if (targetMarkerRing) targetMarkerRing.classList.add('hidden');
        if (targetDeviationBar) targetDeviationBar.classList.add('hidden');
        triggerHapticTick(20);
        showToast('Target bearing cleared');
      }
      updateHeadingUI(currentHeading);
    }

    if (bearingContainerTap) bearingContainerTap.addEventListener('click', toggleTargetLock);
    if (targetLockPill) targetLockPill.addEventListener('click', (e) => { e.stopPropagation(); toggleTargetLock(); });

    // Magnetic Interference Alert Pill Tap -> Opens Calibration Studio
    const magPillAlert = document.getElementById('magneticInterferencePill');
    if (magPillAlert) {
      magPillAlert.addEventListener('click', () => {
        if (calibrationModal) {
          calibrationModal.classList.remove('hidden');
          updateCalibrationUI();
        }
      });
    }

    // ─── Floating Dock Navigation Bindings ───
    const btnDockRoomFinder = document.getElementById('btnDockRoomFinder');
    const btnDockPlotTilt = document.getElementById('btnDockPlotTilt');
    const btnDockAyadi = document.getElementById('btnDockAyadi');
    const btnDockAudit = document.getElementById('btnDockAudit');
    const btnDockCalibrate = document.getElementById('btnDockCalibrate');

    if (btnDockRoomFinder) btnDockRoomFinder.addEventListener('click', () => {
      renderRoomsGrid();
      if (roomFinderModal) roomFinderModal.classList.remove('hidden');
    });

    if (btnDockPlotTilt) btnDockPlotTilt.addEventListener('click', () => {
      updatePlotTiltUI(currentHeading);
      if (plotTiltModal) plotTiltModal.classList.remove('hidden');
    });

    if (btnDockAyadi) btnDockAyadi.addEventListener('click', () => {
      if (ayadiModal) {
        ayadiModal.classList.remove('hidden');
        runAyadiCalculation();
      }
    });

    if (btnDockAudit) btnDockAudit.addEventListener('click', openAuditModal);

    if (btnDockCalibrate) btnDockCalibrate.addEventListener('click', () => {
      if (calibrationModal) {
        calibrationModal.classList.remove('hidden');
        updateCalibrationUI();
      }
    });

    // Sector Preview Reset Button
    
    // ─── v5.5.0 Powerhouse Event Listeners ───
    // 1. Freeze Compass Reading Button + AR Freeze Button + 5-Second Precision Survey Lock
    const btnFreezeHeading = document.getElementById('btnFreezeHeading');
    const freezePillText = document.getElementById('freezePillText');
    const btnArFreezeFs = document.getElementById('btnArFreezeFs');
    const arFreezeFsText = document.getElementById('arFreezeFsText');
    const btnPrecisionSample = document.getElementById('btnPrecisionSample');
    const precisionPillText = document.getElementById('precisionPillText');

    function syncFreezeButtons() {
      if (btnFreezeHeading) { btnFreezeHeading.classList.toggle('active', isHeadingFrozen); btnFreezeHeading.setAttribute('aria-pressed', String(isHeadingFrozen)); }
      if (freezePillText) {
        freezePillText.textContent = isHeadingFrozen
          ? (precisionConfidenceDeg !== null ? `LOCKED ±${precisionConfidenceDeg}°` : 'FROZEN')
          : 'FREEZE';
      }
      if (btnArFreezeFs) { btnArFreezeFs.classList.toggle('active', isHeadingFrozen); btnArFreezeFs.setAttribute('aria-pressed', String(isHeadingFrozen)); }
      if (arFreezeFsText) arFreezeFsText.textContent = isHeadingFrozen ? 'Frozen' : 'Freeze';
      if (!isHeadingFrozen && btnPrecisionSample) {
        btnPrecisionSample.classList.remove('locked', 'sampling');
        if (precisionPillText) precisionPillText.textContent = '5s LOCK';
      }
    }

    function toggleHeadingFreeze() {
      if (isPrecisionSampling) {
        clearInterval(precisionSampleCountdown);
        clearTimeout(precisionSampleTimer);
        isPrecisionSampling = false;
      }
      isHeadingFrozen = !isHeadingFrozen;
      precisionConfidenceDeg = null;
      if (isHeadingFrozen) {
        frozenHeadingVal = currentHeading;
        frozenCssVal = lastCssHeading;
        syncFreezeButtons();
        triggerHapticTick(50);
        showToast(tiltWarningActive
          ? '❄️ Frozen at ' + Math.round(frozenHeadingVal) + '° — but the phone is tilted over 15°, so accuracy is reduced. Level it and freeze again.'
          : '❄️ Reading Frozen at ' + Math.round(frozenHeadingVal) + '°. Step freely to inspect without drift!');
      } else {
        frozenHeadingVal = null; frozenCssVal = null;
        syncFreezeButtons();
        triggerHapticTick(25);
        showToast('Live tracking resumed');
        updateHeading(rawMagneticHeading, true);
      }
    }

    if (btnFreezeHeading) {
      btnFreezeHeading.addEventListener('click', (e) => {
        e.stopPropagation();
        toggleHeadingFreeze();
      });
    }
    if (btnArFreezeFs) {
      btnArFreezeFs.addEventListener('click', (e) => {
        e.stopPropagation();
        toggleHeadingFreeze();
      });
    }

    // 5-Second Circular Mean Survey Lock (Safe Precision Pack #1)
    if (btnPrecisionSample) {
      btnPrecisionSample.addEventListener('click', (e) => {
        e.stopPropagation();
        if (isPrecisionSampling) {
          clearInterval(precisionSampleCountdown);
          clearTimeout(precisionSampleTimer);
          isPrecisionSampling = false;
          btnPrecisionSample.classList.remove('sampling');
          if (precisionPillText) precisionPillText.textContent = '5s LOCK';
          showToast('Precision survey cancelled');
          return;
        }
        if (isHeadingFrozen) {
          // Unfreeze first if already locked
          isHeadingFrozen = false;
          frozenHeadingVal = null; frozenCssVal = null;
          precisionConfidenceDeg = null;
          syncFreezeButtons();
        }
        isPrecisionSampling = true;
        precisionSamples = [{ angle: currentHeading, weight: 1.0 }];
        btnPrecisionSample.classList.remove('locked');
        btnPrecisionSample.classList.add('sampling');
        let remainingSec = 5;
        if (precisionPillText) precisionPillText.textContent = `HOLD ${remainingSec}s`;
        showToast('🎯 Hold phone steady & level for 5s Circular Mean Survey...');

        precisionSampleCountdown = setInterval(() => {
          remainingSec -= 1;
          if (remainingSec > 0 && precisionPillText) {
            precisionPillText.textContent = `HOLD ${remainingSec}s`;
          }
        }, 1000);

        precisionSampleTimer = setTimeout(() => {
          clearInterval(precisionSampleCountdown);
          isPrecisionSampling = false;
          btnPrecisionSample.classList.remove('sampling');

          if (precisionSamples.length === 0) {
            precisionSamples.push({ angle: currentHeading, weight: 1.0 });
          }

          // 1. Weighted Trigonometric Circular Mean: atan2(sum(w*sin), sum(w*cos))
          const D = Math.PI / 180;
          let sumSin = 0, sumCos = 0, totalW = 0;
          precisionSamples.forEach(s => {
            sumSin += s.weight * Math.sin(s.angle * D);
            sumCos += s.weight * Math.cos(s.angle * D);
            totalW += s.weight;
          });
          let meanDeg = Math.atan2(sumSin / totalW, sumCos / totalW) / D;
          if (meanDeg < 0) meanDeg += 360;

          // 2. Outlier Rejection (Filter out spikes > 2x circular deviation if > 8 samples)
          if (precisionSamples.length >= 8) {
            let sqDiffSum = 0;
            const deltas = precisionSamples.map(s => {
              let diff = ((s.angle - meanDeg + 540) % 360) - 180;
              sqDiffSum += diff * diff;
              return { ...s, diff: Math.abs(diff) };
            });
            const stdDev = Math.sqrt(sqDiffSum / precisionSamples.length);
            const cutoff = Math.max(1.5, 2.0 * stdDev);
            const inliers = deltas.filter(s => s.diff <= cutoff);
            if (inliers.length >= 4) {
              let iSin = 0, iCos = 0, iW = 0;
              inliers.forEach(s => {
                iSin += s.weight * Math.sin(s.angle * D);
                iCos += s.weight * Math.cos(s.angle * D);
                iW += s.weight;
              });
              meanDeg = Math.atan2(iSin / iW, iCos / iW) / D;
              if (meanDeg < 0) meanDeg += 360;
            }
          }

          // 3. Compute Circular Standard Error / Confidence Radius
          let R = Math.hypot(sumSin / totalW, sumCos / totalW);
          R = Math.min(0.99999, Math.max(0.0001, R));
          const circStdRad = Math.sqrt(-2 * Math.log(R));
          const confDeg = Math.max(0.2, Math.min(5.0, (circStdRad / D))).toFixed(1);

          precisionConfidenceDeg = confDeg;
          isHeadingFrozen = true;
          frozenHeadingVal = meanDeg;
          frozenCssVal = SC.unwrapToward(lastCssHeading, meanDeg);
          btnPrecisionSample.classList.add('locked');
          if (precisionPillText) precisionPillText.textContent = `±${confDeg}° LOCK`;
          syncFreezeButtons();
          updateHeadingUI(frozenCssVal);
          triggerHapticTick(60);
          showToast(`🎯 Survey Locked: ${meanDeg.toFixed(1)}° (±${confDeg}° over ${precisionSamples.length} samples)`);
        }, 5000);
      });
    }

    // 2. Solar Muhurta Periodic Refresh & Tap Info
    const solarMuhurtaBadge = document.getElementById('solarMuhurtaBadge');
    const solarMuhurtaText = document.getElementById('solarMuhurtaText');
    function refreshSolarMuhurta() {
      const lat = window.lastKnownLat || 12.9716;
      const lng = window.lastKnownLng || 77.5946;
      const sun = calculateSunPosition(lat, lng);
      const muhurta = getVedicMuhurta();
      const solarIcon = document.querySelector('#solarMuhurtaBadge .solar-icon');
      if (solarIcon) solarIcon.textContent = sun.isDay ? '☀️' : '🌙';
      if (solarMuhurtaText) {
        solarMuhurtaText.textContent = 'Sun: ' + sun.azimuth + '° • ' + (muhurta.isRahuKalam ? 'Rahu' : 'Shubh');
      }
      if (solarMuhurtaBadge) {
        solarMuhurtaBadge.className = 'solar-muhurta-badge ' + (muhurta.isRahuKalam ? 'rahu-kalam' : 'auspicious');
      }
    }
    refreshSolarMuhurta();
    setInterval(refreshSolarMuhurta, 60000);

    if (solarMuhurtaBadge) {
      solarMuhurtaBadge.addEventListener('click', (e) => {
        e.stopPropagation();
        const muhurta = getVedicMuhurta();
        const lat = window.lastKnownLat || 12.9716;
        const lng = window.lastKnownLng || 77.5946;
        const sun = calculateSunPosition(lat, lng);
        showToast(muhurta.statusLabel + ' | Sun Azimuth: ' + sun.azimuth + '° (' + (sun.isDay ? 'Daytime' : 'Night') + ')');
      });
    }

    // 3. AR Torch Button
    const btnArTorch = document.getElementById('btnArTorch');
    if (btnArTorch) {
      btnArTorch.addEventListener('click', () => toggleArTorch());
    }

    // 4. AR Snapshot Shutter Button
    const btnArSnapshot = document.getElementById('btnArSnapshot');
    if (btnArSnapshot) {
      btnArSnapshot.addEventListener('click', () => captureArVastuSnapshot());
    }

    // 5. AR Viewport Expand Toggle
    const btnArExpand = document.getElementById('btnArExpand');
    const arExpandIcon = document.getElementById('arExpandIcon');
    const arExpandText = document.getElementById('arExpandText');
    if (btnArExpand) {
      btnArExpand.addEventListener('click', () => {
        isArExpanded = !isArExpanded;
        compassViewport.classList.toggle('ar-expanded', isArExpanded);
        if (btnArExpand) btnArExpand.classList.toggle('active', isArExpanded);
        if (arExpandIcon) arExpandIcon.textContent = isArExpanded ? '↙' : '⛶';
        if (arExpandText) arExpandText.textContent = isArExpanded ? 'Compact' : 'Expand';
        showToast(isArExpanded ? 'Expanded AR Viewport' : 'Standard Dial Viewport');
      });
    }

    // 6. Log Room to Site Audit Buttons
    const btnLogRoomToAudit = document.getElementById('btnLogRoomToAudit');
    if (btnLogRoomToAudit) {
      btnLogRoomToAudit.addEventListener('click', () => logCurrentRoomToWalkthrough());
    }

    const btnQuickLogCurrent = document.getElementById('btnQuickLogCurrent');
    if (btnQuickLogCurrent) {
      btnQuickLogCurrent.addEventListener('click', () => logCurrentRoomToWalkthrough());
    }

    const btnClearSiteWalkthrough = document.getElementById('btnClearSiteWalkthrough');
    if (btnClearSiteWalkthrough) {
      btnClearSiteWalkthrough.addEventListener('click', () => {
        siteWalkthroughLogs = [];
        try { localStorage.removeItem('kuberan_site_walkthrough_logs'); } catch(e) {}
        renderSiteWalkthroughUI();
        showToast('Site Walkthrough cleared');
      });
    }

    // 7. AR Snapshot Modal Actions
    
    // ─── v5.5.0 Fullscreen AR Viewfinder HUD Listeners ───
    const btnCloseArFs = document.getElementById('btnCloseArFs');
    if (btnCloseArFs) {
      btnCloseArFs.addEventListener('click', () => {
        toggleCameraAR();
      });
    }

    const btnArTorchFs = document.getElementById('btnArTorchFs');
    if (btnArTorchFs) {
      btnArTorchFs.addEventListener('click', () => {
        toggleArTorch();
      });
    }

    const btnArFsSnapshot = document.getElementById('btnArFsSnapshot');
    if (btnArFsSnapshot) {
      btnArFsSnapshot.addEventListener('click', () => {
        captureArVastuSnapshot();
      });
    }

    const btnArLogRoomFs = document.getElementById('btnArLogRoomFs');
    if (btnArLogRoomFs) {
      btnArLogRoomFs.addEventListener('click', () => {
        logCurrentRoomToWalkthrough();
      });
    }

    const btnArTapeToggle = document.getElementById('btnArTapeToggle');
    const tapeWrap = document.querySelector('.ar-compass-tape-wrap');
    if (btnArTapeToggle && tapeWrap) {
      btnArTapeToggle.addEventListener('click', () => {
        tapeWrap.classList.toggle('hidden');
        const isHidden = tapeWrap.classList.contains('hidden');
        btnArTapeToggle.classList.toggle('active', !isHidden);
        showToast(isHidden ? 'Compass Ribbon Hidden' : 'Compass Ribbon Visible');
      });
    }

    const btnCloseSnapModal = document.getElementById('btnCloseSnapModal');
    const arSnapshotModal = document.getElementById('arSnapshotModal');
    if (btnCloseSnapModal && arSnapshotModal) {
      btnCloseSnapModal.addEventListener('click', () => arSnapshotModal.classList.add('hidden'));
    }

    const btnDownloadSnapshot = document.getElementById('btnDownloadSnapshot');
    if (btnDownloadSnapshot) {
      btnDownloadSnapshot.addEventListener('click', () => {
        if (!window.lastArSnapshotBlobUrl) return;
        const a = document.createElement('a');
        a.href = window.lastArSnapshotBlobUrl;
        a.download = 'Kuberan-Vastu-AR-Snapshot-' + Date.now() + '.jpg';
        a.click();
        showToast('Saved snapshot to device gallery!');
      });
    }

    const btnShareSnapshot = document.getElementById('btnShareSnapshot');
    if (btnShareSnapshot) {
      btnShareSnapshot.addEventListener('click', async () => {
        if (!window.lastArSnapshotBlobUrl) return;
        try {
          // Convert DataURL to Blob for Web Share API
          const res = await fetch(window.lastArSnapshotBlobUrl);
          const blob = await res.blob();
          const file = new File([blob], 'kuberan-vastu-inspection.jpg', { type: 'image/jpeg' });
          if (navigator.canShare && navigator.canShare({ files: [file] })) {
            await navigator.share({
              title: 'KUBERAN Silks Vastu AR Inspection',
              text: 'Vastu Shastra Site Inspection Snapshot by KUBERAN Silks - https://kuberansilks.com/',
              files: [file]
            });
            showToast('Snapshot shared successfully!');
          } else {
            // Fallback: download
            btnDownloadSnapshot.click();
          }
        } catch(err) {
          showToast('Sharing not supported on this device');
        }
      });
    }

    const btnReturnToLiveHeading = document.getElementById('btnReturnToLiveHeading');
    if (btnReturnToLiveHeading) {
      btnReturnToLiveHeading.addEventListener('click', () => {
        previewZoneSector = null;
        const sectorPreviewBar = document.getElementById('sectorPreviewBar');
        if (sectorPreviewBar) sectorPreviewBar.classList.add('hidden');
        updateVastuInspector(currentHeading);
        showToast('Resumed Live Compass Tracking');
      });
    }

    // Interactive Tap on Dial SVG to Inspect Sector
    if (dialSvg) {
      dialSvg.addEventListener('click', (e) => {
        const sectorEl = e.target.closest('.vastu-sector-clickable');
        if (sectorEl) {
          const zCode = sectorEl.dataset.zoneCode;
          const pId = sectorEl.dataset.padaId;
          const targetZone8 = zCode && VASTU_DATA.ZONES_8.find(z => z.code === zCode);
          const targetZone16 = zCode && VASTU_DATA.ZONES_16.find(z => z.id === zCode);
          const targetPada32 = pId && VASTU_DATA.PADAS_32.find(p => p.id === pId);
          const targetZone = targetZone8 || targetZone16 || targetPada32;

          if (targetZone) {
            previewZoneSector = targetZone;
            const centerDeg = targetZone.centerDeg !== undefined
              ? targetZone.centerDeg
              : ((targetZone.startDeg + targetZone.endDeg) / 2);
            const labelText = targetZone.names
              ? (targetZone.names[currentLang] || targetZone.names.en)
              : (targetZone.label ? `${targetZone.id} (${targetZone.label})` : `${targetZone.id} • ${targetZone.devata}`);

            const sectorPreviewBar = document.getElementById('sectorPreviewBar');
            const previewZoneTitle = document.getElementById('previewZoneTitle');
            if (sectorPreviewBar && previewZoneTitle) {
              previewZoneTitle.textContent = labelText;
              sectorPreviewBar.classList.remove('hidden');
            }
            updateVastuInspector(centerDeg);
            triggerHapticTick(25);
            showToast(`Previewing ${labelText}`);
          }
        }
      });
    }

    // Clickable Room Chips in Inspector: Selecting room activates Room Finder
    if (favorableTags) {
      favorableTags.addEventListener('click', (e) => {
        const tag = e.target.closest('.room-tag');
        if (tag) {
          const text = tag.textContent.trim().replace(/^[^a-zA-Z0-9\u0900-\u0DFF]+/, '').trim();
          const allRooms = [...(VASTU_DATA.ROOMS || []), ...(VASTU_DATA.COMMERCIAL_ROOMS || [])];
          const found = allRooms.find(r => (r.names && r.names.en && text.toLowerCase().includes(r.names.en.toLowerCase())) ||
                                           (r.names && r.names[currentLang] && text.toLowerCase().includes(r.names[currentLang].toLowerCase())));
          if (found) {
            selectRoom(found.id);
          }
        }
      });
    }

    // Collapsible Inspector Details Drawer Toggle
    const btnToggleInspectorDetails = document.getElementById('btnToggleInspectorDetails');
    const inspectorExpandContent = document.getElementById('inspectorExpandContent');
    const inspectorDrawerInner = document.getElementById('inspectorDrawerInner');

    if (btnToggleInspectorDetails && inspectorExpandContent) {
      btnToggleInspectorDetails.addEventListener('click', () => {
        const isExpanded = !inspectorExpandContent.classList.contains('hidden');
        if (isExpanded) {
          inspectorExpandContent.classList.add('hidden');
          btnToggleInspectorDetails.classList.remove('open');
        } else {
          // Populate Drawer with remedies, 45-Devata Antar-Devata & Bhumi-Plava rules
          const activeZ = getActiveZone8(currentHeading);
          const activeAntar = getActiveAntarDevata(currentHeading);
          const activePada = getActivePada32(currentHeading);
          const elem = VASTU_DATA.ELEMENTS[activeZ.element];
          let drawerHtml = `
            <div style="font-size:0.75rem; color:var(--text-muted); line-height:1.4;">
              <strong style="color:${elem.color}; font-size:0.8rem; display:block; margin-bottom:4px;">🕉️ Elemental Resonance (${elem.names[currentLang] || elem.names.en})</strong>
              Keep this sector balanced with ${elem.names.en} attributes. Avoid clutter and incompatible elemental conflicts.
            </div>
          `;
          if (activeAntar && activePada) {
            drawerHtml += `
              <div style="margin-top:8px; padding-top:8px; border-top:1px solid rgba(212,163,89,0.2); font-size:0.74rem; color:#e2e8f0; line-height:1.4;">
                <strong style="color:var(--kuberan-gold); display:block; margin-bottom:2px;">📜 Vishwakarma 45-Devata Mandala & Slope Rule</strong>
                • <strong>Outer Door Pada (32):</strong> ${activePada.id} ${activePada.devata} (Grade ${activePada.grade})<br>
                • <strong>Inner Deity (12-Antar):</strong> ${activeAntar.name} — ${activeAntar.effect[currentLang] || activeAntar.effect.en}<br>
                • <strong>Bhūmi-Plava (Slope):</strong> Floor/water must slope down toward North/East (Īśānya) and remain elevated in South-West (Nairṛtya).
              </div>
            `;
          }
          if (inspectorDrawerInner) inspectorDrawerInner.innerHTML = drawerHtml;
          inspectorExpandContent.classList.remove('hidden');
          btnToggleInspectorDetails.classList.add('open');
        }
      });
    }

    // Ayadi Stepper Controls (+ / - 0.5 ft)
    const btnStepLengthMinus = document.getElementById('btnStepLengthMinus');
    const btnStepLengthPlus = document.getElementById('btnStepLengthPlus');
    const btnStepWidthMinus = document.getElementById('btnStepWidthMinus');
    const btnStepWidthPlus = document.getElementById('btnStepWidthPlus');
    const ayadiLengthInput = document.getElementById('ayadiLength');
    const ayadiWidthInput = document.getElementById('ayadiWidth');

    if (btnStepLengthMinus && ayadiLengthInput) {
      btnStepLengthMinus.addEventListener('click', () => {
        let val = parseFloat(ayadiLengthInput.value) || 0;
        if (val > 1) { ayadiLengthInput.value = (val - 0.5).toFixed(1); runAyadiCalculation(); }
      });
    }
    if (btnStepLengthPlus && ayadiLengthInput) {
      btnStepLengthPlus.addEventListener('click', () => {
        let val = parseFloat(ayadiLengthInput.value) || 0;
        ayadiLengthInput.value = (val + 0.5).toFixed(1); runAyadiCalculation();
      });
    }
    if (btnStepWidthMinus && ayadiWidthInput) {
      btnStepWidthMinus.addEventListener('click', () => {
        let val = parseFloat(ayadiWidthInput.value) || 0;
        if (val > 1) { ayadiWidthInput.value = (val - 0.5).toFixed(1); runAyadiCalculation(); }
      });
    }
    if (btnStepWidthPlus && ayadiWidthInput) {
      btnStepWidthPlus.addEventListener('click', () => {
        let val = parseFloat(ayadiWidthInput.value) || 0;
        ayadiWidthInput.value = (val + 0.5).toFixed(1);
        runAyadiCalculation();
      });
    }

    // Vishwakarma Prakash Field Diagnostics Listeners (Bhumi-Plava, Dvara-Vedha, Vithi-Shula)
    ['selectBhumiPlava', 'selectDvaraVedha', 'selectVithiShula'].forEach(selId => {
      const selEl = document.getElementById(selId);
      if (selEl) {
        selEl.addEventListener('change', () => {
          updateShastraDiagnosticsUI();
        });
      }
    });

    // Print Certificate Button in Audit Modal
    const btnPrintCertificate = document.getElementById('btnPrintCertificate');
    if (btnPrintCertificate) {
      btnPrintCertificate.addEventListener('click', () => {
        window.print();
      });
    }

    // Mode Switcher removed (app locked to Vastu mode)

    // Zone Switcher (8 / 16 / 32)
    if (btnZone8) btnZone8.addEventListener('click', () => {
      zoneSystem = '8';
      if (btnZone8) btnZone8.classList.add('active');
      if (btnZone16) btnZone16.classList.remove('active');
      if (btnZone32) btnZone32.classList.remove('active');
      buildDialSvg();
      updateVastuInspector(currentHeading);
    });

    if (btnZone16) btnZone16.addEventListener('click', () => {
      zoneSystem = '16';
      if (btnZone16) btnZone16.classList.add('active');
      if (btnZone8) btnZone8.classList.remove('active');
      if (btnZone32) btnZone32.classList.remove('active');
      buildDialSvg();
      updateVastuInspector(currentHeading);
    });

    if (btnZone32) btnZone32.addEventListener('click', () => {
      zoneSystem = '32';
      if (btnZone32) btnZone32.classList.add('active');
      if (btnZone8) btnZone8.classList.remove('active');
      if (btnZone16) btnZone16.classList.remove('active');
      buildDialSvg();
      updateVastuInspector(currentHeading);
    });

    // Property Type Switcher (Residential vs Commercial & Retail)
    if (btnPropResidential && btnPropCommercial) {
      if (btnPropResidential) btnPropResidential.addEventListener('click', () => {
        propertyType = 'residential';
        btnPropResidential.classList.add('active');
        btnPropCommercial.classList.remove('active');
        if (retailProfileStrip) retailProfileStrip.classList.add('hidden');
        roomCategoryTab = 'residential';
        if (tabResRooms) tabResRooms.classList.add('active');
        if (tabCommRooms) tabCommRooms.classList.remove('active');
        buildDialSvg();
        updateVastuInspector(currentHeading);
        showToast('Switched to Residential Vastu');
      });

      if (btnPropCommercial) btnPropCommercial.addEventListener('click', () => {
        propertyType = 'commercial';
        btnPropCommercial.classList.add('active');
        btnPropResidential.classList.remove('active');
        if (retailProfileStrip) retailProfileStrip.classList.remove('hidden');
        roomCategoryTab = 'commercial';
        if (tabCommRooms) tabCommRooms.classList.add('active');
        if (tabResRooms) tabResRooms.classList.remove('active');
        buildDialSvg();
        updateVastuInspector(currentHeading);
        showToast('Switched to Commercial & Retail Vastu');
      });
    }

    // Retail Profile Chips (Apparel, Jewelry, General)
    function setRetailProfile(profId) {
      retailProfile = profId;
      [chipProfileApparel, chipProfileJewelry, chipProfileGeneral].forEach(chip => {
        if (chip) chip.classList.toggle('active', chip.dataset.profile === profId);
      });
      buildDialSvg();
      updateVastuInspector(currentHeading);
      const prof = VASTU_DATA.RETAIL_PROFILES && VASTU_DATA.RETAIL_PROFILES.find(p => p.profile_id === profId);
      const name = prof ? (prof.name[currentLang] || prof.name.en) : profId;
      showToast(`Retail Profile: ${name}`);
    }

    if (chipProfileApparel) chipProfileApparel.addEventListener('click', () => setRetailProfile('apparel_silk_sarees'));
    if (chipProfileJewelry) chipProfileJewelry.addEventListener('click', () => setRetailProfile('jewelry_luxury'));
    if (chipProfileGeneral) chipProfileGeneral.addEventListener('click', () => setRetailProfile('general_commercial'));

    // Room Category Tabs in Room Finder Modal
    if (tabResRooms) {
      if (tabResRooms) tabResRooms.addEventListener('click', () => {
        roomCategoryTab = 'residential';
        tabResRooms.classList.add('active');
        if (tabCommRooms) tabCommRooms.classList.remove('active');
        renderRoomsGrid();
      });
    }
    if (tabCommRooms) {
      if (tabCommRooms) tabCommRooms.addEventListener('click', () => {
        roomCategoryTab = 'commercial';
        tabCommRooms.classList.add('active');
        if (tabResRooms) tabResRooms.classList.remove('active');
        renderRoomsGrid();
      });
    }

    // Commercial Plot Shape Selector Cards in Plot Tilt Modal
    if (plotShapeSelectorGrid) {
      plotShapeSelectorGrid.querySelectorAll('.shape-chip').forEach(card => {
        card.addEventListener('click', () => {
          plotShapeSelectorGrid.querySelectorAll('.shape-chip').forEach(c => c.classList.remove('active'));
          card.classList.add('active');
          selectedPlotShape = card.dataset.shape;
          const shapeObj = VASTU_DATA.PLOT_SHAPES && VASTU_DATA.PLOT_SHAPES[selectedPlotShape];
          if (shapeObj && plotShapeBadge && plotShapeAdviceText) {
            plotShapeBadge.className = `shape-badge ${shapeObj.badgeClass}`;
            plotShapeBadge.textContent = shapeObj.statusLabel;
            plotShapeAdviceText.textContent = shapeObj.commercialEffect;
            showToast(`Plot Shape: ${shapeObj.name}`);
          }
        });
      });
    }

    // Dial Visual Theme Switcher (Elemental / Chakra / Royal Gold)
    if (btnDialTheme) btnDialTheme.addEventListener('click', () => {
      currentDialThemeIndex = (currentDialThemeIndex + 1) % DIAL_THEMES.length;
      dialTheme = DIAL_THEMES[currentDialThemeIndex];

      document.body.classList.remove('theme-elemental', 'theme-chakra', 'theme-gold');
      document.body.classList.add(`theme-${dialTheme}`);

      buildDialSvg();
      const themeNames = { elemental: 'Pancha Bhoota Elemental', chakra: 'Vastu Chakra Wheel', gold: 'Royal Gold' };
      showToast(`Dial Style: ${themeNames[dialTheme]}`);
    });

    // Language Switcher Trigger
    if (btnLanguage) btnLanguage.addEventListener('click', () => {
      renderLangModal();
      langModal.classList.remove('hidden');
    });
    if (btnCloseLangModal) btnCloseLangModal.addEventListener('click', () => langModal.classList.add('hidden'));

    // North Mode Toggle (True North default)
    if (btnToggleNorth) btnToggleNorth.addEventListener('click', () => {
      isTrueNorth = !isTrueNorth;
      if (isTrueNorth) {
        btnToggleNorth.classList.add('active');
        if (northPill) northPill.textContent = 'TRU';
        // northModeLabel removed
        showToast('True North mode active (Magnetic declination applied)');
      } else {
        btnToggleNorth.classList.remove('active');
        if (northPill) northPill.textContent = 'MAG';
        // northModeLabel removed
        showToast('Magnetic North mode active');
      }
      sensorStatus.textContent = isTrueNorth ? 'True North calibrated' : 'Magnetic active';
      updateHeading(rawMagneticHeading);
    });

    // Target Bearing Lock
    if (btnBearingLock) btnBearingLock.addEventListener('click', () => {
      if (targetHeading === null) {
        targetHeading = Math.round(currentHeading);
        targetValue.textContent = `${targetHeading}°`;
        btnBearingLock.classList.add('active');
        targetMarkerRing.style.transform = `rotate(${targetHeading}deg)`;
        targetMarkerRing.classList.remove('hidden');
        showToast(`Target bearing locked: ${targetHeading}°`);
      } else {
        targetHeading = null;
        targetValue.textContent = '--';
        btnBearingLock.classList.remove('active');
        targetMarkerRing.classList.add('hidden');
        targetDeviationBar.classList.add('hidden');
        showToast('Target bearing cleared');
      }
      updateHeadingUI(currentHeading);
    });

    if (btnClearTarget) btnClearTarget.addEventListener('click', () => {
      targetHeading = null;
      targetValue.textContent = '--';
      if (btnBearingLock) btnBearingLock.classList.remove('active');
      targetMarkerRing.classList.add('hidden');
      targetDeviationBar.classList.add('hidden');
      updateHeadingUI(currentHeading);
      showToast('Target bearing cleared');
    });

    // Vastu Tool: Room Finder
    if (btnToolRoomFinder) btnToolRoomFinder.addEventListener('click', () => {
      renderRoomsGrid();
      roomFinderModal.classList.remove('hidden');
    });
    if (btnCloseRoomModal) btnCloseRoomModal.addEventListener('click', () => roomFinderModal.classList.add('hidden'));
    if (btnCloseRoomGuide) btnCloseRoomGuide.addEventListener('click', clearActiveRoom);

    // Vastu Tool: Plot Tilt Detector
    if (btnToolPlotTilt) btnToolPlotTilt.addEventListener('click', () => {
      updatePlotTiltUI(currentHeading);
      plotTiltModal.classList.remove('hidden');
    });
    if (btnCloseTiltModal) btnCloseTiltModal.addEventListener('click', () => plotTiltModal.classList.add('hidden'));

    if (btnLockPlotTilt) btnLockPlotTilt.addEventListener('click', () => {
      const heading = parseFloat(currentHeading.toFixed(1));
      let dev = ((heading % 90) + 45) % 90 - 45;
      const absDev = Math.abs(dev).toFixed(1);
      plotTiltReading = {
        heading: heading,
        dev: absDev,
        type: absDev <= 3.0 ? 'Sama-Sutra (Aligned)' : 'Vidisha (Tilted)'
      };
      plotTiltModal.classList.add('hidden');
      showToast(`Plot wall locked: ${heading}° (${plotTiltReading.type})`);
    });

    // Vastu Tool: Camera AR
    
    
    // Haptic Feedback Toggle
    const toggleHaptics = document.getElementById('toggle-haptics');
    if (toggleHaptics) {
      let hapticSaved = null;
      try { hapticSaved = localStorage.getItem('kuberan_haptics'); } catch(e) {}
      if (hapticSaved !== null) {
        toggleHaptics.checked = hapticSaved === 'true';
        hapticsEnabled = toggleHaptics.checked;
      }
      toggleHaptics.addEventListener('change', (e) => {
        hapticsEnabled = e.target.checked;
        try { localStorage.setItem('kuberan_haptics', e.target.checked); } catch(err) {}
        showToast(e.target.checked ? 'Haptic feedback enabled' : 'Haptic feedback disabled');
      });
    }

    // Telemetry Grid Tap to Refresh GPS
    const telemetryGrid = document.querySelector('.telemetry-grid');
    if (telemetryGrid) {
      telemetryGrid.addEventListener('click', (e) => {
        if (e.target.closest('#telemetryCalibrationItem')) return; // Ignore calibration tap
        refreshGPS();
      });
    }

    const toggleGridListener = document.getElementById('toggle-vastu-grid');
    if (toggleGridListener) {
      let gridSaved = false;
      try { gridSaved = localStorage.getItem('kuberan_vastu_grid') === 'true'; } catch(e) {}
      toggleGridListener.checked = gridSaved;
      if (btnQuickGrid) btnQuickGrid.classList.toggle('active', gridSaved);
      toggleGridListener.addEventListener('change', (e) => {
        try { localStorage.setItem('kuberan_vastu_grid', e.target.checked); } catch(err) {}
        if (btnQuickGrid) btnQuickGrid.classList.toggle('active', e.target.checked);
        // Defer SVG rebuild to RAF so CSS toggle animation slides smoothly with zero lag
        requestAnimationFrame(() => {
          buildDialSvg();
          updateVastuInspector(currentHeading);
        });
      });
    }

    const toggleCamera = document.getElementById('toggle-camera-ar');
    if (toggleCamera) {
      toggleCamera.addEventListener('change', async (e) => {
         if (e.target.checked && !cameraStream) await toggleCameraAR();
         else if (!e.target.checked && cameraStream) await toggleCameraAR();
      });
    }


    // Vastu Tool: Audit Export Report
    if (btnToolAudit) btnToolAudit.addEventListener('click', openAuditModal);
    if (btnCloseAuditModal) btnCloseAuditModal.addEventListener('click', () => auditModal.classList.add('hidden'));

    if (btnCopyAuditReport) btnCopyAuditReport.addEventListener('click', async () => {
      const text = generateAuditTextReport();
      try {
        await navigator.clipboard.writeText(text);
        showToast('Vastu Report copied to clipboard!');
      } catch (err) {
        showToast('Could not copy report to clipboard');
      }
    });

    if (btnShareAuditReport) btnShareAuditReport.addEventListener('click', async () => {
      const text = generateAuditTextReport();
      if (navigator.share) {
        try {
          await navigator.share({
            title: 'KUBERAN Vastu Compass Audit',
            text: text
          });
        } catch(e) { /* localStorage/vibrate may be blocked in private browsing */ }
      } else {
        await navigator.clipboard.writeText(text);
        showToast('Report copied (Share not supported on this browser)');
      }
    });

    // Info Modal
    if (btnInfo) btnInfo.addEventListener('click', () => {
      infoModal.classList.remove('hidden');
      generateQrCode();
    });
    if (btnCloseModal) btnCloseModal.addEventListener('click', () => infoModal.classList.add('hidden'));

    // Calibration Modal Trigger & Controls
    if (btnCalibrate) {
      if (btnCalibrate) btnCalibrate.addEventListener('click', () => {
        calibrationModal.classList.remove('hidden');
        updateCalibrationUI();
      });
    }
    if (telemetryCalibrationItem) {
      telemetryCalibrationItem.addEventListener('click', () => {
        calibrationModal.classList.remove('hidden');
        updateCalibrationUI();
      });
    }
    if (btnCloseCalModal) {
      btnCloseCalModal.addEventListener('click', () => {
        calibrationModal.classList.add('hidden');
      });
    }
    if (calibrationModal) {
      calibrationModal.addEventListener('click', (e) => {
        if (e.target === calibrationModal) calibrationModal.classList.add('hidden');
      });
    }

    if (btnOffsetMinus5) btnOffsetMinus5.addEventListener('click', () => adjustCalibrationOffset(-5));
    if (btnOffsetMinus1) btnOffsetMinus1.addEventListener('click', () => adjustCalibrationOffset(-1));
    if (btnOffsetReset) btnOffsetReset.addEventListener('click', () => setCalibrationOffset(0));
    if (btnOffsetPlus1) btnOffsetPlus1.addEventListener('click', () => adjustCalibrationOffset(1));
    if (btnOffsetPlus5) btnOffsetPlus5.addEventListener('click', () => adjustCalibrationOffset(5));

    if (btnZeroToNorth) {
      btnZeroToNorth.addEventListener('click', () => {
        if (!window.confirm('Only do this while pointing EXACTLY at true North (use an external reference). It permanently shifts the compass until reset. Continue?')) return;
        // Make the CURRENT pointing read 0° (North). Offset is applied AFTER smoothing and BEFORE
        // declination, so the reference must include the declination that will be added later.
        const base = (smoothedHeading !== null ? normalizeAngle(smoothedHeading) : rawMagneticHeading)
                   + (isTrueNorth ? magneticDeclination : 0);
        const neededOffset = normalizeAngle(-base);
        setCalibrationOffset(neededOffset > 180 ? neededOffset - 360 : neededOffset);
        showToast('Zeroed to Current Heading');
      });
    }

    // 1-Tap Solar Calibration (Śaṅku-Chāyā Method — Astronomical Sun Azimuth)
    const btnCalibrateToSun = document.getElementById('btnCalibrateToSun');
    if (btnCalibrateToSun) {
      btnCalibrateToSun.addEventListener('click', () => {
        const lat = window.lastKnownLat || 12.9716;
        const lng = window.lastKnownLng || 77.5946;
        const sun = calculateSunPosition(lat, lng);
        if (sun.elevation < 2) {
          if (!window.confirm(`Sun is currently low or below the horizon (Elevation: ${sun.elevation}°). Point your phone horizontally toward the calculated Sun Azimuth (${sun.azimuth}°) to proceed anyway?`)) return;
        } else {
          if (!window.confirm(`Point the top of your phone horizontally toward the Sun (or align it parallel to a vertical object's shadow toward the Sun). Calibrate compass to Astronomical Sun Azimuth (${sun.azimuth}°)?`)) return;
        }
        const base = (smoothedHeading !== null ? normalizeAngle(smoothedHeading) : rawMagneticHeading)
                   + (isTrueNorth ? magneticDeclination : 0);
        let neededOffset = normalizeAngle(sun.azimuth - base);
        if (neededOffset > 180) neededOffset -= 360;
        setCalibrationOffset(neededOffset);
        showToast(`☀️ Śaṅku-Chāyā Calibrated to Sun Azimuth (${sun.azimuth}°)`);
      });
    }

    // Universal Backdrop Click-to-Close & Escape Key Handler for all Modals
    document.querySelectorAll('.modal-backdrop').forEach((modal) => {
      modal.addEventListener('click', (e) => {
        if (e.target === modal) modal.classList.add('hidden');
      });
    });
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        document.querySelectorAll('.modal-backdrop:not(.hidden)').forEach((modal) => {
          modal.classList.add('hidden');
        });
      }
    });

    // Copy Coordinates Button
    if (btnCopyCoords) btnCopyCoords.addEventListener('click', async () => {
      const lat = gpsLat.textContent;
      const lng = gpsLng.textContent;
      const str = `${lat}, ${lng} (Heading: ${Math.round(currentHeading)}° ${headingCardinal.textContent})`;
      try {
        await navigator.clipboard.writeText(str);
        showToast('Coordinates copied to clipboard');
      } catch (e) {
        showToast('Copy failed');
      }
    });

    // iOS Sensor Permission Button
    if (btnGrantSensor) btnGrantSensor.addEventListener('click', requestSensorPermission);
    if (btnDismissSensor) {
      btnDismissSensor.addEventListener('click', () => {
        try { localStorage.setItem('kuberan_compass_sensor_enabled', 'true'); } catch(e) { /* localStorage/vibrate may be blocked in private browsing */ }
        iosPermissionBanner.classList.add('hidden');
      });
    }
  }

  // --- Dynamic QR Code Generator for Install / GitHub ---
  function generateQrCode() {
    const qrcodeBox = document.getElementById('qrcodeBox');
    if (qrcodeBox && typeof QRCode !== 'undefined') {
      qrcodeBox.innerHTML = '';
      const shareUrl = window.location.href;
      new QRCode(qrcodeBox, {
        text: shareUrl,
        width: 140,
        height: 140,
        colorDark: "#d4a359",
        colorLight: "#08111e",
        correctLevel: QRCode.CorrectLevel.M
      });
    }
  }

  // --- iOS Sensor Permissions with Robust Error Handling ---
  function requestSensorPermission() {
    if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
      DeviceOrientationEvent.requestPermission()
        .then((response) => {
          if (response === 'granted') {
            try { localStorage.setItem('kuberan_compass_sensor_enabled', 'true'); } catch(e) { /* private browsing */ }
            attachSensorListeners();
            if (iosPermissionBanner) iosPermissionBanner.classList.add('hidden');
            showToast('Compass sensors activated');
          } else {
            showToast('Motion permission denied. Enable in iOS Settings > Safari');
          }
        })
        .catch((err) => {
          console.warn('iOS motion sensor permission error:', err);
          showToast('Motion permission required. Tap Enable Compass Sensors.');
        });
    } else {
      attachSensorListeners();
      if (iosPermissionBanner) iosPermissionBanner.classList.add('hidden');
    }
  }


  // --- Magnetic Interference Detection ---
  let magnetometer = null;
  let interferenceWarningActive = false;

  function initMagnetometer() {
    if ('Magnetometer' in window) {
      try {
        // Frequency 2 Hz is sufficient and saves battery
        magnetometer = new Magnetometer({ frequency: 2 });
        magnetometer.addEventListener('reading', () => {
          // Calculate vector magnitude in microteslas (µT): sqrt(x^2 + y^2 + z^2)
          const fieldStrength = Math.sqrt(
            Math.pow(magnetometer.x, 2) +
            Math.pow(magnetometer.y, 2) +
            Math.pow(magnetometer.z, 2)
          );

          // Earth's magnetic field is typically between 25 and 65 µT.
          // Thresholds set at > 85 µT to prevent false positives from slight anomalies
          const magPill = document.getElementById('magneticInterferencePill');
          if (fieldStrength > 85 || fieldStrength < 15) {
            if (magPill) magPill.classList.remove('hidden');
            if (!interferenceWarningActive) {
              interferenceWarningActive = true;
              showToast('⚠️ HIGH MAGNETIC INTERFERENCE: Step away from metal/electronics for accurate Vastu reading');
              if (sensorStatus) sensorStatus.textContent = '⚠️ High Interference Detected (' + Math.round(fieldStrength) + ' µT)';
              if (sensorStatus) sensorStatus.style.color = '#fca5a5';
              if (compassViewport) compassViewport.style.boxShadow = '0 0 20px rgba(252, 165, 165, 0.4)';
            }
          } else {
            if (magPill) magPill.classList.add('hidden');
            if (interferenceWarningActive) {
              interferenceWarningActive = false;
              if (sensorStatus) sensorStatus.textContent = 'North tracking active';
              if (sensorStatus) sensorStatus.style.color = 'var(--text-main)';
              if (compassViewport) compassViewport.style.boxShadow = '';
            }
          }
        });
        magnetometer.addEventListener('error', (e) => {
          console.warn('Magnetometer error:', e.error.name, e.error.message);
          // NotReadableError means sensor is blocked by another app or hardware issue
          if (e.error.name === 'NotAllowedError') {
            console.log('Magnetometer permission denied');
          }
        });
        magnetometer.start();
      } catch (err) {
        console.log('Magnetometer API not available/permitted for interference detection');
      }
    }
  }

  function startMagnetometer() {
    if (magnetometer) {
      try { magnetometer.start(); } catch(e) {}
    }
  }

  function stopMagnetometer() {
    if (magnetometer) {
      try { magnetometer.stop(); } catch(e) {}
    }
  }

  // --- Sensor Initialization ---
  // iOS 13+: DeviceOrientationEvent.requestPermission() MUST run inside a user gesture. We never call it
  // automatically: if no sensor data arrives we reveal a banner whose button (btnGrantSensor) calls it.
  // A stored "already enabled" flag is NOT trusted: iOS re-asks per session / app launch, so only real
  // data proves access (the old flag could hide the banner and leave a dead compass).
  let sensorPermissionTimer = null;

  function isIosPermissionApi() {
    return typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function';
  }

  function scheduleSensorPermissionCheck() {
    if (!isIosPermissionApi()) return;
    clearTimeout(sensorPermissionTimer);
    sensorPermissionTimer = setTimeout(() => {
      sensorPermissionTimer = null;
      if (!hasSensorData && iosPermissionBanner) iosPermissionBanner.classList.remove('hidden');
    }, 1000);
  }

  function initSensors() {
    initMagnetometer();
    attachSensorListeners(); // harmless before iOS permission: events simply start after the user taps Enable
    scheduleSensorPermissionCheck();

    if (!isIosPermissionApi() && !('ondeviceorientation' in window) && !('ondeviceorientationabsolute' in window)) {
      if (sensorStatus) sensorStatus.textContent = 'Device orientation not supported';
    }

    // Graceful hardware detection (phones/tablets without a magnetometer): manual azimuth dial mode
    setTimeout(() => {
      if (!hasSensorData && !isIosPermissionApi()) {
        if (sensorStatus) {
          sensorStatus.textContent = 'Manual Azimuth Mode (Touch/Drag dial)';
          sensorStatus.style.color = '#fbbf24';
        }
        const lblCal = document.getElementById('lblCalSensor');
        if (lblCal) lblCal.textContent = 'MANUAL DIAL (NO SENSOR)';
      }
    }, 2500);
  }

  // ═══ §13 PWA ══════════════════════════════════════════════════
  // Service Worker registration, install prompt, update detection.
  function initPWA() {
    if ('serviceWorker' in navigator) {
      window.addEventListener('load', () => {
        navigator.serviceWorker.register('./sw.js')
          .then((reg) => {
            console.log('KUBERAN Vastu Compass SW registered:', reg.scope);
            // Force immediate update check
            reg.update();
            reg.addEventListener('updatefound', () => {
              const newWorker = reg.installing;
              if (newWorker) {
                newWorker.addEventListener('statechange', () => {
                  if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
                    console.log('New Vastu Compass version available, updating cache...');
                  }
                });
              }
            });
          })
          .catch((err) => console.warn('SW registration failed:', err));
      });

      let refreshing = false;
      const hadController = Boolean(navigator.serviceWorker.controller);
      navigator.serviceWorker.addEventListener('controllerchange', () => {
        // Only reload if the client was already controlled by an older worker (prevent first-install reload)
        if (!refreshing && hadController) {
          refreshing = true;
          window.location.reload();
        }
      });
    }

    // Capture install prompt
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      deferredPrompt = e;
      btnInstallApp.classList.remove('hidden');
    });

    if (btnInstallApp) btnInstallApp.addEventListener('click', async () => {
      if (deferredPrompt) {
        deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        if (outcome === 'granted') {
          btnInstallApp.classList.add('hidden');
        }
        deferredPrompt = null;
      }
    });
  }

  // ═══ §15 BOOTSTRAP ════════════════════════════════════════════
  // Application entry point.
  // ═══ Sensor lifecycle ═════════════════════════════════════════
  // pause: tab hidden / page hidden / app backgrounded   resume: visible again / bfcache restore
  // destroy: page unload or embedding component unmount (removes EVERY listener, timer and RAF it created)
  let sensorsPaused = false;

  function pauseSensors() {
    detachSensorListeners();
    stopMagnetometer();
    stopGPS();
    stabilizer.stop();
    if (inclinometerRafId) { cancelAnimationFrame(inclinometerRafId); inclinometerRafId = null; }
    clearTimeout(sensorPermissionTimer);
    if (isPrecisionSampling) { // a survey interrupted by backgrounding would average stale samples
      clearInterval(precisionSampleCountdown);
      clearTimeout(precisionSampleTimer);
      isPrecisionSampling = false;
      const pill = document.getElementById('btnPrecisionSample');
      const pillText = document.getElementById('precisionPillText');
      if (pill) pill.classList.remove('sampling');
      if (pillText) pillText.textContent = '5s LOCK';
    }
    if (cameraStream) toggleCameraAR(); // release camera hardware cleanly
    sensorsPaused = true;
  }

  function resumeSensors() {
    if (!sensorsPaused) return;
    sensorsPaused = false;
    resetHeadingFilters(); // drop stale history so the dial does not sweep from the pre-background heading
    attachSensorListeners();
    startMagnetometer();
    startGPS();
    scheduleSensorPermissionCheck();
  }

  function onVisibilityChange() {
    if (document.hidden) pauseSensors(); else resumeSensors();
  }
  function onPageHide() { pauseSensors(); }
  function onPageShow(e) { if (e.persisted) resumeSensors(); }

  let capBackListenerHandle = null;

  function setupCapacitorBackButton() {
    const capApp = window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.App;
    if (!capApp || typeof capApp.addListener !== 'function') return;
    Promise.resolve(capApp.addListener('backButton', ({ canGoBack }) => {
      // 1. Close any open modal (except mandatory first-launch disclaimer)
      const openModal = document.querySelector('.modal-backdrop:not(.hidden):not(#firstLaunchDisclaimerModal)');
      if (openModal) {
        openModal.classList.add('hidden');
        return;
      }
      // 2. Exit Fullscreen AR Camera mode if active
      const arOverlay = document.getElementById('arFullscreenOverlay');
      if (arOverlay && !arOverlay.classList.contains('hidden')) {
        if (cameraStream) toggleCameraAR();
        else arOverlay.classList.add('hidden');
        return;
      }
      // 3. Otherwise minimize/exit cleanly on Android root view
      if (canGoBack && window.history.length > 1) {
        window.history.back();
      } else if (typeof capApp.exitApp === 'function') {
        capApp.exitApp();
      }
    })).then((handle) => { capBackListenerHandle = handle; }).catch(() => {});
  }

  function destroyCompass() {
    pauseSensors();
    document.removeEventListener('visibilitychange', onVisibilityChange);
    window.removeEventListener('pagehide', onPageHide);
    window.removeEventListener('pageshow', onPageShow);
    detachDesktopDragSimulation();
    if (capBackListenerHandle && typeof capBackListenerHandle.remove === 'function') {
      try { capBackListenerHandle.remove(); } catch(e) {}
      capBackListenerHandle = null;
    }
  }

  // Public handle for embedding shells (Capacitor / frameworks): call destroy() on unmount.
  window.KuberanCompass = { pause: pauseSensors, resume: resumeSensors, destroy: destroyCompass };

  function init() {
    setupEventListeners();
    buildDialSvg();
    initSensors();
    initGPS();
    initPWA();
    updateCalibrationUI();
    updateHeading(0);
    updateInclinometer(0, 0);

    // First Launch Vedic Architectural Disclaimer
    try {
      const disclaimerAccepted = localStorage.getItem('kuberan_shastra_disclaimer_accepted') === 'true';
      const firstLaunchModal = document.getElementById('firstLaunchDisclaimerModal');
      const btnAcceptDisclaimer = document.getElementById('btnAcceptDisclaimer');
      if (!disclaimerAccepted && firstLaunchModal) {
        firstLaunchModal.classList.remove('hidden');
        if (btnAcceptDisclaimer) {
          btnAcceptDisclaimer.addEventListener('click', () => {
            try { localStorage.setItem('kuberan_shastra_disclaimer_accepted', 'true'); } catch (e) {}
            firstLaunchModal.classList.add('hidden');
          });
        }
      }
    } catch (e) {}

    // Lifecycle: pause on hide / pagehide, resume on return, full cleanup via destroyCompass()
    document.addEventListener('visibilitychange', onVisibilityChange);
    window.addEventListener('pagehide', onPageHide);
    window.addEventListener('pageshow', onPageShow);
    setupCapacitorBackButton();

    // A saved manual offset shifts EVERY reading. Never let it hide silently.
    if (Math.abs(calibrationOffset) >= 0.5) {
      setTimeout(() => showToast(`Manual offset ${calibrationOffset > 0 ? '+' : ''}${calibrationOffset.toFixed(1)}° is active - reset it in Calibrate if the compass reads wrong`), 1200);
    }
  }

  
  
  let remedyToastTimer;
  // ═══ §12 REMEDIES ═════════════════════════════════════════════
  // Vastu Dosha analysis engine & element-zone remedy mapping.
  // Future: extract to RemediesEngine.js.
  const REMEDY_SETTING_KEY = 'kuberan_show_vastu_remedies';
  const toggleRemedies = document.getElementById('toggle-remedies');
  
  if (toggleRemedies) {
    let isRemedyEnabled = false;
    try { isRemedyEnabled = localStorage.getItem(REMEDY_SETTING_KEY) === 'true'; } catch(e) {}
    toggleRemedies.checked = isRemedyEnabled;
    
    toggleRemedies.addEventListener('change', (e) => {
      try { localStorage.setItem(REMEDY_SETTING_KEY, e.target.checked); } catch(err) {}
      applyRemedyVisibility(e.target.checked);
      if (e.target.checked) {
        let remedyToast = document.getElementById('remedyToastAlert');
        if (!remedyToast) {
          remedyToast = document.createElement('div');
          remedyToast.id = 'remedyToastAlert';
          remedyToast.style.position = 'fixed';
          remedyToast.style.bottom = '30px';
          remedyToast.style.left = '50%';
          remedyToast.style.transform = 'translateX(-50%)';
          remedyToast.style.backgroundColor = 'rgba(20, 25, 35, 0.98)';
          remedyToast.style.color = '#f7eedd';
          remedyToast.style.padding = '15px 20px';
          remedyToast.style.borderRadius = '12px';
          remedyToast.style.border = '1px solid #d4a359';
          remedyToast.style.zIndex = '99999';
          remedyToast.style.width = '85%';
          remedyToast.style.maxWidth = '400px';
          remedyToast.style.boxShadow = '0 10px 40px rgba(0,0,0,0.8)';
          remedyToast.style.display = 'flex';
          remedyToast.style.alignItems = 'flex-start';
          remedyToast.style.gap = '10px';
          remedyToast.style.fontFamily = 'inherit';
          remedyToast.style.fontSize = '0.9rem';
          remedyToast.style.lineHeight = '1.4';
          
          remedyToast.innerHTML = `
            <div style="flex:1;">
              <strong style="color:#d4a359; font-size:1rem; display:block; margin-bottom:5px;">ℹ️ Vastu AI Engine</strong>
              <span style="opacity:0.9;">Please use the <strong>Room Finder (in the bottom dock)</strong> to select a room... Then open this report to generate an AI Vastu Dosha analysis and view remedies.</span>
            </div>
            <button id="closeRemedyToast" style="background:none; border:none; color:#d4a359; font-size:1.8rem; cursor:pointer; padding:0; line-height:1; outline:none;">&times;</button>
          `;
          document.body.appendChild(remedyToast);
          
          document.getElementById('closeRemedyToast').addEventListener('click', () => {
            remedyToast.style.display = 'none';
          });
        }
        
        remedyToast.style.display = 'flex';
        
        if (remedyToastTimer) clearTimeout(remedyToastTimer);
        remedyToastTimer = setTimeout(() => {
          if (remedyToast) remedyToast.style.display = 'none';
        }, 30000);
      }
    });
  }

  function applyRemedyVisibility(show) {
    const remedyPanels = document.querySelectorAll('.remedy-card');
    remedyPanels.forEach(panel => {
      if (show) panel.classList.remove('hidden');
      else panel.classList.add('hidden');
    });
  }

  async function fetchVastuAnalysis(direction, roomObj, activeZoneKey) {
    const container = document.getElementById('vastu-analysis-container');
    if (!container) return;
    
    container.innerHTML = `<p style="padding: 10px; color: #fbbf24; font-style: italic; text-align: center;">⚙️ Analyzing Pancha Tattva parameters...</p>`;

    // Simulate AI loading delay
    await new Promise(r => setTimeout(r, 600));

    try {
      const data = generateLocalVastuAnalysis(direction, roomObj, activeZoneKey);
      renderVastuResult(data);
    } catch (error) {
      console.error('Vastu Engine Error:', error);
      container.innerHTML = `<p style="color:red; text-align:center;">Error generating Vastu recommendations.</p>`;
    }
  }

  function generateLocalVastuAnalysis(directionName, roomObj, zoneKey) {
    let roomName = 'General Layout';
    let isCompliant = true;
    let severity = 'NONE';
    let conflict = 'Placement is generally compliant or neutral.';
    
    const remedies = {
      simple_fixes: [],
      elemental_cures: [],
      elemental_harmonizers: [],
      vastu_instruments: []
    };

    if (roomObj) {
      roomName = (roomObj.names && roomObj.names.en) ? roomObj.names.en : roomObj.id;
      const zCode = zoneKey;
      
      if (roomObj.idealZones && roomObj.idealZones.includes(zCode)) {
        isCompliant = true;
        severity = 'NONE';
        conflict = 'No Vastu Dosha detected. This room placement is highly auspicious per Pancha Tattva principles.';
      } 
      else if (roomObj.avoidZones && roomObj.avoidZones.includes(zCode)) {
        isCompliant = false;
        severity = 'HIGH';
      } 
      else {
        isCompliant = false;
        severity = 'MEDIUM';
      }
    }

    if (!isCompliant) {
      // ===== PANCHA TATTVA ELEMENT-ZONE MAPPING (Fact-Checked) =====
      // Water (Jala): N, NNE, NE, NNW
      // Air (Vayu): ENE, E, ESE, NW
      // Fire (Agni): SE, SSE, S
      // Earth (Prithvi): SSW, SW
      // Space/Ether (Akasha): WSW, W, WNW

      // --- WATER ELEMENT ZONES: N, NNE, NE, NNW ---
      if (zoneKey === 'N' || zoneKey === 'NNE' || zoneKey === 'NE' || zoneKey === 'NNW') {
        conflict = 'Jala Tattva (Water Element) imbalance in ' + directionName + '. Governed by Lord Kubera (N) and Ishana/Shiva (NE). In classical Vastu, associated with reduced spatial harmony, focus, and natural vitality.';
        remedies.simple_fixes.push('Keep this zone absolutely clutter-free, clean, and well-lit at all times.');
        remedies.simple_fixes.push('Place a bowl of natural sea salt (uncrushed rock salt) in the corner — replace weekly.');
        remedies.simple_fixes.push('Use light blue or white color tones for walls and furnishings in this zone.');
        remedies.elemental_cures.push('Place a small indoor water feature, aquarium, or a brass Kalash filled with clean water.');
        remedies.elemental_cures.push('Introduce Silver or Zinc metallic objects to enhance the Water element.');
        remedies.elemental_cures.push('Keep a Tulsi (Holy Basil) or Money Plant in the North-East corner.');
        remedies.vastu_instruments.push('Install a Kuber Yantra (for North) or an Ishana Yantra (for NE) on the wall.');
        remedies.vastu_instruments.push('Place a Crystal Sphatik Shivling in the NE corner for spiritual amplification.');
        remedies.vastu_instruments.push('Use a 9-pyramid Vastu plate beneath the water element to energize the zone.');
      }
      // --- AIR ELEMENT ZONES: ENE, E, ESE, NW ---
      else if (zoneKey === 'ENE' || zoneKey === 'E' || zoneKey === 'ESE' || zoneKey === 'NW') {
        conflict = 'Vayu Tattva (Air Element) imbalance in ' + directionName + '. Governed by Indra/Surya (E) and Vayu Deva (NW). Affects social connections, support systems, legal matters, and mental wellbeing.';
        remedies.simple_fixes.push('Ensure excellent cross-ventilation — keep windows in this zone open during daytime.');
        remedies.simple_fixes.push('Place wind chimes with 5 or 6 hollow metal rods (avoid wooden ones).');
        remedies.simple_fixes.push('Use light green or pastel-toned decor to harmonize the Air element.');
        remedies.elemental_cures.push('Place Brass or Bronze decorative items (diyas, figurines) to balance Vayu.');
        remedies.elemental_cures.push('Grow aromatic indoor plants like Jasmine or Lavender in this zone.');
        remedies.elemental_cures.push('Hang a Brass Trishul or Brass Om symbol near the entrance of this zone.');
        remedies.vastu_instruments.push('Install an Indra Yantra (for East) or a Vayu Yantra (for NW) on the wall.');
        remedies.vastu_instruments.push('Place a Brass Vastu Helix (clockwise spiral) to redirect stagnant air energy.');
      }
      // --- FIRE ELEMENT ZONES: SE, SSE, S ---
      else if (zoneKey === 'SE' || zoneKey === 'SSE' || zoneKey === 'S') {
        conflict = 'Agni Tattva (Fire Element) imbalance in ' + directionName + '. Governed by Agni Deva (SE) and Yama Dharmaraja (S). Impacts cash flow, vitality, confidence, and digestive health.';
        remedies.simple_fixes.push('Light a ghee deepak (oil lamp) or a red/orange LED lamp in this zone every evening.');
        remedies.simple_fixes.push('Use warm colors — red, orange, maroon, or coral — for curtains and wall accents.');
        remedies.simple_fixes.push('Avoid keeping water storage, aquariums, or blue decor in this Fire zone.');
        remedies.elemental_cures.push('Place Copper strips, a Copper Swastik plate, or Copper utensils in this zone.');
        remedies.elemental_cures.push('Keep a natural Red Jasper or Carnelian stone in the SE corner.');
        remedies.elemental_cures.push('Install an electrical appliance (heater, inverter) in the SE to honor Agni.');
        remedies.vastu_instruments.push('Install an Agni Yantra or Mangal Yantra on the South-East wall.');
        remedies.vastu_instruments.push('Place a Copper Vastu Pyramid (pointed upward) to amplify fire energy.');
        remedies.vastu_instruments.push('Keep a Swastik symbol made of Copper or red kumkum at the SE entrance.');
      }
      // --- EARTH ELEMENT ZONES: SSW, SW ---
      else if (zoneKey === 'SSW' || zoneKey === 'SW') {
        conflict = 'Prithvi Tattva (Earth Element) imbalance in ' + directionName + '. Governed by Nairrti Devi (SW). Affects stability, marital harmony, the head of family, and long-term savings.';
        remedies.simple_fixes.push('Place heavy furniture, storage units, or iron safes in this zone to ground the energy.');
        remedies.simple_fixes.push('Use earthy tones — yellow, beige, brown, or terracotta — for walls and decor.');
        remedies.simple_fixes.push('Avoid keeping the SW zone empty or lightweight — it must feel dense and grounded.');
        remedies.elemental_cures.push('Place Lead (Sisa) strips or blocks along the floor skirting of this zone.');
        remedies.elemental_cures.push('Keep natural Yellow Sapphire, Tiger Eye, or Citrine gemstones here.');
        remedies.elemental_cures.push('Install Brass or Iron heavy figurines (like Nandi or elephants) for stability.');
        remedies.vastu_instruments.push('Install a Nairrti Yantra or a Rahu Yantra on the South-West wall.');
        remedies.vastu_instruments.push('Place a Lead Vastu Helix (Vastu Spring) to ground and stabilize the dosha.');
        remedies.vastu_instruments.push('Keep a square brass plate with the Om symbol under a heavy object in the SW.');
      }
      // --- SPACE/ETHER ELEMENT ZONES: WSW, W, WNW ---
      else if (zoneKey === 'WSW' || zoneKey === 'W' || zoneKey === 'WNW') {
        conflict = 'Akasha Tattva (Space/Ether Element) imbalance in ' + directionName + '. Governed by Lord Varuna (W). Affects financial gains, education, savings, and emotional release from grief/depression.';
        remedies.simple_fixes.push('Keep this zone moderately open with balanced storage — avoid over-cluttering.');
        remedies.simple_fixes.push('Use light grey, white, or metallic silver tones for this zone decor.');
        remedies.simple_fixes.push('Play soothing vedic mantras or chanting in this zone daily for Akasha activation.');
        remedies.elemental_cures.push('Place Iron or Steel metallic objects to stabilize the expansive Ether energy.');
        remedies.elemental_cures.push('Keep a Shankh (conch shell) in the West to invoke Varuna blessings.');
        remedies.elemental_cures.push('Install a small bell or gong — sound harmonizes the Space element.');
        remedies.vastu_instruments.push('Install a Varuna Yantra on the Western wall to balance Akasha Tattva.');
        remedies.vastu_instruments.push('Place an Iron Vastu Helix or a multi-metal (Panchdhatu) pyramid here.');
        remedies.vastu_instruments.push('Keep a round metallic plate with Gayatri Mantra inscription in this zone.');
      }
      // --- FALLBACK for any unmapped sub-directions ---
      else {
        conflict = 'General Pancha Tattva imbalance detected. The room placement does not align with ideal Vastu prescriptions for this direction.';
        remedies.simple_fixes.push('Cleanse the area weekly with camphor (Kapoor) or dried sage.');
        remedies.simple_fixes.push('Place natural rock salt bowls in corners to neutralize negative energy.');
        remedies.elemental_cures.push('Use Panchdhatu (five-metal alloy) items to balance all five elements simultaneously.');
        remedies.elemental_cures.push('Introduce indoor plants and natural lighting to harmonize Prana flow.');
        remedies.vastu_instruments.push('Install a Sarva Dosha Nivaran Yantra for multi-directional correction.');
        remedies.vastu_instruments.push('Place directional Vastu pyramids specific to the affected wall.');
      }
    }

    return {
      direction: directionName,
      room: roomName,
      isCompliant: isCompliant,
      severity: severity,
      elementalConflict: conflict,
      remedies: remedies
    };
  }

  function renderVastuResult(data) {
    const container = document.getElementById('vastu-analysis-container');
    if (!container) return;
    let isRemedyEnabled = false;
    try { isRemedyEnabled = localStorage.getItem(REMEDY_SETTING_KEY) === 'true'; } catch(e) {}
    const remedyCardClass = isRemedyEnabled ? 'remedy-card' : 'remedy-card hidden';

    if (data.isCompliant) {
      if (data.room === 'General Layout') {
        container.innerHTML = `
          <div class="vastu-success" style="padding:10px; text-align:left;">
            <h3 style="font-size:1.1rem;">ℹ️ Select a Room</h3>
            <p style="font-size:0.9rem; opacity:0.9; margin:0;">Please use the <strong>Room Finder</strong> (in the bottom dock) to select a room (e.g. Kitchen, Master Bedroom). Then open this report to generate an AI Vastu Dosha analysis and view remedies.</p>
          </div>
        `;
      } else {
        container.innerHTML = `
          <div class="vastu-success" style="padding:10px; text-align:left;">
            <h3 style="font-size:1.1rem;">✅ ${data.direction} - ${data.room}</h3>
            <p style="font-size:0.9rem; opacity:0.9; margin:0;">Excellent! This placement is fully compliant with Vastu Shastra rules. No remedies required.</p>
          </div>
        `;
      }
      return;
    }

    let html = `
      <div class="vastu-defect" style="text-align:left; padding:10px 0;">
        <h3 style="font-size:1.1rem;">⚠️ Vastu Defect (${data.severity})</h3>
        <p style="font-size:0.9rem; opacity:0.9; margin:4px 0;"><strong>Dir:</strong> ${data.direction} | <strong>Room:</strong> ${data.room}</p>
        <p style="font-size:0.85rem; color:#fca5a5; margin:4px 0;"><em>${data.elementalConflict}</em></p>

        <div class="${remedyCardClass}">
          <h4>⚡ Traditional Harmonizers & Vedic Balancers</h4>
          
          ${data.remedies.simple_fixes.length > 0 ? `
            <div class="remedy-section-title">Household Fixes</div>
            <ul class="remedy-list">
              ${data.remedies.simple_fixes.map(r => `<li>${r}</li>`).join('')}
            </ul>
          ` : ''}

          ${data.remedies.elemental_cures.length > 0 ? `
            <div class="remedy-section-title">Elemental Harmonizers</div>
            <ul class="remedy-list">
              ${data.remedies.elemental_cures.map(r => `<li>${r}</li>`).join('')}
            </ul>
          ` : ''}

          ${data.remedies.vastu_instruments.length > 0 ? `
            <div class="remedy-section-title">Vastu Instruments</div>
            <ul class="remedy-list">
              ${data.remedies.vastu_instruments.map(r => `<li>${r}</li>`).join('')}
            </ul>
          ` : ''}
        </div>
      </div>
    `;

    container.innerHTML = html;
  }

  // --- SETTINGS MODAL BINDINGS (v4.6.4) ---
  const settingsModal = document.getElementById('settingsModal');
  const btnSettings = document.getElementById('btnSettings');
  const btnCloseSettings = document.getElementById('btnCloseSettings');

  if (btnSettings && settingsModal) {
    btnSettings.addEventListener('click', () => settingsModal.classList.remove('hidden'));
    btnCloseSettings.addEventListener('click', () => settingsModal.classList.add('hidden'));
    
    // Close on outside click
    settingsModal.addEventListener('click', (e) => {
      if (e.target === settingsModal) settingsModal.classList.add('hidden');
    });
  }

  // Language setting
  const selLang = document.getElementById('setting-lang');
  if (selLang) {
    selLang.value = currentLang;
    selLang.addEventListener('change', (e) => setLanguage(e.target.value));
  }

  // Compass Ref (True/Magnetic)
  const radiosRef = document.getElementsByName('compass-ref');
  radiosRef.forEach(r => r.addEventListener('change', (e) => {
    if (e.target.checked) {
      isTrueNorth = (e.target.value === 'true');
      const btnQuickNorthEl = document.getElementById('btnQuickNorth');
      const quickNorthLabelEl = document.getElementById('quickNorthLabel');
      if (btnQuickNorthEl) btnQuickNorthEl.classList.toggle('active', isTrueNorth);
      if (quickNorthLabelEl) quickNorthLabelEl.textContent = isTrueNorth ? 'TRUE' : 'MAG';
      if (modeTrue && modeMagnetic) {
        modeTrue.classList.toggle('active', isTrueNorth);
        modeMagnetic.classList.toggle('active', !isTrueNorth);
      }
      updateHeading(rawMagneticHeading, true);
    }
  }));

  // Dial Style
  const selDial = document.getElementById('setting-dial-style');
  if (selDial) {
    selDial.value = dialTheme;
    selDial.addEventListener('change', (e) => {
      dialTheme = e.target.value;
      currentDialThemeIndex = DIAL_THEMES.indexOf(dialTheme);
      document.body.classList.remove('theme-elemental', 'theme-chakra', 'theme-gold');
      document.body.classList.add('theme-' + dialTheme);
      buildDialSvg(); // redraw the dial immediately
    });
  }

  // Property Type
  const selProp = document.getElementById('setting-property');
  const selRetail = document.getElementById('setting-retail-profile');
  const retailGroup = document.getElementById('retailProfileSettingGroup');
  
  if (selProp) {
    selProp.value = propertyType;
    if (propertyType === 'commercial' && retailGroup) {
      retailGroup.classList.remove('hidden');
    }
    
    selProp.addEventListener('change', (e) => {
      propertyType = e.target.value;
      roomCategoryTab = propertyType;
      
      const tabResRooms = document.getElementById('tabResRooms');
      const tabCommRooms = document.getElementById('tabCommRooms');
      
      if (propertyType === 'commercial') {
        if (retailGroup) retailGroup.classList.remove('hidden');
        if (tabCommRooms) tabCommRooms.classList.add('active');
        if (tabResRooms) tabResRooms.classList.remove('active');
        showToast('Switched to Commercial Vastu');
      } else {
        if (retailGroup) retailGroup.classList.add('hidden');
        if (tabResRooms) tabResRooms.classList.add('active');
        if (tabCommRooms) tabCommRooms.classList.remove('active');
        showToast('Switched to Residential Vastu');
      }
      
      if (typeof renderRoomsGrid === 'function') renderRoomsGrid();
      updateVastuInspector(currentHeading);
      buildDialSvg();
    });
  }

  // Retail Profile
  if (selRetail) {
    selRetail.value = retailProfile;
    selRetail.addEventListener('change', (e) => {
      retailProfile = e.target.value;
      showToast('Retail Profile Updated');
      buildDialSvg();
      updateVastuInspector(currentHeading);
    });
  }

  // Zonal Division
  const radiosZones = document.getElementsByName('zones');
  radiosZones.forEach(r => r.addEventListener('change', (e) => {
    if (e.target.checked) {
      zoneSystem = e.target.value;
      const q8 = document.getElementById('btnQuickZone8');
      const q16 = document.getElementById('btnQuickZone16');
      const q32 = document.getElementById('btnQuickZone32');
      if (q8) q8.classList.toggle('active', zoneSystem === '8');
      if (q16) q16.classList.toggle('active', zoneSystem === '16');
      if (q32) q32.classList.toggle('active', zoneSystem === '32');
      if (zoneSystem === '32') {
        if (padaEntranceCard) padaEntranceCard.classList.remove('hidden');
      } else {
        if (padaEntranceCard) padaEntranceCard.classList.add('hidden');
      }
      updateVastuInspector(currentHeading);
      buildDialSvg();
    }
  }));

  // Run on DOM load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

})();





